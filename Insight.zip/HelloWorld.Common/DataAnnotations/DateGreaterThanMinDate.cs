﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HelloWorld.Common.DataAnnotations
{
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class DateGreaterThanMinDate : ValidationAttribute
    {
        private const string DefaultErrorMessage = "Please enter a valid date.";

        private string Message { get; set; }

        public DateGreaterThanMinDate()
            : base(DefaultErrorMessage)
        {
            Message = DefaultErrorMessage;
        }

        public DateGreaterThanMinDate(string errorMessage)
            : base(errorMessage)
        {
            Message = errorMessage;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var dateEntered = (DateTime?)value;
            if (dateEntered.HasValue && dateEntered < DateTime.MinValue.AddDays(1))
            {
                return new ValidationResult(Message);
            }
            return null;
        }
    }

    /*
 



        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context) {
            var rule = new ModelClientCustomDateValidationRule(FormatErrorMessage(metadata.DisplayName));
            yield return rule;
       }
    }

    public sealed class ModelClientCustomDateValidationRule : ModelClientValidationRule {

        public ModelClientCustomDateValidationRule(string errorMessage) {
            ErrorMessage = errorMessage;
            ValidationType = "datemustbeequalorgreaterthancurrentdate";
        }
    }
}*/
}
