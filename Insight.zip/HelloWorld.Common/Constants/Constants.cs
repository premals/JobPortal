﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld.Common.Constants
{
    public static class Constants
    {
        public const string InvalidAmountMessage = "Invalid Amount.   ";

        public static class URLs
        {
            public static string Residents = "residents/index";
        }

        public static class Styles
        {
            public static class Drag
            {
                public const string Default = "relative rounded-lg border-2 border-dashed pa-4 mt-4 mud-width-full mud-height-full z-10";
                public const string DragEnter = "relative rounded-lg border-2 border-dashed pa-4 mt-4 mud-width-full mud-height-full z-10 mud-border-primary";
            }

            public static class Dialog
            {
                public const string Content = "height: 90vh; overflow-y: auto; overflow-x: hidden;";
            }
        }

        public static class Messages
        {
            public static class DragAndDrop
            {
                public const string Default = "Drag and drop files here or click";
            }

            public static class UploadStatus
            {
                public const string UploadingFiles = "Uploading File(s)...";
            }

            public static class Warning
            {
                public const string FileExceedsMaxSize = "{0} exceeds the max size of 10MB and has been removed from the upload.";
                public const string IncorrectUploadFileType = "{0} is not a PDF file and has been removed from the upload.";
                public const string UnableToLoadDocuments = "Unable to load Documents at this time. Please try again. If issue persists, please contact support.";
                public const string UnableToDeleteFile = "Unable to delete {0} at this time. Please try again. If issue persists, please contact support.";
            }

            public static class Error
            {
                public const string PleaseTryAgain = "An error occurred -  please try again. If issue persists, please contact support.";
                public const string UnableToDeleteFromBlobStorage = "Unable to delete {0} from blob storage";
                public const string UnableToUploadToBlobStorage = "Unable to upload {0} to blob storage";
                public const string EmptyConnectionString = "DDC Error: Connection string is empty";
                public const string UnableToLoadAzureStorageSettings = "Unable to load Azure Storage settings.";
                public const string UnableToSaveTenantConfig = "Error saving tenant config.";
                public const string UnableToGetTenantConfig = "Error getting tenant config.";
            }

            public static class Success
            {
                public const string SavedSuccessfully = "Saved successfully.";
            }

            public static class Dialog
            {
                public const string DeleteDocumentConfirmation = "Are you sure you want to delete this document?";
                public const string Warning = "Warning!";
            }

            public static class Info
            {
                public const string NoChangesMade = "No changes have been made.";
            }

            public static class MatrixIntegration
            {
                public const string ChangeMatrixIntegrationConfirmation = "You are about to change the Matrix configuration for this organization. This could break integrations. Do you wish to proceed?";
                public const string MatrixIntegrationSavedSuccessfully = "Matrix Integration Saved Successfully";
                public const string DuplicateFacilityCode = "Duplicate Facility Code. Please Enter a Unique Facility Code.";
            }
        }

        public static class SessionStorageKeys
        {
            public const string AzureStorageConnectionString = "AzureStorageConnectionString";
            public const string AzureStorageAccountKey = "AzureStorageAccountKey";
            public const string AzureStorageUri = "AzureStorageUri";
            public const string AzureStorageAccountName = "AzureStorageAccountName";
            public const string EmployeeId = "EmployeeId";
            public const string CurrentFacilityId = "CurrentFacilityId";
            public const string CurrentFacility = "CurrentFacility";
            public const string ConnectionString = "ConnectionString";
            public const string TenantId = "TenantId";
            public const string IsMatrixEnabled = "IsMatrixEnabled";
            public const string MatrixFacilityCode = "MatrixFacilityCode";
        }

        public static class ContentType
        {
            public const string ApplicationPdf = "application/pdf";
        }

		public static class FileSize
		{
			public const int MaxFileSizeMB = 10;
		}

        public static class ResidentPayerRank
        {
            public const string Primary = "PRIMARY";
            public const string Secondary = "SECONDARY";
            public const string Tertiary = "TERTIARY";
            public const string Fourth = "FORTH";
            public const string Fifth = "FIFTH";
        }

        public static class Log
        {
            public const string LogUser = "[Timestamp: {0}] [Actor: {1}] [Action: {2}] [Target: {3}] [Result: {4}]";
        }
    }
}
