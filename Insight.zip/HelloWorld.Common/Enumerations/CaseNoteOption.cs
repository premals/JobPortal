﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum CaseNoteOption
    {
        [Description("Show all case notes")]
        ShowAll = 0,
        [Description("Only show most recent")]
        MostRecent = 1,
        [Description("Show last 2 case notes")]
        LastTwo = 2,
        [Description("Show last 5 case notes")]
        LastFive = 5
    }
}
