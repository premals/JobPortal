﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace HelloWorld.Common.Enumerations
{
    public static class InsightEnumExtensions
    {
        public static string GetDisplayName(this Enum value)
        {
            var enumMember = value.GetType().GetMember(value.ToString())[0];
            var customAttribute = enumMember.GetCustomAttribute<DisplayAttribute>();

            return customAttribute?.Name ?? value.ToString();
        }

        public static T? FromDisplayName<T>(string displayName) where T : struct, Enum
        {
            foreach (var value in Enum.GetValues(typeof(T)).Cast<T>())
            {
                if (value.GetDisplayName().Equals(displayName, StringComparison.OrdinalIgnoreCase))
                {
                    return value;
                }
            }

            return null;
        }
    }
}
