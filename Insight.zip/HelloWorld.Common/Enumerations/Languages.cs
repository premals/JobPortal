﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum Languages
    {
        [Description("English")]
        English = 1,
        [Description("Spanish")]
        Spanish = 2,
        [Description("Chinese")]
        Chinese = 3,
        [Description("Tagalog")]
        Tagalog = 4,
        [Description("Vietnamese")]
        Vietnamese = 5,
        [Description("Korean")]
        Korean = 6,
        [Description("French")]
        French = 7,
        [Description("German")]
        German = 8,
        [Description("Arabic")]
        Arabic = 9,
        [Description("Russian")]
        Russian = 10,
        [Description("American Sign Language")]
        AmericanSignLanguage = 11
    }
}
