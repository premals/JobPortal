﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Common.Enumerations
{
    public enum PayerCodeTypeEnum
    {
        [Display(Name = "Medicaid Pending")]
        MedicaidPending = 1,
        Medicaid = 2,
        Private = 3
    }
}
