﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum MaritalStatuses
    {
        [Description("Unknown")]
        Unknown = 0,
        [Description("Single")]
        Single = 1,
        [Description("Married")]
        Married = 2,
        [Description("Separated")]
        Separated = 3,
        [Description("Divorced")]
        Divorced = 4,
        [Description("Widowed")]
        Widowed = 5
    }
}
