﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum NoteType
    {
        [Description("Other")]
        Other = 0, 
        [Description("Appeal")]
        Appeal = 1,
        [Description("Call")]
        Call = 2,
        [Description("Email")]
        Email = 3,
        [Description("General Note")]
        GeneralNote = 4,
        [Description("Letter Sent")]
        LetterSent = 5,
        [Description("Medicaid Pending Update")]
        MedicaidPendingUpdate = 6,
        [Description("Memo")]
        Memo = 7,
    }
}
