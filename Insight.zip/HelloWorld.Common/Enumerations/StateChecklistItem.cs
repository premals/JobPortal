﻿using System.ComponentModel;

namespace HelloWorld.Common.Enumerations
{
    public enum StateChecklistItem 
    {
        [Description("3008")]
        Complete3008 = 1,
        [Description("PASRR")]
        PASRRComplete = 2,
        [Description("Bank Stmts")]
        BankStatementsComplete = 3,
        [Description("SSA Award Letter")]
        SSAAwardLetter = 4,
        [Description("SSDI App")]
        SSDIAppComplete = 5
    }
}
