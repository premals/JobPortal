﻿using System.ComponentModel;

namespace HelloWorld.Common.Enumerations
{
    public enum RateLimitEntity
    {
        [Description("PointClickCare")]
        PointClickCare = 1,
    }
}