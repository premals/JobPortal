﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum EmailNotificationTypeEnum
    {
        [Description("Medicaid Applications Needed")]
        MedicaidApplicationsNeeded = 1,
        [Description("Temporary Level of Care")]
        TemporaryLevelofCare = 2,
        [Description("LTC Managed Care Plans Needed")]
        LTCManagedCarePlansNeeded = 3,
        [Description("LTC Authorization Needed")]
        LTCAuthorizationNeeded = 4,
        [Description("MMA Authorizations Needed")]
        MMAAuthorizationsNeeded = 5,
        [Description("Umed Applications Follow Ups Needed")]
        UmedApplicationsFollowUpsNeeded = 6,
        [Description("Case Notes Follow Ups Needed")]
        CaseNotesFollowUpsNeeded = 7
    }
}
