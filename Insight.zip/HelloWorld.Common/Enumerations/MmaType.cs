﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum MmaType
    {
        [Description("MMA")]
        MMA = 1,
        [Description("DSNP")]
        DSNP = 2,
        [Description("ISNP")]
        ISNP = 3
    }
}
