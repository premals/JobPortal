﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum AssetTypes
    {
        Checking = 1,
        Savings = 2,
        MoneyMarket = 3,
        CertificateOfDeposit = 4,
        Annuity = 5,
        MutualFund = 6,
        FourOhOneK = 7,
        IRA = 8,
        StocksBonds = 9,
        Other = 10
    }
}
