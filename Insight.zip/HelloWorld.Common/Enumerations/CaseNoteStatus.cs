﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum CaseNoteStatus
    {
        [Description("Open")] 
        Open = 0,
        [Description("Pending Approval")]
        PendingApproval = 1,
        [Description("Complete")]
        Complete = 2
    }
}
