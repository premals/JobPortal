﻿using System.ComponentModel;

namespace HelloWorld.Common.Enumerations
{
    public enum ResidentExpenseTypes
    {
        [Description("Health Insurance Premium")]
        HealthInsurancePremium = 1,
        [Description("Mortgage/Rent")]
        MortgageRent = 2,
        [Description("HOA Fee")]
        HoaFee = 3,
        [Description("Home Owners Insurance")]
        HomeOwnersInsurance = 4,
        [Description("Property Taxes")]
        PropertyTaxes = 5, 
        [Description("Electric Bill")]
        ElectricBill = 6,
        [Description("Phone Bill")]
        PhoneBill = 7,
        [Description("Water/Sewer Bill")]
        WaterBill = 8
    }
}
