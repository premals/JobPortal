﻿using System.ComponentModel;

namespace HelloWorld.Common.Enumerations
{
    public enum ResidentBurialAccountTypes
    {
        [Description("Prepaid Burial Account")]
        PrepaidBurialAccount = 1,
        [Description("Burial Insurance")]
        BurialInsurance = 2,
        [Description("Irrevocable Burial Account")]
        IrrevocableBurialAccount = 3
    }
}
