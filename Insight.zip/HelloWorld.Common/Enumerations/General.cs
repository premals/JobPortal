﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum DayOfTheWeek
    { 
        Sunday = 1,
        Monday = 2,
        Tuesday = 3,
        Wednesday = 4,
        Thursday = 5,
        Friday = 6,
        Saturday = 7,
    }

    public enum MessageBoxType
    {
        OK = 1,
        YesNo = 2
    }
}
