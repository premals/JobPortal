﻿using System.ComponentModel;

namespace HelloWorld.Common.Enumerations
{
    public enum ResidentIncomeTypes
    {
        [Description("SSA")]
        Ssa = 1,
        [Description("SSI")]
        Ssi = 2,
        [Description("VA")]
        Va = 3,
        [Description("Pension")]
        Pension = 4,
        [Description("Other")]
        Other = 5
    }
}
