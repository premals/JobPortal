﻿using System.ComponentModel;

namespace HelloWorld.Common.Enumerations
{
    public enum ResidentStatuses
    {
        [Description("Pending Admission")]
        PendingAdmission = 1,
        [Description("Resident")]
        Resident = 2,
        [Description("Discharged")]
        Discharged = 3
    }
}
