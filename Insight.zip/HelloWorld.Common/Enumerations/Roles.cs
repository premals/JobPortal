﻿using System.ComponentModel;

namespace HelloWorld.Common.Enumerations
{
    public enum Roles
    {
        [Description("Super Admin")]
        SuperAdmin = 1, //ONLY has access to configuration pages
        [Description("System Admin")]
        SystemAdmin = 2, //User access plus all Administration
        [Description("User")]
        User = 3, //Will not have access to Administration
        [Description("Admin Config User")]
        AdminConfig = 4, //Will not have access to Administration
    }
}
