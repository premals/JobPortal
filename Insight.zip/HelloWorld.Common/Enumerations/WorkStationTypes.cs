﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum WorkStationTypes
    {
        Desktop = 1,
        Tablet = 2
    }
}
