﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld.Common.Enumerations
{
    public enum AccessLevelType
    {
        Tenant = 1,
        Region = 2,
        Facility = 3
    }
}
