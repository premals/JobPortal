﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Common.Helpers
{
    public static class ReflectionHelper
    {
        public static bool AreShallowEqual<T>(T object1, T object2)
        {
            return CompareInternal(object1, object2, false);
        }

        public static bool AreDeepEqual<T>(T object1, T object2)
        {
            return CompareInternal(object1, object2, true);
        }

        private static bool CompareInternal<T>(T object1, T object2, bool includeObjectProperties)
        {
            if (object1 == null || object2 == null)
            {
                return object1 == null && object2 == null;
            }

            var type = typeof(T);
            var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var property in properties)
            {
                if (property.GetIndexParameters().Length > 0)
                {
                    continue;
                }

                var propertyType = property.PropertyType;

                if (!includeObjectProperties && !propertyType.IsValueType && propertyType != typeof(string))
                {
                    continue;
                }

                var propertyValue1 = property.GetValue(object1);
                var propertyValue2 = property.GetValue(object2);

                if (propertyValue1 == null && propertyValue2 == null)
                {
                    continue;
                }

                if (propertyValue1 == null || propertyValue2 == null)
                {
                    return false;
                }

                if (propertyType == typeof(string) || propertyType.IsValueType)
                {
                    if (!propertyValue1.Equals(propertyValue2))
                    {
                        return false;
                    }
                }
                else
                {
                    var method = typeof(ReflectionHelper).GetMethod(nameof(AreDeepEqual)).MakeGenericMethod(propertyType);
                    var result = (bool)method.Invoke(null, new[] { propertyValue1, propertyValue2 });

                    if (!result)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public static T ShallowCopy<T>(T sourceObject) where T : class, new()
        {
            if (sourceObject == null)
            {
                return null;
            }

            var objectCopy = new T();
            var objectType = typeof(T);

            foreach (var property in objectType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (property.CanRead && property.CanWrite)
                {
                    var propertyValue = property.GetValue(sourceObject, null);

                    property.SetValue(objectCopy, propertyValue, null);
                }
            }

            return objectCopy;
        }
    }
}
