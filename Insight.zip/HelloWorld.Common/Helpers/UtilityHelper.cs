﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace HelloWorld.Common.Helpers
{
    public static class UtilityHelper
    {
        public static string FormatPhoneNumber(string phone)
        {
            phone = phone.Replace("-", "").Replace("(", "").Replace(")", "").Replace(" ", "").Trim();
            return phone;
        }

        public static string FormatEmailAddress(string email)
        {
            email = email.Trim();
            return email;
        }

        public static bool IsValidAmount(decimal amount)
        {
            return (amount >= 0.00M && amount <= 999999.99M);
        }

        public static bool IsSocialSecurityNumberValid(string ssn)
        {
            if (string.IsNullOrWhiteSpace(ssn))
            {
                return false;
            }

            if (!ssn.All(char.IsDigit))
            {
                return false;
            }

            bool isValid = ssn.Length == 9
                && ssn.Substring(0, 1) != "9"
                && ssn.Substring(0, 3) != "000"
                && ssn.Substring(0, 3) != "666"
                && ssn.Substring(3, 2) != "00"
                && ssn.Substring(5, 4) != "0000";

            return isValid;
        }

        public static bool IsPhoneNumberValid(string phoneNumber)
        {
            var regex = @"^\(?(20[0-9]|2[1-9][0-9]|[3-9][0-9]{2})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$";
            Match match = Regex.Match(phoneNumber, regex, RegexOptions.IgnoreCase);

            return match.Success;
        }

        public static bool IsEmailValid(string  email)
        {
            var regex = @"^[A-Za-z0-9_\+-]+(\.[A-Za-z0-9_\+-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*\.([A-Za-z]{2,4})$";
            Match match = Regex.Match(email, regex, RegexOptions.IgnoreCase);

            return match.Success;
        }
    }
}
