﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld.Common.Helpers
{
    public class PasswordHelper
    {
        public static bool IsPasswordInvalid(string password)
        {
            if (string.IsNullOrEmpty(password)
                || password.Length < 8
                || !password.Any(char.IsUpper)
                || !password.Any(char.IsLower)
                || !password.Any(char.IsNumber)
                || password.All(ch => Char.IsLetterOrDigit(ch)))
            {
                return true;
            }

            return false;
        }

        public static string GenerateRandomPassword()
        {
            int length = 10;
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
            var random = new Random();
            
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
