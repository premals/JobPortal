﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld.Common.Helpers
{
    public class DateHelper
    { 
        /// <summary>
        /// This method is intended to be used to offset the DateTime from UTC to Local DateTime
        /// </summary>
        /// <param name="dateTime">The UTC DateTime to convert</param>
        /// <param name="timeZoneInfo">Represents the Store's Configured Time Zone</param>
        /// <returns> Returns the Local DateTime </returns>
        public static DateTime OffsetDateTimeFromUtcToLocal(DateTime dateTime, TimeZoneInfo timeZoneInfo)
        {
            return TimeZoneInfo.ConvertTimeFromUtc(dateTime, timeZoneInfo ?? TimeZoneInfo.Local);
        }

        public static DateTime OffsetDateTimeToUtcFromLocal(DateTime dateTime, TimeZoneInfo timeZoneInfo)
        {
            return TimeZoneInfo.ConvertTimeToUtc(dateTime, timeZoneInfo ?? TimeZoneInfo.Local);
        }

        public static TimeZoneInfo GetTimeZoneInfo(string timeZoneId)
        {
            return TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
        }

        public static bool IsValidDate(DateTime? date, DateTime minDate, bool allowFutureDate = true, bool allowNullDate = true)
        {
            DateTime minSqlServerDate = new DateTime(1753, 1, 1);

            if (!date.HasValue)
            {
                return allowNullDate;
            }

            if (date < minSqlServerDate)
            {
                return false;
            }

            return date > minDate && (allowFutureDate == true ? true : date.Value.Date <= DateTime.Now.Date);
        }
    }
}
