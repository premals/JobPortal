﻿using BlazorApp.Services;
using HelloWorld.Common.Enumerations;
using HelloWorld.Common.Helpers;
using HelloWorld.Model.DataTables;
using HelloWorld.Common.Constants;
using WebhookApp.Controllers;
using Integration.PCC.Response;
using Integration.PCC;
using HelloWorld.EntityFramework.Interfaces;
using Insight.Common.Services;
using static HelloWorld.Common.Constants.Constants;

namespace WebhookApp.Services
{
    public class PccWebhookService
    {
        public readonly IConfiguration _configuration;
        public readonly HttpClient _client;
        public readonly ILogger<PccIntegrationController> _logger;
        public string _connectionString;
        public string _accessToken;
        public string _orgUuid;
        public EndpointService _endpointService;
        public FacilityPayerCodeService _facilityPayerCodeService;
        public ResidentService _residentService;

        public PccWebhookService(ILogger<PccIntegrationController> logger, IConfiguration configuration
            , HttpClient client, string connectionString, string accessToken, string orgUuid, IConfigRepository configRepository)
        {
            _configuration = configuration;
            _logger = logger;
            _client = client;
            _connectionString = connectionString;
            _accessToken = accessToken;
            _orgUuid = orgUuid;
            _endpointService = new EndpointService(orgUuid, accessToken, client, configRepository);
            _facilityPayerCodeService = new FacilityPayerCodeService(connectionString);
            _residentService = new ResidentService(_connectionString);
        }

        /// <summary>
        /// Check if PointClickCare Patient has Medicaid payer type
        ///     If yes, add to Insight if they do not exist already
        /// </summary>
        /// <param name="patientId"></param>
        /// <param name="addResidentIfMissing"></param>
        /// <returns></returns>
        public async Task AddUpdateMedicaidResident(int patientId, ResidentUserDefinedFieldsMap map, bool addResidentIfMissing = true)
        {
            List<string> userDefinedFields = new List<string>();

            if (map?.RecertificationDate != null)
            {
                userDefinedFields.Add(map.RecertificationDate);
            }

            if (map?.MedicaidApprovedDate != null)
            {
                userDefinedFields.Add(map.MedicaidApprovedDate);
            }

            var existingResident = _residentService.GetByPccPatientId(Convert.ToInt32(patientId));
            var pccPatient = Task.Run(async () => await GetPccPatient(patientId, userDefinedFields)).Result;

            if (pccPatient == null)
            {
                _logger.LogInformation($"Patient {patientId} cannot be found in GetPccPatient.");
                return;
            }

            var coverages = await GetCoverages(patientId);

            //BB - We don't have a resident in Insight that is already synced
            if (existingResident == null)
            {
                //BB - Try to find a resident by resident number first and then by first, last, dob
                existingResident = FindResidentMatch(pccPatient);

                if (existingResident != null)
                {
                    await UpdateResident(pccPatient, existingResident, coverages, map);
                }
                else
                {
                    if (string.Equals(pccPatient.patientStatus, "CURRENT", StringComparison.OrdinalIgnoreCase) 
                        && addResidentIfMissing == true)
                    {
                        await SaveNewResident(pccPatient, coverages, map);
                    }
                }
            }
            else
            {
                await UpdateResident(pccPatient, existingResident, coverages, map);
            }
        }

        private async Task UpdateResident(PccPatientResponse pccPatient, Resident resident, PccCoveragesResponse coverages, ResidentUserDefinedFieldsMap map)
        {
            var adtRecords = Task.Run(async () => await GetAdtRecords(pccPatient.patientId)).Result;

            SetResidentInfoFromPcc(pccPatient, resident, adtRecords);
            SetUserDefinedFields(pccPatient, resident, map);
            SetDemographics(pccPatient, resident);
            UpdateResidentPayers(resident, coverages, adtRecords);
            SetCloseCase(resident, adtRecords);
            SetPccWebhookModification(resident);
            resident.UpdatedBy = 0;
            resident.UpdatedDate = DateTime.UtcNow;
            _residentService.Update(resident);
        }

        public async Task SaveNewResident(PccPatientResponse pccPatient, PccCoveragesResponse coverages, ResidentUserDefinedFieldsMap map)
        {
            var residentService = new ResidentService(_connectionString);

            var patientFound = residentService.GetByPccPatientId(pccPatient.patientId);

            if (patientFound != null)
            {
                _logger.LogInformation($"Patient {pccPatient.patientId} already exists: {pccPatient.firstName} {pccPatient.lastName}.");
                return;
            }

            var facilityService = new FacilityService(_connectionString);
            var facility = facilityService.GetByExternalFacilityId(pccPatient.facId);

            if (facility == null)
            {
                _logger.LogInformation($"{pccPatient.facId} could not be found.");
                return;
            }

            var adtRecords = await GetAdtRecords(pccPatient.patientId);

            List<int> payerLevelsToInclude = new List<int>()
            { 
                1 
            };

            if (facility.IncludeSecondaryPayer)
            {
                payerLevelsToInclude.Add(2);
            }

            if (facility.IncludeTertiaryPayer)
            {
                payerLevelsToInclude.Add(3);
            }

            if (facility.IncludeFourthPayer)
            {
                payerLevelsToInclude.Add(4);
            }

            if (facility.IncludeFifthPayer)
            {
                payerLevelsToInclude.Add(5);
            }

            if (adtRecords != null && HasMatchingPayerCode(facility, coverages, adtRecords))
            {
                var payers = new List<PccPayer>();

                if (coverages != null)
                {
                    payers = coverages.Payers;
                }

                var resident = new Resident
                {
                    FacilityId = facility.Id
                };
                SetResidentInfoFromPcc(pccPatient, resident, adtRecords);
                SetUserDefinedFields(pccPatient, resident, map);
                SetDemographics(pccPatient, resident);
                SetPccWebhookModification(resident);
                resident.CreatedBy = 0;
                resident.CreatedDate = DateTime.UtcNow;
                var newResident = residentService.Add(resident);
                AddResidentPayerCodes(newResident, payers, adtRecords);
            }
        }

        private bool HasMatchingPayerCode(Facility facility, PccCoveragesResponse coverages, List<AdtRecords> adtRecords)
        {
            var facilityPayerCodes = _facilityPayerCodeService.GetByFacilityId(facility.Id).OrderBy(x => x.Code).ToList();

            if (!coverages.Payers.Any())
            {
                //use the most recent ADT record with a Payer Code to see if they have a matching payer code
                var mostRecentCensusWithPayerCode = adtRecords.Where(x => x.PayerCode != null).FirstOrDefault();

                if (mostRecentCensusWithPayerCode != null)
                {
                    return facilityPayerCodes.Any(x => string.Equals(x.Code, mostRecentCensusWithPayerCode.PayerCode, StringComparison.OrdinalIgnoreCase));
                }
                else
                {
                    return false;
                }
            }

            //Primary
            var payer = coverages.Payers.Where(x => string.Equals(x.PayerRank, ResidentPayerRank.Primary, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            if (payer != null)
            {
                if (facilityPayerCodes.Any(x => string.Equals(x.Code, payer.PayerCode, StringComparison.OrdinalIgnoreCase)))
                {
                    return true;
                }
            }

            if (facility.IncludeSecondaryPayer)
            {
                payer = coverages.Payers.Where(x => string.Equals(x.PayerRank, ResidentPayerRank.Secondary, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (payer != null)
                {
                    if (facilityPayerCodes.Any(x => string.Equals(x.Code, payer.PayerCode, StringComparison.OrdinalIgnoreCase)))
                    {
                        return true;
                    }
                }
            }

            if (facility.IncludeTertiaryPayer)
            {
                payer = coverages.Payers.Where(x => string.Equals(x.PayerRank, ResidentPayerRank.Tertiary, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (payer != null)
                {
                    if (facilityPayerCodes.Any(x => string.Equals(x.Code, payer.PayerCode, StringComparison.OrdinalIgnoreCase)))
                    {
                        return true;
                    }
                }
            }

            if (facility.IncludeFourthPayer)
            {
                payer = coverages.Payers.Where(x => string.Equals(x.PayerRank, ResidentPayerRank.Fourth, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (payer != null)
                {
                    if (facilityPayerCodes.Any(x => string.Equals(x.Code, payer.PayerCode, StringComparison.OrdinalIgnoreCase)))
                    {
                        return true;
                    }
                }
            }

            if (facility.IncludeFifthPayer)
            {
                payer = coverages.Payers.Where(x => string.Equals(x.PayerRank, ResidentPayerRank.Fifth, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (payer != null)
                {
                    if (facilityPayerCodes.Any(x => string.Equals(x.Code, payer.PayerCode, StringComparison.OrdinalIgnoreCase)))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private void AddResidentPayerCodes(Resident resident, List<PccPayer> payers, List<AdtRecords> adtRecords)
        {
            if (payers.Any())
            {
                foreach (var payer in payers)
                {
                    switch (payer.PayerRank.ToUpper())
                    {
                        case ResidentPayerRank.Primary:
                            {
                                var residentPayer = new ResidentPayer()
                                {
                                    ResidentId = resident.Id,
                                    PayerRank = 1,
                                    PayerName = payer.PayerName,
                                    PayerCode = payer.PayerCode
                                };

                                _residentService.AddResidentPayer(residentPayer);

                                break;
                            }
                        case ResidentPayerRank.Secondary:
                            {
                                var residentPayer = new ResidentPayer()
                                {
                                    ResidentId = resident.Id,
                                    PayerRank = 2,
                                    PayerName = payer.PayerName,
                                    PayerCode = payer.PayerCode
                                };

                                _residentService.AddResidentPayer(residentPayer);

                                break;
                            }
                        case ResidentPayerRank.Tertiary:
                            {
                                var residentPayer = new ResidentPayer()
                                {
                                    ResidentId = resident.Id,
                                    PayerRank = 3,
                                    PayerName = payer.PayerName,
                                    PayerCode = payer.PayerCode
                                };

                                _residentService.AddResidentPayer(residentPayer);

                                break;
                            }
                        case ResidentPayerRank.Fourth:
                            {
                                var residentPayer = new ResidentPayer()
                                {
                                    ResidentId = resident.Id,
                                    PayerRank = 4,
                                    PayerName = payer.PayerName,
                                    PayerCode = payer.PayerCode
                                };

                                _residentService.AddResidentPayer(residentPayer);

                                break;
                            }
                        case ResidentPayerRank.Fifth:
                            {
                                var residentPayer = new ResidentPayer()
                                {
                                    ResidentId = resident.Id,
                                    PayerRank = 5,
                                    PayerName = payer.PayerName,
                                    PayerCode = payer.PayerCode
                                };

                                _residentService.AddResidentPayer(residentPayer);

                                break;
                            }
                        default:
                            {
                                break;
                            }
                    }
                }
            }
            else
            {
                var mostRecentCensusWithPayerCode = adtRecords.Where(x => x.PayerCode != null).OrderByDescending(x => Convert.ToDateTime(x.EffectiveDateTime)).FirstOrDefault();

                if (mostRecentCensusWithPayerCode != null)
                {
                    var residentPayer = new ResidentPayer()
                    {
                        ResidentId = resident.Id,
                        PayerRank = 1,
                        PayerName = mostRecentCensusWithPayerCode.PayerName,
                        PayerCode = mostRecentCensusWithPayerCode.PayerCode
                    };

                    _residentService.AddResidentPayer(residentPayer);
                }
            }
        }

        private void UpdateResidentPayers(Resident resident, PccCoveragesResponse coverages, List<AdtRecords> adtRecords)
        {
            var payers = new List<PccPayer>();

            if (coverages == null || !coverages.Payers.Any())
            {
                var mostRecentCensusWithPayerCode = adtRecords.Where(x => x.PayerCode != null).OrderByDescending(x => Convert.ToDateTime(x.EffectiveDateTime)).FirstOrDefault();

                if (mostRecentCensusWithPayerCode != null)
                {
                    payers.Add(new PccPayer()
                    {
                        PayerCode = mostRecentCensusWithPayerCode.PayerCode,
                        PayerName = mostRecentCensusWithPayerCode.PayerName
                    });
                }
            }
            else
            {
                payers = coverages.Payers;
            }

            var currentPayers = _residentService.GetResidentPayers(resident.Id);

            foreach (var currentPayer in currentPayers)
            {
                switch (currentPayer.PayerRank)
                {
                    case 1:
                        {
                            var payer = payers.FirstOrDefault(x => string.Equals(x.PayerRank, ResidentPayerRank.Primary, StringComparison.OrdinalIgnoreCase));
                            if (payer != null)
                            {
                                currentPayer.PayerName = payer.PayerName;
                                currentPayer.PayerCode = payer.PayerCode;
                                _residentService.UpdateResidentPayer(currentPayer);
                            }
                            else
                            {
                                _residentService.DeleteResidentPayer(currentPayer);                            
                            }
                            break;
                        }
                    case 2:
                        {
                            var payer = payers.FirstOrDefault(x => string.Equals(x.PayerRank, ResidentPayerRank.Secondary, StringComparison.OrdinalIgnoreCase));
                            if (payer != null)
                            {
                                currentPayer.PayerName = payer.PayerName;
                                currentPayer.PayerCode = payer.PayerCode;
                                _residentService.UpdateResidentPayer(currentPayer);
                            }
                            else
                            {
                                _residentService.DeleteResidentPayer(currentPayer);
                            }
                            break;
                        }
                    case 3:
                        {
                            var payer = payers.FirstOrDefault(x => string.Equals(x.PayerRank, ResidentPayerRank.Tertiary, StringComparison.OrdinalIgnoreCase));
                            if (payer != null)
                            {
                                currentPayer.PayerName = payer.PayerName;
                                currentPayer.PayerCode = payer.PayerCode;
                                _residentService.UpdateResidentPayer(currentPayer);
                            }
                            else
                            {
                                _residentService.DeleteResidentPayer(currentPayer);
                            }
                            break;
                        }
                    case 4:
                        {
                            var payer = payers.FirstOrDefault(x => string.Equals(x.PayerRank, ResidentPayerRank.Fourth, StringComparison.OrdinalIgnoreCase));
                            if (payer != null)
                            {
                                currentPayer.PayerName = payer.PayerName;
                                currentPayer.PayerCode = payer.PayerCode;
                                _residentService.UpdateResidentPayer(currentPayer);
                            }
                            else
                            {
                                _residentService.DeleteResidentPayer(currentPayer);
                            }
                            break;
                        }
                    case 5:
                        {
                            var payer = payers.FirstOrDefault(x => string.Equals(x.PayerRank, ResidentPayerRank.Fifth, StringComparison.OrdinalIgnoreCase));
                            if (payer != null)
                            {
                                currentPayer.PayerName = payer.PayerName;
                                currentPayer.PayerCode = payer.PayerCode;
                                _residentService.UpdateResidentPayer(currentPayer);
                            }
                            else
                            {
                                _residentService.DeleteResidentPayer(currentPayer);
                            }
                            break;
                        }
                }
            }

            //Need to see if we need to add any. 
            currentPayers = _residentService.GetResidentPayers(resident.Id);
            List<PccPayer> payersToUpdate = new List<PccPayer>();

            if (payers.Any(x => string.Equals(x.PayerRank, ResidentPayerRank.Primary, StringComparison.OrdinalIgnoreCase)) && !currentPayers.Any(x => x.PayerRank == 1))
            {
                payersToUpdate.Add(payers.First(x => string.Equals(x.PayerRank, ResidentPayerRank.Primary, StringComparison.OrdinalIgnoreCase)));
            }

            if (payers.Any(x => string.Equals(x.PayerRank, ResidentPayerRank.Secondary, StringComparison.OrdinalIgnoreCase)) && !currentPayers.Any(x => x.PayerRank == 2))
            {
                payersToUpdate.Add(payers.First(x => string.Equals(x.PayerRank, ResidentPayerRank.Secondary, StringComparison.OrdinalIgnoreCase)));
            }

            if (payers.Any(x => string.Equals(x.PayerRank, ResidentPayerRank.Tertiary, StringComparison.OrdinalIgnoreCase)) && !currentPayers.Any(x => x.PayerRank == 3))
            {
                payersToUpdate.Add(payers.First(x => string.Equals(x.PayerRank, ResidentPayerRank.Tertiary, StringComparison.OrdinalIgnoreCase)));
            }

            if (payers.Any(x => string.Equals(x.PayerRank, ResidentPayerRank.Fourth, StringComparison.OrdinalIgnoreCase)) && !currentPayers.Any(x => x.PayerRank == 4))
            {
                payersToUpdate.Add(payers.First(x => string.Equals(x.PayerRank, ResidentPayerRank.Fourth, StringComparison.OrdinalIgnoreCase)));
            }

            if (payers.Any(x => string.Equals(x.PayerRank, ResidentPayerRank.Fifth, StringComparison.OrdinalIgnoreCase)) && !currentPayers.Any(x => x.PayerRank == 5))
            {
                payersToUpdate.Add(payers.First(x => string.Equals(x.PayerRank, ResidentPayerRank.Fifth, StringComparison.OrdinalIgnoreCase)));
            }

            if (payersToUpdate.Any())
            {
                AddResidentPayerCodes(resident, payersToUpdate, adtRecords);
            }
        }

        public async Task<PccPatientResponse> GetPccPatient(int pccPatientId, List<string> userDefinedFields)
        {
            var pccPatient = new PccPatientResponse();
            try
            {
                var baseUrl = _configuration["PccIntegration:EndPoint"];
                pccPatient = await _endpointService.GetPatient(pccPatientId, baseUrl, userDefinedFields);
                _logger.LogInformation($"pccPatient with name {pccPatient.firstName} {pccPatient.lastName}");
            }
            catch (Exception ex) 
            {
                var message = $"Error: Get Patient Endpoint - PCC Patient ID {pccPatient.patientId}, facility ID: {pccPatient.facId}. Error: {ex.Message}";
                throw new Exception(message);
            }

            return pccPatient;
        }

        private async Task<List<AdtRecords>> GetAdtRecords(int pccPatientId)
        {
            var adtRecords = new List<AdtRecords>();

            try
            {
                var url = _configuration["PccIntegration:AdtRecords"];
                adtRecords = await _endpointService.GetAdtRecords(pccPatientId, url);
            }
            catch (Exception ex)
            {
                if (ex.Message == "Resource not found.")
                {
                    return adtRecords;
                }

                throw new Exception($"Error: Get AdtRecords Endpoint - PCC Patient ID {pccPatientId}. Error: {ex.Message}");
            }

            return adtRecords;
        }

        private async Task<PccCoveragesResponse> GetCoverages(int pccPatientId)
        {
            var response = new PccCoveragesResponse();

            try
            {
                var url = _configuration["PccIntegration:Coverages"];
                response = await _endpointService.GetCoverages(pccPatientId, url);
            }
            catch (Exception ex)
            {
                if (ex.Message == "Resource not found.")
                {
                    return response;
                }

                throw new Exception($"Error: Get AdtRecords Endpoint - PCC Patient ID {pccPatientId}. Error: {ex.Message}");
            }

            return response;
        }

        private void SetPccWebhookModification(Resident resident)
        {
            resident.UpdatedBy = 0;
            resident.UpdatedDate = DateTime.UtcNow;
        }

        private Resident? FindResidentMatch(PccPatientResponse pccPatient)
        {
            Resident? existingResident = null;
            var residentService = new ResidentService(_connectionString);
            var facilityService = new FacilityService(_connectionString);
            var facility = facilityService.GetByExternalFacilityId(pccPatient.facId);
            if (facility != null)
            {
                existingResident = residentService.GetByResidentNumber(pccPatient.patientExternalId, facility.Id);
                if (existingResident == null)
                {
                    existingResident = residentService.GetMatch(pccPatient.firstName, pccPatient.lastName, Convert.ToDateTime(pccPatient.birthDate), facility.Id);
                }
            }
           
            return existingResident;
        }

        public void SetDemographics(PccPatientResponse patient, Resident resident)
        {
            resident.FirstName = patient.firstName ?? "";
            resident.LastName = patient.lastName ?? "";
            resident.MiddleInitial = string.IsNullOrEmpty(patient.middleName) ? null : patient.middleName.Substring(0, 1);
            resident.DateOfBirth = string.IsNullOrEmpty(patient.birthDate) ? null : Convert.ToDateTime(patient.birthDate);
            resident.SocialSecurityNumber = !string.IsNullOrEmpty(patient.socialBeneficiaryIdentifier) ? CryptographyHelper.Encrypt(patient.socialBeneficiaryIdentifier) : "";
            resident.AddressLine1 = patient.legalMailingAddress.addressLine1 ?? "";
            resident.AddressLine2 = patient.legalMailingAddress.addressLine2 ?? "";
            resident.StateCode = patient.legalMailingAddress.state ?? "";
            resident.Zip = !string.IsNullOrWhiteSpace(patient.legalMailingAddress.postalCode) 
                ? patient.legalMailingAddress.postalCode.Length < 5 
                    ? patient.legalMailingAddress.postalCode 
                    : patient.legalMailingAddress.postalCode.Substring(0, 5) 
                : string.Empty;
            resident.City = patient.legalMailingAddress.city ?? "";

            var phoneNumber = patient.homePhone?.Replace("-", "").Replace("(", "").Replace(")", "").Replace(" ", "").Trim();
            resident.Phone = phoneNumber?.Length == 10 ? phoneNumber : null;

            resident.Email = patient.email ?? "";
            resident.MedicaidNumber = patient.medicaidNumber ?? "";
            resident.GenderId = 0;
            resident.GenderDescription = patient.gender;
            resident.ResidentNumber = patient.patientExternalId;
            resident.MaritalStatusDescription = patient.maritalStatus;
            resident.MaritalStatusId = 0;
            resident.LanguageDescription = patient.languageDesc;
            resident.PlanType = (int)MmaType.MMA;
        }

        private void SetResidentInfoFromPcc(PccPatientResponse patient, Resident resident, List<AdtRecords> adtRecords)
        {
            var adtRecord = adtRecords.FirstOrDefault() ?? new AdtRecords();
            resident.PccId = patient.patientId;
            resident.AdmissionDate = string.IsNullOrEmpty(patient.admissionDate) ? null : Convert.ToDateTime(patient.admissionDate);

            if (patient.patientStatus == "Discharged")
            {
                resident.ResidentStatusId = (int)ResidentStatuses.Discharged;
                resident.DischargeLocation = adtRecord.DestinationType;
                resident.DischargeDate = string.IsNullOrEmpty(patient.dischargeDate) ? null : Convert.ToDateTime(patient.dischargeDate);
            }
            else
            {
                resident.ResidentStatusId = patient.patientStatus == "Current" ? (int)ResidentStatuses.Resident : (int)ResidentStatuses.PendingAdmission;
                resident.DischargeDate = null;
                resident.DischargeLocation = null;
            }
        }

        private void SetUserDefinedFields(PccPatientResponse patient, Resident resident, ResidentUserDefinedFieldsMap map)
        {
            if (patient.userDefinedFields != null && patient.userDefinedFields.Count > 0)
            {
                if (!string.IsNullOrEmpty(map?.RecertificationDate))
                {
                    var recertDateValue = patient.userDefinedFields.FirstOrDefault(x => x.name == map.RecertificationDate);

                    if (recertDateValue != null)
                    {
                        DateTime recertDate;

                        if (DateTime.TryParse(recertDateValue.description, out recertDate))
                        {
                            resident.RecertificationDate = recertDate;
                        }
                    }
                }
            }
        }
        
        /// <summary>
        /// Close Case for Resident when there is no Admission type (includes Readmission)
        /// </summary>
        /// <param name="resident"></param>
        /// <param name="adtRecords"></param>
        private void SetCloseCase(Resident resident, List<AdtRecords> adtRecords)
        {
            var medicaidPayerCodes = _facilityPayerCodeService.GetByFacilityId(resident.FacilityId, (int)PayerCodeTypeEnum.Medicaid).OrderBy(x => x.Code).ToList();
            var mostRecentCensus = adtRecords.FirstOrDefault();
            var mostRecentCensusWithPayerCode = adtRecords.Where(x => x.PayerCode != null).FirstOrDefault();

            if (resident.IsDeleted && !medicaidPayerCodes.Any(x => string.Equals(x.Code, mostRecentCensusWithPayerCode?.PayerCode, StringComparison.OrdinalIgnoreCase)))
            {
                return;
            }

            if (!adtRecords.Any(x => x.StandardActionType == "Admission"))
            {
                resident.IsDeleted = true;
                return;
            }

            if (mostRecentCensus != null 
                && mostRecentCensus?.StandardActionType == "Death"
                && mostRecentCensusWithPayerCode != null 
                && medicaidPayerCodes.Any(x => string.Equals(x.Code, mostRecentCensusWithPayerCode?.PayerCode, StringComparison.OrdinalIgnoreCase)))
            {
                resident.IsDeleted = true;
                return;
            }

            resident.IsDeleted = false;
        }
    }
}
