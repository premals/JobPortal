using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using BlazorApp.Services.Interfaces;
using BlazorApp.Services;
using System.Security.Cryptography.X509Certificates;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using System.Text;
using HelloWorld.EntityFramework;
using HelloWorld.EntityFramework.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Logging.AddApplicationInsights(
        configureTelemetryConfiguration: (config) =>
            config.ConnectionString = builder.Configuration.GetConnectionString("APPLICATIONINSIGHTS_CONNECTION_STRING"),
            configureApplicationInsightsLoggerOptions: (options) => { }
    );

var configuration = builder.Configuration;
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddTransient<ITenantService, TenantService>();
builder.Services.AddTransient<IConfigRepository, ConfigRepository>();

builder.Services.AddTransient<IConfiguration>(_ => builder.Configuration);

builder.Services.AddDbContext<HelloWorldTenantContext>(options =>
              options.UseSqlServer(configuration.GetConnectionString("HelloWorldTenantContext"))); ;

builder.Services.AddDbContext<HelloWorldConfigContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("HelloWorldConfigContext")));

var kvUri = configuration.GetSection("AzureKeyVaultUri").Value;
var certName = configuration.GetSection("CertificateName").Value;

if (kvUri == null)
{
    throw new Exception("Could not retrieve AzureKeyVaultUri.");
}

if (certName == null)
{
    throw new Exception("Could not retrieve certName.");
}

var secretClient = new SecretClient(new Uri(kvUri ?? ""), new DefaultAzureCredential());

var response = secretClient.GetSecret(certName);
var keyVaultSecret = response?.Value;

if (keyVaultSecret == null)
{
    throw new Exception("Could not find certificate.");
}

var privateKeyBytes = Convert.FromBase64String(keyVaultSecret.Value);
var clientCertificate = new X509Certificate2(privateKeyBytes);

builder.Services.AddHttpClient("namedClient", c =>
{
}).ConfigurePrimaryHttpMessageHandler(() =>
{
    var handler = new HttpClientHandler();
    handler.ClientCertificates.Add(clientCertificate);
    return handler;
});

var basicTokenResponse = secretClient.GetSecret("rs-pcc-basic-token");
var basicToken = basicTokenResponse?.Value.Value;

configuration["PccIntegration:BasicToken"] = basicToken;

var usernameResponse = secretClient.GetSecret("rs-pcc-webhook-username");
var webhookUsername = usernameResponse?.Value.Value;

var pwdResponse = secretClient.GetSecret("rs-pcc-webhook-pwd");
var webhookPassword = pwdResponse?.Value.Value;

configuration["PccIntegration:WhUsername"] = webhookUsername;
configuration["PccIntegration:WhPassword"] = webhookPassword;

configuration["PccIntegration:WebhookSecret"] = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{webhookUsername}:{webhookPassword}"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();

app.Run();