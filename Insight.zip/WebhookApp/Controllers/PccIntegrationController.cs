using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using BlazorApp.Services.Interfaces;
using Microsoft.SqlServer.Dac.Model;
using Integration.PCC;
using Integration.PCC.Payload;
using Integration.PCC.Response;
using System.Net.Http.Headers;
using WebhookApp.Services;
using HelloWorld.EntityFramework.Interfaces;
using BlazorApp.Services;
using HelloWorld.Model.DataTables;
using Insight.Common.Services;

namespace WebhookApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PccIntegrationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _clientFactory;
        private readonly ILogger<PccIntegrationController> _logger;
        private readonly ITenantService _tenantService;
        public readonly IConfigRepository _configRepository;
        private const int ResultOk = 200;
        private const int ResultBad = 400;
        private const int ResultUnauthorized = 401;

        public PccIntegrationController(ILogger<PccIntegrationController> logger, IConfiguration configuration, ITenantService tenantService, IConfigRepository configRepository, IHttpClientFactory clientFactory)
        {
            _configuration = configuration;
            _logger = logger;
            _tenantService = tenantService;
            _clientFactory = clientFactory;
            _configRepository = configRepository;
        }

        [HttpPost("SyncPatient")]
        public async Task<IActionResult> SyncPatient([FromBody]PccPayload payload)
        {

            var rateLimit = _configRepository.GetRateLimit(HelloWorld.Common.Enumerations.RateLimitEntity.PointClickCare);

            if (rateLimit == null)
            {
                _logger.LogInformation("Unable to get rate limit for PCC");
                return BadRequest("Unable to get rate limit for PCC");
            }

            if (rateLimit.TimeToReset != null)
            {
                if (rateLimit.TimeToReset > DateTime.UtcNow)
                {
                    _logger.LogInformation("Rate limit has been reached.");
                    return BadRequest("Rate limit has been reached.");
                }
                else
                {
                    rateLimit.TimeToReset = null;
                    _configRepository.UpdateRateLimit(rateLimit);
                }
            }

            _logger.LogInformation($"{payload.PatientId} - {payload.OrgUuid} - {payload.FacId} - {payload.MessageId} - {payload.MessageDate} - {payload.EventType}");
            var authResult = GetAuthorization(Request);

            if (authResult != ResultOk)
            {
                switch (authResult)
                {
                    case ResultBad:
                        return BadRequest("Authorization is missing or has the wrong type");
                    case ResultUnauthorized:
                        return Unauthorized("Request not authorized");
                    default:
                        break;
                }
            }

            try
            {
                if (payload != null)
                {
                    if (string.IsNullOrEmpty(payload.OrgUuid))
                    {
                        throw new Exception("OrgUuid is required");
                    }

                    var data = new[] { new KeyValuePair<string, string>("grant_type", "client_credentials") };
                    var content = new FormUrlEncodedContent(data);
                    var request = new HttpRequestMessage(HttpMethod.Post, "https://connect.pointclickcare.com/auth/token");

                    request.Headers.Add("Authorization", $"Basic {_configuration["PccIntegration:BasicToken"]}");
                    request.Content = content;

                    var client = _clientFactory.CreateClient("namedClient");

                    var response = await client.SendAsync(request);
                    var pccAccessResponse = new PccAccessResponse();
                    if (response.IsSuccessStatusCode)
                    {
                        using var responseStream = await response.Content.ReadAsStreamAsync();
                        pccAccessResponse = await JsonSerializer.DeserializeAsync<PccAccessResponse>(responseStream);
                    }

                    if (pccAccessResponse != null)
                    {
                        var connectionString = GetTenantConnectionString(payload.OrgUuid);

                        var pccService = new PccWebhookService(_logger, _configuration, client, connectionString, pccAccessResponse.access_token, payload.OrgUuid, _configRepository);

                        //Get UDFs
                        var residentUdfService = new ResidentUserDefinedFieldsMapService(connectionString);
                        var facilityService = new FacilityService(connectionString);

                        var facility = facilityService.GetByExternalFacilityId(payload.FacId);

                        ResidentUserDefinedFieldsMap map = new ResidentUserDefinedFieldsMap();

                        if (facility != null)
                        {
                            map = residentUdfService.GetFieldsByFacilityId(facility.Id);
                        }

                        //End Get UDFs

                        var pccPatient = new PccPatientResponse();
                        switch (payload.EventType)
                        {
                            case PccEventType.AdmitPatient:
                            case PccEventType.UpdateAccount:
                            {
                                await pccService.AddUpdateMedicaidResident(payload.PatientId, map, true);
                                break;
                            }
                            case PccEventType.ReadmitPatient:
                            case PccEventType.UpdateResidentInfo:
                            case PccEventType.UpdateAccountOnReturnFromLeave:
                            case PccEventType.CancelAdmit:
                            case PccEventType.cancelDischarge:
                            case PccEventType.Discharge:
                            {
                                await pccService.AddUpdateMedicaidResident(payload.PatientId, map, false);
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"payload: Message ID: {payload.MessageId} - Patient ID: {payload.PatientId} - Facility ID: {payload.FacId} - Org Uuid: {payload.OrgUuid} - Event Type: {payload.EventType}. Error: {ex.Message}");
                return BadRequest(new { message = ex.Message });
            }

            return Ok();
        }

        private int GetAuthorization(HttpRequest request)
        {
            var secret = _configuration.GetSection("PccIntegration:WebhookSecret").Value;
            _logger.LogInformation($"Getting Auth with secret - {secret}");

            int result;

            if (request != null)
            {
                var authHeader = AuthenticationHeaderValue.Parse(request.Headers["Authorization"]);

                if (authHeader != null && authHeader.Scheme == "Basic")
                {
                    if (authHeader.Parameter != null && authHeader.Parameter.Equals(secret, StringComparison.Ordinal))
                    {
                        _logger.LogInformation($"Request has been authorized");
                        result = ResultOk;
                    }
                    else
                    {
                        result = ResultUnauthorized;
                    }

                }
                else
                {
                    result = ResultBad;
                }
            }
            else
            {
                result = ResultBad;
            }

            return result;
        }

        private string GetTenantConnectionString(string orgUuid)
        {
            var pccIntegration = _configRepository.GetPccIntegration(orgUuid);
            if (pccIntegration == null) return string.Empty;

            var tenant = _tenantService.Get(pccIntegration.TenantId);
            if (tenant == null) return string.Empty;

            return _tenantService.GetConnectionString(tenant.DatabaseName);
        }
    }
}