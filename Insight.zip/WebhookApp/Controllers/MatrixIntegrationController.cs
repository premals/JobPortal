﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.SqlServer.Dac.Model;
using NHapi.Base.Model;
using NHapi.Base.Parser;
using System.Text;
using Integration.Matrix;

namespace WebhookApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MatrixIntegrationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _clientFactory;
        private readonly ILogger<MatrixIntegrationController> _logger;
        private readonly ITenantService _tenantService;
        public readonly IConfigRepository _configRepository;
        private const int ResultOk = 200;
        private const int ResultBad = 400;
        private const int ResultUnauthorized = 401;
        public MatrixIntegrationController(ILogger<MatrixIntegrationController> logger, IConfiguration configuration, ITenantService tenantService, IConfigRepository configRepository, IHttpClientFactory clientFactory)
        {
            _configuration = configuration;
            _logger = logger;
            _tenantService = tenantService;
            _clientFactory = clientFactory;
            _configRepository = configRepository;
        }

        [HttpPost("Webhook")]
        public async Task<IActionResult> Webhook()
        {

            Request.EnableBuffering(); // Allows re-reading the stream
            
            string hl7Raw;
            using (var reader = new StreamReader(Request.Body, Encoding.UTF8, leaveOpen: true))
            {
                hl7Raw = await reader.ReadToEndAsync();
                Request.Body.Position = 0; // Reset stream position for potential further use
            }

            //USE FOR DEBUGGING SANDBOX ONLY - DO NOT USE FOR PROD AS IT CONTAINS PHI

            // Parse the HL7 message
            var parser = new PipeParser();
            IMessage message;
            try
            {
                message = parser.Parse(hl7Raw);
            }
            catch (Exception ex)
            {
                return BadRequest($"HL7 parsing failed: {ex.Message}");
            }

            string controlId = GetControlId(hl7Raw) ?? "UNKNOWN";

            string ackMessage = $"MSH|^~\\&|Insight|Facility|MatrixCare|Sandbox|{DateTime.Now:yyyyMMddHHmmss}||ACK^A01|{controlId}|P|2.5\r" +
                                $"MSA|AA|{controlId}\r";

            //Directly grab event type from the message structure
            var msh = (message.GetStructure("MSH") as NHapi.Model.V25.Segment.MSH);
            string negAckMessage = "MSH|^~\\&|YourSystem|YourFacility|Matrix|999999|<timestamp>||ACK^A08|<msgId>|P|2.5\r\nMSA|AE|<msgId>\r\nERR|||207^Application internal error^HL70357|E|Missing patient identifier";

            if (msh == null)
            {
                return Content(negAckMessage, "text/plain");
            }

            if (msh.SendingFacility.NamespaceID.Value == "999999" && msh.SendingFacility.UniversalID?.Value == "MatrixCare Center")
            {
                LogSandboxRequest(hl7Raw, Request.Headers);

            }
            else
            {
                string extenalPatientId = "";
                // Split into segments
                string[] segments = hl7Raw.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

                // Find PID segment
                string pidSegment = segments.FirstOrDefault(s => s.StartsWith("PID"));

                if (pidSegment != null)
                {
                    string[] fields = pidSegment.Split('|');

                    // PID-2 is field index 2 (0-based index)
                    extenalPatientId = fields.Length > 2 ? fields[2] : "";
                }
                else
                {
                    _logger.LogWarning("PID segment not found.");
                }

                _logger.LogInformation("Received HL7 message: Type={0}, Event: {1}, ControlID={2}, From={3}, Resident: {5}",
                                            msh.MessageType.MessageCode.Value,
                                            msh.MessageType.TriggerEvent.Value,
                                            msh.MessageControlID.Value,
                                                msh.SendingFacility.UniversalID?.Value,
                                                extenalPatientId
                                        );

            }

            string? eventType = msh?.MessageType?.TriggerEvent?.Value;
            
            if (string.IsNullOrWhiteSpace(eventType))
            {
                _logger.LogError("Failed to process message {0}.Type={1}. From={2}. Error: {3}", 
                        msh.MessageControlID.Value,
                        msh.MessageType.MessageCode.Value,
                        msh.SendingFacility.UniversalID?.Value,
                        "Event type is missing.");
                negAckMessage = $"MSH|^~\\&|YourSystem|{msh?.SendingFacility.UniversalID?.Value}|Matrix|{msh?.SendingFacility.NamespaceID.Value}|<timestamp>||ACK^A08|<msgId>|P|2.5\r\nMSA|AE|<msgId>\r\nERR|||207^Application internal error^HL70357|E|Event type is missing.";

                return Content(negAckMessage, "text/plain");
            }

            var sendingFacility = msh.SendingFacility;

            // MSH-4.1: Namespace ID (Facility Code)
            string facilityCode = sendingFacility.NamespaceID.Value;

            // MSH-4.2: Universal ID (Facility Name or global identifier)
            string facilityName = sendingFacility.UniversalID.Value;

            var client = _clientFactory.CreateClient("namedClient");
            var matrixIntegration = _configRepository.GetMatrixIntegration(facilityCode, facilityName);
            if (matrixIntegration == null)
            {
                var errorMessage = $"Unable to locate Matrix Integration for Facility Code: {facilityCode}, Facility Name: {facilityName}";
                _logger.LogError(errorMessage);
                negAckMessage = $"MSH|^~\\&|YourSystem|{msh?.SendingFacility.UniversalID?.Value}|Matrix|{msh?.SendingFacility.NamespaceID.Value}|<timestamp>||ACK^A08|<msgId>|P|2.5\r\nMSA|AE|<msgId>\r\nERR|||207^Application internal error^HL70357|E|{errorMessage}";

                return Content(negAckMessage, "text/plain");
            }

            if (matrixIntegration.IsEnabled)
            {
                var connectionString = GetTenantConnectionString(matrixIntegration.TenantId);

                var matrixService = new MatrixWebhookService(connectionString, _configRepository);
                try
                {
                    matrixService.ProcessEvent(message, matrixIntegration.FacilityId);
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Failed to process message {msh.MessageControlID.Value}. Type={msh.MessageType.MessageCode.Value}. From={msh.SendingFacility.UniversalID?.Value}. Facility Name {facilityName}. Error: {ex.InnerException?.Message ?? ex.Message}");

                    negAckMessage = $"MSH|^~\\&|YourSystem|{msh?.SendingFacility.UniversalID?.Value}|Matrix|{msh?.SendingFacility.NamespaceID.Value}|<timestamp>||ACK^A08|<msgId>|P|2.5\r\nMSA|AE|<msgId>\r\nERR|||207^Application internal error^HL70357|E|{ex.InnerException?.Message ?? ex.Message}";

                    return Content(negAckMessage, "text/plain");

                }
            }
            else
            {
                _logger.LogWarning($"Matrix Integration Not Enabled for Facility Code: {facilityCode}, Facility Name: {facilityName}, Sending Facility: {sendingFacility}");
            }

            return Content(ackMessage, "text/plain");
        }

        private void LogSandboxRequest(string body, IHeaderDictionary headers)
        {
            _logger.LogInformation($"Timestamp: {DateTime.Now} - HL7 Message: {body}");
        }

        private string? GetControlId(string hl7Message)
        {
            // Tries to extract control ID from MSH segment (field 10)
            var lines = hl7Message.Split('\r');
            var msh = lines.FirstOrDefault(l => l.StartsWith("MSH"));
            if (msh != null)
            {
                var parts = msh.Split('|');
                if (parts.Length > 9)
                    return parts[9]; // control ID is field 10
            }
            return null;
        }

        private string GetTenantConnectionString(int tenantId)
        {          

            var tenant = _tenantService.Get(tenantId);
            if (tenant == null) return string.Empty;

            return _tenantService.GetConnectionString(tenant.DatabaseName);
        }
    }
}
