﻿using System;
using System.Collections.Generic;
using System.Linq;
using HelloWorld.Models;
using HelloWorld.Common.Helpers;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;

namespace HelloWorld.Services
{
    public class EmployeesService
    {
        private readonly HelloWorldTenantContext _context;

        public EmployeesService(HelloWorldTenantContext context)
        {
            _context = context;
        }

        public bool EmployeeExists(int id)
        {
            return _context.Employee.Any(e => e.Id == id);
        }
    }
}
