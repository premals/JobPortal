﻿using System;
using HelloWorld.Models;
using HelloWorld.Common.Helpers;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;

namespace HelloWorld.Services
{
    public class ResidentRegistrationService
    {
        private readonly HelloWorldTenantContext _context;

        public ResidentRegistrationService(HelloWorldTenantContext context)
        {
            _context = context;
        }

        public void CreateResidentRegistration(ResidentRegistrationModel resident)
        {
            resident.GenderId = Convert.ToInt32(resident.SelectedGenderId);
            resident.MaritalStatusId = Convert.ToInt32(resident.SelectedMaritalStatusId);
            resident.RegistrationDate = DateTime.UtcNow; //Eventually will need to look up based on Location Time Zone
            resident.ResidentStatusId = (int)ResidentStatus.Pending;
            resident.CreatedBy = 1; //Eventually will need to save on User Session
            resident.CreatedDate = DateTime.UtcNow; //Eventually will need to look up based on Location Time Zone
            resident.Phone = UtilityHelper.FormatPhoneNumber(resident.Phone);
            resident.MedicaidApplicationDate = null;
            //resident.LocationId  //Need to assign this to the User Session Location once Location is finished

            _context.Add(resident);
            _context.SaveChanges();
        }
    }
}
