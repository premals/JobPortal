﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelloWorld.EntityFramework.Context;

namespace HelloWorld.Services
{
    public class FacilityService
    {
        private readonly HelloWorldTenantContext _context;

        public FacilityService(HelloWorldTenantContext context)
        {
            _context = context;
        }

        public bool LocationExists(int id)
        {
            return _context.Facility.Any(e => e.Id == id);
        }
    }
}
