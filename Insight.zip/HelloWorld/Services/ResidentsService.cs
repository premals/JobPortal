﻿using System;
using HelloWorld.Models;
using HelloWorld.Common.Helpers;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;
using System.Linq;

namespace HelloWorld.Services
{
    public class ResidentsService
    {
        private readonly HelloWorldTenantContext _context;

        public ResidentsService(HelloWorldTenantContext context)
        {
            _context = context;
        }

        public bool ResidentExists(int id)
        {
            return _context.Resident.Any(e => e.Id == id);
        }
    }
}
