﻿using HelloWorld.Model.DataTables;

namespace HelloWorld.Models
{
    public class LocationWebModel : Facility
    {
        public string DivisionName { get; set; }
    }
}
