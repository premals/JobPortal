﻿using System;
using System.ComponentModel.DataAnnotations;
using HelloWorld.Model.DataTables;
using System.Collections.Generic;

namespace HelloWorld.Models
{
    public class EmployeeViewModel : Employee
    {
        public EmployeeViewModel()
        {
            Facilities = new List<Facility>();
        }

        [Display(Name = "Last Login")]
        public string LastLoginDateTimeDisplay
        {
            get
            {
                if (LastLoginDateTime == null)
                {
                    return string.Empty;
                }
                var lastLoginDateTime = (DateTime)LastLoginDateTime;
                return lastLoginDateTime.ToString("yyyy-MM-dd");
            }
        }

        [Display(Name = "Password Last Changed")]
        public string PasswordLastChangedDisplay
        {
            get
            {
                if (PasswordLastChanged == null)
                {
                    return string.Empty;
                }
                var passwordLastChanged = (DateTime)PasswordLastChanged;
                return passwordLastChanged.ToString("yyyy-MM-dd");
            }
        }

        [Display(Name = "Is System Admin User?")]
        public bool IsSystemAdmin { get; set; }

        public bool SystemOptionIsUsingRegions { get; set; }

        public List<Region> Regions { get; set; }

        public List<Facility> Facilities { get; set; }

        public void CastToViewModel(Employee employee)
        {
            Id = employee.Id;
            DefaultFacilityId = employee.DefaultFacilityId;
            FirstName = employee.FirstName;
            LastName = employee.LastName;
            HireDate = employee.HireDate;
            TerminationDate = employee.TerminationDate;           
            Email = employee.Email;
            OptIntoEmail = employee.OptIntoEmail;
            RoleId = employee.RoleId;
            Username = employee.Username;
            Password = employee.Password;
            PasswordQuestion = employee.PasswordQuestion;
            PasswordAnswer = employee.PasswordAnswer;
            IsActive = employee.IsActive;
            IsPasswordPermanent = employee.IsPasswordPermanent;
            IsAccountLocked = employee.IsAccountLocked;
            IsChangePasswordOnNextLogin = employee.IsChangePasswordOnNextLogin;
            LastLoginDateTime = employee.LastLoginDateTime;
            PasswordLastChanged = employee.PasswordLastChanged;
            UnsuccessfulLoginAttempts = employee.UnsuccessfulLoginAttempts;
            OptIntoEmail = employee.OptIntoEmail;
        }
    }
}
