﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using HelloWorld.Common.Enumerations;
using HelloWorld.Model.DataTables;

namespace HelloWorld.Models
{
    public class ResidentRegistrationModel : Resident
    {
        public ResidentRegistrationModel()
        {
            GenerateGenderList();
            GenerateMartialStatusList();
            GenerateStatesList();
            GenerateLanguagesList();
        }

        [Required]
        [Display(Name = "Gender")]
        public List<SelectListItem> Genders { get; set; }
        
        [Required]
        [Display(Name = "Gender")]
        public string SelectedGenderId { get; set; }

        [Required]
        [Display(Name = "State")]
        public List<SelectListItem> States { get; set; }

        [Required]
        [Display(Name = "Marital Status")]
        public List<SelectListItem> MaritalStatuses { get; set; }

        [Required]
        [Display(Name = "Marital Status")]
        public string SelectedMaritalStatusId { get; set; }

        [Display(Name = "Primary Language")]
        public List<SelectListItem> Languages { get; set; }

        [Display(Name = "Primary Language")]
        public string SelectedLanguageId { get; set; }


        private void GenerateGenderList()
        {
            Genders = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (Gender gender in Enum.GetValues(typeof(Gender)))
            {
                Genders.Add(new SelectListItem { Text = gender.ToString(), Value = Convert.ToString((int)gender), Selected = false });
            }
        }

        private void GenerateMartialStatusList()
        {
            MaritalStatuses = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (MaritalStatus maritalStatus in Enum.GetValues(typeof(MaritalStatus)))
            {
                MaritalStatuses.Add(new SelectListItem { Text = maritalStatus.ToString(), Value = Convert.ToString((int)maritalStatus), Selected = false });
            }
        }

        private void GenerateStatesList()
        {
            States = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (State state in Enum.GetValues(typeof(State)))
            {
                States.Add(new SelectListItem { Text = state.ToString(), Value = state.ToString(), Selected = false });
            }
        }
        private void GenerateLanguagesList()
        {
            Languages = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (Languages language in Enum.GetValues(typeof(Languages)))
            {
                Languages.Add(new SelectListItem { Text = language.ToString(), Value = language.ToString(), Selected = false });
            }
        }
    }
}
