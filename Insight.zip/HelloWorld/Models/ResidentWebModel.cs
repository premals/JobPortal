﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using HelloWorld.Common.Enumerations;
using HelloWorld.Model.DataTables;


namespace HelloWorld.Models
{
    public class ResidentWebModel : Resident
    {
        public ResidentWebModel()
        {
            GenerateResidentStatusesList();
            GenerateGenderList();
            GenerateMartialStatusList();
            GenerateStatesList();
            GenerateLanguagesList();
        }

        [Required]
        [Display(Name = "Gender")]
        public List<SelectListItem> Genders { get; set; }

        [Required]
        [Display(Name = "Gender")]
        public string SelectedGenderId { get; set; }

        [Required]
        [Display(Name = "State")]
        public List<SelectListItem> States { get; set; }

        [Required]
        [Display(Name = "Marital Status")]
        public List<SelectListItem> MaritalStatuses { get; set; }

        [Required]
        [Display(Name = "Marital Status")]
        public string SelectedMaritalStatusId { get; set; }

        [Display(Name = "Primary Language")]
        public List<SelectListItem> Languages { get; set; }

        [Display(Name = "Primary Language")]
        public string SelectedLanguageId { get; set; }

        [Display(Name = "Resident Status")]
        public List<SelectListItem> ResidentStatuses { get; set; }
       
        [Display(Name = "Resident Status")]
        public string SelectedResidentStatusId { get; set; }

        private void GenerateResidentStatusesList()
        {
            ResidentStatuses = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (ResidentStatus status in Enum.GetValues(typeof(ResidentStatus)))
            {
                ResidentStatuses.Add(new SelectListItem { Text = status.ToString(), Value = Convert.ToString((int)status), Selected = ResidentStatusId == (int)status });
            }
        }

        private void GenerateGenderList()
        {
            Genders = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (Gender gender in Enum.GetValues(typeof(Gender)))
            {
                Genders.Add(new SelectListItem { Text = gender.ToString(), Value = Convert.ToString((int)gender), Selected = GenderId == (int)gender });
            }
        }

        private void GenerateMartialStatusList()
        {
            MaritalStatuses = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (MaritalStatus maritalStatus in Enum.GetValues(typeof(MaritalStatus)))
            {
                MaritalStatuses.Add(new SelectListItem { Text = maritalStatus.ToString(), Value = Convert.ToString((int)maritalStatus), Selected = MaritalStatusId == (int)maritalStatus });
            }
        }

        private void GenerateStatesList()
        {
            States = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (State state in Enum.GetValues(typeof(State)))
            {
                States.Add(new SelectListItem { Text = state.ToString(), Value = state.ToString(), Selected = StateCode == state.ToString() });
            }
        }

        private void GenerateLanguagesList()
        {
            Languages = new List<SelectListItem>
            {
                new SelectListItem {  Text = "-- Select --", Value = "", Selected = true }
            };

            foreach (Languages language in Enum.GetValues(typeof(Languages)))
            {
                Languages.Add(new SelectListItem { Text = language.ToString(), Value = Convert.ToString((int)language), Selected = PrimaryLanguageId == (int)language });
            }
        }

        public void CastToViewModel(Resident resident)
        {
            Id = resident.Id;
            ResidentNumber = resident.ResidentNumber;
            FirstName = resident.FirstName;
            MiddleInitial = resident.MiddleInitial;
            LastName = resident.LastName;
            DateOfBirth = resident.DateOfBirth;
            GenderId = resident.GenderId;
            MaritalStatusId = resident.MaritalStatusId;
            ResidentStatusId = resident.ResidentStatusId;
            AddressLine1 = resident.AddressLine1;
            AddressLine2 = resident.AddressLine2;
            City = resident.City;
            StateCode = resident.StateCode;
            Zip = resident.Zip;
            Phone = resident.Phone;
            PhoneExt = resident.PhoneExt;
            Email = resident.Email;
            FacilityId = resident.FacilityId;
            MedicaidApplicationDate = resident.MedicaidApplicationDate;
            RegistrationDate = resident.RegistrationDate;
            SocialSecurityNumber = resident.SocialSecurityNumber;
            PrimaryLanguageId = resident.PrimaryLanguageId;
            Facility = new Facility
            {
                Name = resident.Facility.Name
            };
        }
    }
}
