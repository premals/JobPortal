﻿using System;
using System.Collections.Generic;
using HelloWorld.Model.DataTables;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace HelloWorld.Models
{
    public class FacilityWebModel : Facility
    {
        [Display(Name = "Time Zone")]
        public List<SelectListItem> TimeZones { get; set; }

        public void CastToViewModel(Facility facility)
        {
            Id = facility.Id;
            RegionId = facility.RegionId;
            Name = facility.Name;
            AddressLine1 = facility.AddressLine1;
            AddressLine2 = facility.AddressLine2;
            City = facility.City;
            State = facility.State;
            Zip = facility.Zip;
            PrimaryPhone = facility.PrimaryPhone;
            PrimaryPhoneExt = facility.PrimaryPhoneExt;
            SecondaryPhone = facility.SecondaryPhone;
            SecondaryPhoneExt = facility.SecondaryPhoneExt;
            Fax = facility.Fax;
            Email = facility.Email;
            IsActive = facility.IsActive;
            TimeZoneId = facility.TimeZoneId;
            IsDstObserved = facility.IsDstObserved;
            TimeZones = GetTimeZones();
        }

        private List<SelectListItem> GetTimeZones()
        {
            var timeZones = new List<SelectListItem>();
            foreach (var zone in TimeZoneInfo.GetSystemTimeZones())
            {
                timeZones.Add(new SelectListItem() { Text = zone.DisplayName, Value = zone.Id, Selected = !string.IsNullOrEmpty(TimeZoneId) ? true : false });
            }

            return timeZones;
        }
    }
}
