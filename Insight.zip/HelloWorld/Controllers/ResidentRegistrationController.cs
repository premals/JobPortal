﻿using Microsoft.AspNetCore.Mvc;
using System;
using HelloWorld.Models;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Services;

namespace HelloWorld.Controllers
{
    public class ResidentRegistrationController : Controller
    {
        private readonly HelloWorldTenantContext _context;

        public ResidentRegistrationController(HelloWorldTenantContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Add New Resident from Application
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            var newResident = new ResidentRegistrationModel();

            return View(newResident);
        }

        // POST: ResidentRegistration/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]     
        public IActionResult Index(ResidentRegistrationModel resident)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var residentRegistrationService = new ResidentRegistrationService(_context);
                    residentRegistrationService.CreateResidentRegistration(resident);
                }
                catch (Exception ex)
                {
                    return View(resident);
                }

                return View("RegistrationConfirmation");
            }

            return View(resident);
        }
    }
}
