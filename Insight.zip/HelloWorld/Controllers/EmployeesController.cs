﻿using System;
using System.Linq;
using System.Threading.Tasks;
using HelloWorld.Services;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using HelloWorld.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HelloWorld.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly HelloWorldTenantContext _context;
        private readonly EmployeesService _employeesService;
        public EmployeesController(HelloWorldTenantContext context)
        {
            _context = context;
            _employeesService = new EmployeesService(_context);
        }

        // GET: Employees
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, string search2String, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = string.IsNullOrEmpty(sortOrder) ? "name_desc" : "";

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentStatusFilter"] = search2String;

            var employees = from s in _context.Employee.Include(x => x.Facility.Region)
                        select s;

            if (!string.IsNullOrEmpty(searchString))
            {
                employees = employees.Where(s => s.LastName.StartsWith(searchString)
                                       || s.FirstName.StartsWith(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    employees = employees.OrderByDescending(s => s.LastName);
                    break;
                default:
                    employees = employees.OrderBy(s => s.LastName);
                    break;
            }

            int pageSize = 5;
            return View(await PaginatedList<Employee>.CreateAsync(employees.AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        // GET: Employees
        [HttpGet]
        [Route("Getv2")]
        public async Task<ActionResult<PaginatedList<Employee>>> Get(int? pageNumber, string sortField, string sortOrder)
        {
            var employees = from s in _context.Employee.Include(x => x.Facility.Region)
                            select s;
                      
            switch (sortOrder)
            {
                case "name_desc":
                    employees = employees.OrderByDescending(s => s.LastName);
                    break;
                default:
                    employees = employees.OrderBy(s => s.LastName);
                    break;
            }

            int pageSize = 5;
            return await PaginatedList<Employee>.CreateAsync(employees.AsNoTracking(), pageNumber ?? 1, pageSize);
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
            return View(new EmployeeViewModel { IsActive = true, IsPasswordPermanent = true });
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmployeeViewModel employee)
        {
            if (ModelState.IsValid)
            {
                if (employee.IsSystemAdmin)
                {
                    employee.RoleId = (int)Roles.SystemAdmin;
                }
                else
                {
                    employee.RoleId = (int)Roles.User;
                }

                var employees = from s in _context.Employee.Where(x => x.Username == employee.Username)
                                select s;

                if (employees.Any())
                {
                    ModelState.AddModelError("Username", "Username must be unique");
                    return View(employee);
                }

                employee.DefaultFacilityId = 3;
                employee.CreatedDate = DateTime.UtcNow;
                employee.CreatedBy = 1;

                _context.Add(employee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Create));
            }

            return View(employee);
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            EmployeeViewModel evm = new EmployeeViewModel();
            evm.CastToViewModel(employee);

            //var currentTenant = _context.Tenant.FirstOrDefault();
            //evm.IsUsingRegions = currentTenant == null ? true : currentTenant.IsUsingRegion;
            evm.SystemOptionIsUsingRegions = true;

            if (evm.SystemOptionIsUsingRegions)
            {
                evm.Regions = _context.Region.Include("Facilities").ToList();
                evm.Facilities = _context.Facility.Where(x=>x.RegionId == 0).ToList();
            }
            else
            {
                evm.Facilities = _context.Facility.ToList();
            }

            return View(evm);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, EmployeeViewModel employee)
        {
            if (id != employee.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var employees = from s in _context.Employee.Where(x => x.Username == employee.Username && x.Id != employee.Id)
                                select s;

                if (employees.Any())
                {
                    ModelState.AddModelError("Username", "Username must be unique");
                    return View(employee);
                }

                if (employee.IsSystemAdmin)
                {
                    employee.RoleId = (int)Roles.SystemAdmin;
                }
                else
                {
                    employee.RoleId = (int)Roles.User;
                }

                try
                {
                    employee.UpdatedBy = 1;
                    employee.UpdatedDate = DateTime.UtcNow;

                    _context.Entry(employee).Property(x => x.CreatedBy).IsModified = false;
                    _context.Entry(employee).Property(x => x.CreatedDate).IsModified = false;

                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_employeesService.EmployeeExists(employee.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            return View(employee);
        }
    }
}
