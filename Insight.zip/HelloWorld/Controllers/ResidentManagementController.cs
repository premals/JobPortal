﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace HelloWorld.Controllers
{
    public class ResidentManagementController : Controller
    {
        /// <summary>
        /// Landing Page for Resident Management
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Manage existing resident information
        /// </summary>
        /// <returns></returns>
        public IActionResult ManageResident()
        {
            return View();
        }

        /// <summary>
        /// Search for Resident
        /// </summary>
        /// <returns></returns>
        //public IActionResult SearchResident(string sortOrder = "")
        //{
        //    ViewData["NameSortParm"] = string.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
        //    ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

        //    var resident = new List<NewResident>
        //    {
        //        new NewResident { Id  = 1, ResidentNumber = 12345, FirstName = "Shira",  LastName = "Neumann", CreatedDate = DateTime.UtcNow},
        //        new NewResident { Id = 5, ResidentNumber = 22222, FirstName = "Bill", LastName = "Brannan", CreatedDate = DateTime.UtcNow}
        //    };

        //    switch (sortOrder)
        //    {
        //        case "name_desc":
        //            resident = resident.OrderByDescending(s => s.LastName).ToList();
        //            break;
        //        case "Date":
        //            resident = resident.OrderBy(s => s.CreatedDate).ToList();
        //            break;
        //        case "date_desc":
        //            resident = resident.OrderByDescending(s => s.CreatedDate).ToList();
        //            break;
        //        default:
        //            resident = resident.OrderBy(s => s.LastName).ToList();
        //            break;
        //    }
        //    return View(resident);
        //}
    }
}
