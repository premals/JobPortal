﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HelloWorld.Model.DataTables;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Services;
using HelloWorld.Models;

namespace HelloWorld.Controllers
{
    public class FacilityController : Controller
    {
        private readonly HelloWorldTenantContext _context;
        private readonly FacilityService _facilityService;

        public FacilityController(HelloWorldTenantContext context)
        {
            _context = context;
            _facilityService = new FacilityService(_context);
        }

        // GET: Locations
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, string search2String, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = string.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentStatusFilter"] = search2String;

            var facilities = from s in _context.Facility
                            select s;

            if (!string.IsNullOrEmpty(searchString))
            {
                facilities = facilities.Where(s => s.Name.StartsWith(searchString)
                                       || s.Name.StartsWith(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    facilities = facilities.OrderByDescending(s => s.Name);
                    break;
                default:
                    facilities = facilities.OrderBy(s => s.Name);
                    break;
            }

            int pageSize = 5;
            return View(await PaginatedList<Facility>.CreateAsync(facilities.AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        // GET: Locations/Create
        public IActionResult Create()
        {
            var facility = new FacilityWebModel
            {
                IsActive = true,
                TimeZones = new List<SelectListItem>(),
                IsDstObserved = true,
            };

            foreach (var zone in TimeZoneInfo.GetSystemTimeZones())
            {
                facility.TimeZones.Add(new SelectListItem() { Text = zone.DisplayName, Value = zone.Id });
            }

            return View(facility);
        }

        // POST: Locations/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(FacilityWebModel location)
        {
            if (ModelState.IsValid)
            {
                location.CreatedBy = 1; //current session user id
                location.CreatedDate = DateTime.UtcNow;
                location.RegionId = 1; //current session region id

                _context.Add(location);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(location);
        }

        // GET: Facility/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var facility = await _context.Facility.FindAsync(id);
            if (facility == null)
            {
                return NotFound();
            }

            var facilityViewModel = new FacilityWebModel();
            facilityViewModel.CastToViewModel(facility);

            return View(facilityViewModel);
        }

        // POST: Facility/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, FacilityWebModel facility)
        {
            if (id != facility.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(facility);
                    _context.Entry(facility).Property(x => x.RegionId).IsModified = false;
                    _context.Entry(facility).Property(x => x.CreatedBy).IsModified = false;
                    _context.Entry(facility).Property(x => x.CreatedDate).IsModified = false;
                    facility.UpdatedDate = DateTime.UtcNow;
                    facility.UpdatedBy = 1;

                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_facilityService.LocationExists(facility.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(facility);
        }
    }
}
