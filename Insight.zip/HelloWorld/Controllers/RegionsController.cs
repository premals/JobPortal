﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using HelloWorld.Models;

namespace HelloWorld.Controllers
{
    public class RegionsController : Controller
    {
        private readonly HelloWorldTenantContext _context;

        public RegionsController(HelloWorldTenantContext context)
        {
            _context = context;
        }

        // GET: Regions
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = string.IsNullOrEmpty(sortOrder) ? "name_desc" : "";

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewData["CurrentFilter"] = searchString;

            var regions = from s in _context.Region
                            select s;

            if (!string.IsNullOrEmpty(searchString))
            {
                regions = regions.Where(s => s.Name.StartsWith(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    regions = regions.OrderByDescending(s => s.Name);
                    break;
                default:
                    regions = regions.OrderBy(s => s.Name);
                    break;
            }

            int pageSize = 5;
            return View(await PaginatedList<Region>.CreateAsync(regions.AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        // GET: Regions/Create
        public IActionResult Create()
        {
            return View(new Region { IsActive = true });
        }

        // POST: Regions/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,TenantId,Name,IsActive")] Region region)
        {
            if (ModelState.IsValid)
            {
                region.CreatedBy = 1;
                region.CreatedDate = DateTime.UtcNow;

                _context.Add(region);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(region);
        }

        // GET: Regions/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var region = await _context.Region.FindAsync(id);
            if (region == null)
            {
                return NotFound();
            }
            return View(region);
        }

        // POST: Regions/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,IsActive")] Region region)
        {
            if (id != region.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Entry(region).Property(x => x.TenantId).IsModified = false;
                    _context.Entry(region).Property(x => x.CreatedBy).IsModified = false;
                    _context.Entry(region).Property(x => x.CreatedDate).IsModified = false;

                    region.UpdatedBy = 1;
                    region.UpdatedDate = DateTime.UtcNow;

                    _context.Update(region);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RegionExists(region.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(region);
        }

        private bool RegionExists(int id)
        {
            return _context.Region.Any(e => e.Id == id);
        }
    }
}
