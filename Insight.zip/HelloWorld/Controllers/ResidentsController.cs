﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HelloWorld.Model.DataTables;
using HelloWorld.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using HelloWorld.Common.Enumerations;
using HelloWorld.Services;

namespace HelloWorld.Controllers
{
    public class ResidentsController : Controller
    {
        private readonly EntityFramework.Context.HelloWorldTenantContext _context;
        private readonly ResidentsService _residentsService;

        public ResidentsController(EntityFramework.Context.HelloWorldTenantContext context)
        {
            _context = context;
            _residentsService = new ResidentsService(_context);
        }

        // GET: Residents
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, string search2String, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = string.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentStatusFilter"] = search2String;

            var residentStatus = new List<SelectListItem>();

            foreach (ResidentStatus status in Enum.GetValues(typeof(ResidentStatus)))
            {
                residentStatus.Add(new SelectListItem { Text = status.ToString(), Value = status.ToString(), Selected = false });
            }

            ViewBag.ResidentStatus = residentStatus;

            var residents = from s in _context.Resident.Include(x => x.Facility)
                           select s;

            if (!string.IsNullOrEmpty(searchString))
            {
                residents = residents.Where(s => s.LastName.StartsWith(searchString)
                                       || s.FirstName.StartsWith(searchString));
            }

            //if (!string.IsNullOrEmpty(search2String))
            //{
            //    residents = residents.Where(s => s.ResidentStatusName.Contains(search2String));
            //}

            switch (sortOrder)
            {
                case "name_desc":
                    residents = residents.OrderByDescending(s => s.LastName);
                    break;
                case "Date":
                    residents = residents.OrderBy(s => s.MedicaidApplicationDate);
                    break;
                case "date_desc":
                    residents = residents.OrderByDescending(s => s.MedicaidApplicationDate);
                    break;
                default:
                    residents = residents.OrderBy(s => s.LastName);
                    break;
            }

            
            int pageSize = 5;
            return View(await PaginatedList<Resident>.CreateAsync(residents.AsNoTracking(), pageNumber ?? 1, pageSize));
        }

        // GET: Residents/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var resident = await _context.Resident
                .FirstOrDefaultAsync(m => m.Id == id);
            if (resident == null)
            {
                return NotFound();
            }

            return View(resident);
        }

        // GET: Residents/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Residents/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ResidentNumber,FirstName,MiddleInitial,LastName,DateOfBirth,GenderId,MaritalStatusId,AddressLine1,AddressLine2,City,State,Zip,Phone,PhoneExt,Email,ResidentStatusId,LocationId,MedicaidApplicationDate,RegistrationDate,SocialSecurityNumber,CreatedBy,CreatedDate,UpdatedBy,UpdatedDate")] Resident resident)
        {
            if (ModelState.IsValid)
            {
                _context.Add(resident);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(resident);
        }

        // GET: Residents/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var resident = await _context.Resident.Include("Facility").SingleOrDefaultAsync(r => r.Id == id);

            if (resident == null)
            {
                return NotFound();
            }

            var residentViewModel = new ResidentWebModel();
            residentViewModel.CastToViewModel(resident);

            return View(residentViewModel);
        }

        // POST: Residents/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ResidentNumber,FirstName,MiddleInitial,LastName,DateOfBirth,GenderId,MaritalStatusId,AddressLine1,AddressLine2,City,State,Zip,Phone,PhoneExt,Email,ResidentStatusId,LocationId,MedicaidApplicationDate,RegistrationDate,SocialSecurityNumber,CreatedBy,CreatedDate,UpdatedBy,UpdatedDate")] Resident resident)
        {
            if (id != resident.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(resident);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_residentsService.ResidentExists(resident.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(resident);
        }
     
    }
}
