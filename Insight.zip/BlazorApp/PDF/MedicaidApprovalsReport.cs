﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BlazorApp.Data;
using HelloWorld.Model.DataTables;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace BlazorApp.PDF
{
    public class MedicaidApprovalsReport
    {
        public static PdfPTable GenerateHeader(PdfWriter writer, Document document, DateTime? startDate, DateTime? endDate, Facility facility)
        {
            float[] headerWidths = { 30, 40, 30 };
            PdfPTable table = new PdfPTable(1);
            table.WidthPercentage = 100;
            PdfPTable table2 = new PdfPTable(3);
            table2.SetWidths(headerWidths);

            var leftBlockText = new System.Text.StringBuilder();
            leftBlockText.AppendLine(facility.Name);
            leftBlockText.AppendLine(facility.AddressLine1);
            leftBlockText.AppendLine($"{facility.City}, {facility.StateCode}, {facility.Zip}");

            //Left Block
            PdfPCell cell2 = new PdfPCell(new Phrase(leftBlockText.ToString()));
            cell2.Border = 0;
            cell2.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(cell2);

            //Center (Title) Block
            cell2 = new PdfPCell();
            cell2.Border = 0;
            Paragraph para = new Paragraph();
            para.Alignment = Element.ALIGN_CENTER;

            PdfPTable table3 = new PdfPTable(1);
            table3.WidthPercentage = 100;
            PdfPCell cell3 = new PdfPCell();
            cell3.Border = 0;

            Chunk title = new Chunk("Medicaid Approvals Report", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 20, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE));
            para.Add(title);
            cell3.AddElement(para);
            table3.AddCell(cell3);
            table3.CompleteRow();

            string titleText = "";

            if (startDate == null && endDate == null)
            {
                titleText = "";
            }

            if (startDate == null && endDate != null)
            {
                titleText = $"Up until {Convert.ToDateTime(endDate).ToShortDateString()}";
            }

            if (startDate != null && endDate == null)
            {
                titleText = $"Starting from {Convert.ToDateTime(endDate).ToShortDateString()}";
            }

            if (startDate != null && endDate != null)
            {
                titleText = $"{Convert.ToDateTime(startDate).ToShortDateString()} to {Convert.ToDateTime(endDate).ToShortDateString()}";
            }

            para = new Paragraph();
            para.Alignment = Element.ALIGN_CENTER;
            title = new Chunk(titleText, new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 12, iTextSharp.text.Font.NORMAL));
            para.Add(title);
            cell3 = new PdfPCell();
            cell3.Border = 0;
            cell3.AddElement(para);
            table3.AddCell(cell3);
            table3.CompleteRow();

            cell2.AddElement(table3);
            table2.AddCell(cell2);

            //Daterun
            var runDate = DateTime.Now;
            cell2 = new PdfPCell(new Phrase($"Ran on: {runDate}", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
            cell2.BorderWidth = 0;
            cell2.HorizontalAlignment = Element.ALIGN_RIGHT;
            table2.AddCell(cell2);
            table2.CompleteRow();

            PdfPCell cell = new PdfPCell(table2);
            cell.PaddingBottom = 12;
            cell.BorderWidth = 0;
            cell.BackgroundColor = BaseColor.White;
            table.AddCell(cell);

            return table;
        }

        public static void CreateTable(Document pdf, PdfWriter writer, List<MedicaidApprovalsReportModel> residents, Facility facility)
        {
            iTextSharp.text.Font fontH1 = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.White);
            iTextSharp.text.Font fontDataCell = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.Black);
            var headerColor = new BaseColor(108, 145, 162);
            var h1Color = new BaseColor(80, 110, 124);
            var dataColor = new BaseColor(224, 232, 235);

            PdfPTable table = new PdfPTable(1);
            table.WidthPercentage = 100;

            PdfPTable headertable = new PdfPTable(3);
            float[] h1widths = { 19, 42, 39 };
            headertable.WidthPercentage = 100;
            headertable.SetWidths(h1widths);
            headertable.HorizontalAlignment = Element.ALIGN_CENTER;
            headertable.HeaderRows = 0;

            PdfPCell h1Cell = new PdfPCell();
            h1Cell.Border = 0;
            h1Cell.BackgroundColor = BaseColor.White;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            h1Cell = new PdfPCell(new Phrase("Medicaid", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.BorderColorLeft = BaseColor.White;
            h1Cell.BorderColorRight = BaseColor.White;
            h1Cell.BorderWidthLeft = .25F;
            h1Cell.BorderWidthTop = 0F;
            h1Cell.BorderWidthRight = .25F;
            h1Cell.BorderWidthBottom = 0F;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            h1Cell = new PdfPCell(new Phrase("Umed", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.Border = 0;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            PdfPCell mainCell = new PdfPCell(headertable);
            mainCell.Border = 0;
            table.AddCell(mainCell);

            PdfPTable dataTable = new PdfPTable(7);
            float[] headerWidths = { 19, 13, 13, 16, 14, 12, 13 };

            dataTable.WidthPercentage = 100;
            dataTable.SetWidths(headerWidths);
            dataTable.HorizontalAlignment = Element.ALIGN_LEFT;
            dataTable.HeaderRows = 1;

            PdfPCell headerCell = new PdfPCell(new Phrase("Name", fontH1));
            headerCell.BackgroundColor = headerColor;
            headerCell.BorderWidthLeft = .25F;
            headerCell.BorderColor = headerColor;
            headerCell.PaddingBottom = 5F;
            headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
            headerCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(headerCell);

            #region Medicaid

            headerCell = new PdfPCell(new Phrase("Application Date", fontH1));
            headerCell.BackgroundColor = headerColor;
            //headerCell.Border = 0;
            headerCell.BorderWidthLeft = .25F;
            headerCell.BorderWidthTop = 0F;
            headerCell.BorderWidthRight = 0F;
            headerCell.BorderWidthBottom = 0F;
            headerCell.BorderColor = BaseColor.White;
            headerCell.PaddingBottom = 5F;
            headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(headerCell);

            headerCell = new PdfPCell(new Phrase("Effective Date", fontH1));
            headerCell.BackgroundColor = headerColor;
            headerCell.Border = 0;
            headerCell.PaddingBottom = 5F;
            headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(headerCell);

            headerCell = new PdfPCell(new Phrase("Approval Amount", fontH1));
            headerCell.BackgroundColor = headerColor;
            headerCell.BorderWidthLeft = 0F;
            headerCell.BorderWidthTop = 0F;
            headerCell.BorderWidthRight = .25F;
            headerCell.BorderWidthBottom = 0F;
            headerCell.BorderColor = BaseColor.White;
            headerCell.PaddingBottom = 5F;
            headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(headerCell);

            #endregion

            #region Umed

            headerCell = new PdfPCell(new Phrase("Umed Needed?", fontH1));
            headerCell.BackgroundColor = headerColor;
            headerCell.Border = 0;
            headerCell.PaddingBottom = 5F;
            headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(headerCell);

            headerCell = new PdfPCell(new Phrase("Application Date", fontH1));
            headerCell.BackgroundColor = headerColor;
            headerCell.Border = 0;
            headerCell.PaddingBottom = 5F;
            headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(headerCell);

            headerCell = new PdfPCell(new Phrase("Requested Amount", fontH1));
            headerCell.BackgroundColor = headerColor;
            headerCell.BorderWidthRight = .25F;
            headerCell.BorderColor = headerColor;
            headerCell.PaddingBottom = 5F;
            headerCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(headerCell);

            #endregion

            for (int i = 0; i < residents.Count; i++)
            {
                var resident = residents[i];
                var backgroundColor = (i%2 == 0) ? BaseColor.White : dataColor;

                var cell = new PdfPCell(new Phrase($"{resident.ResidentFullName}", fontDataCell));
                cell.PaddingBottom = 5F;
                cell.BackgroundColor = backgroundColor;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                dataTable.AddCell(cell);

                #region Medicaid

                var medicaidAppDate = string.IsNullOrWhiteSpace(resident.MedicaidApplicationDate) ? string.Empty : Convert.ToDateTime(resident.MedicaidApplicationDate).ToShortDateString();
                cell = new PdfPCell(new Phrase(medicaidAppDate, fontDataCell));
                cell.PaddingBottom = 5F;
                cell.BackgroundColor = backgroundColor;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                dataTable.AddCell(cell);

                var medicaidEffectiveDate = string.IsNullOrWhiteSpace(resident.MedicaidEffectiveDate) ? string.Empty : Convert.ToDateTime(resident.MedicaidEffectiveDate).ToShortDateString();
                cell = new PdfPCell(new Phrase(medicaidEffectiveDate, fontDataCell));
                cell.PaddingBottom = 5F;
                cell.BackgroundColor = backgroundColor;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                dataTable.AddCell(cell);

                var medicaidApprovedAmt = !resident.MedicaidApprovedAmount.HasValue ? string.Empty : resident.MedicaidApprovedAmount?.ToString("C");
                cell = new PdfPCell(new Phrase(medicaidApprovedAmt, fontDataCell));
                cell.PaddingBottom = 5F;
                cell.BackgroundColor = backgroundColor;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                dataTable.AddCell(cell);

                #endregion

                #region Umed

                cell = new PdfPCell(new Phrase(resident.UmedNeeded, fontDataCell));
                cell.PaddingBottom = 5F;
                cell.BackgroundColor = backgroundColor;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                dataTable.AddCell(cell);

                var umedAppDate = string.IsNullOrWhiteSpace(resident.UmedApplicationDate) ? string.Empty : Convert.ToDateTime(resident.UmedApplicationDate).ToShortDateString();
                cell = new PdfPCell(new Phrase(umedAppDate, fontDataCell));
                cell.PaddingBottom = 5F;
                cell.BackgroundColor = backgroundColor;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                dataTable.AddCell(cell);

                var umedReqAmt = !resident.UmedRequestedAmount.HasValue ? string.Empty : resident.UmedRequestedAmount?.ToString("C");
                cell = new PdfPCell(new Phrase(umedReqAmt, fontDataCell));
                cell.PaddingBottom = 5F;
                cell.BackgroundColor = backgroundColor;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                dataTable.AddCell(cell);
                dataTable.CompleteRow();

                #endregion
            }

            var totalApprovalAmount = residents.Sum(x => x.MedicaidApprovedAmount != null ? x.MedicaidApprovedAmount : 0).Value.ToString("C");
            var isUmedApprovedCount = residents.Any(x => x.IsUmedApproved == true) ? residents.Where(x => x.IsUmedApproved == true).ToList().Count : 0;

            if (residents.Count == 1)
            {
                var numOfCols = dataTable.NumberOfColumns;

                var cell = new PdfPCell(new Phrase("", fontDataCell));
                cell.Border = 0;
                cell.BackgroundColor = BaseColor.White;

                for (int i = 0; i < numOfCols; i++)
                {
                    dataTable.AddCell(cell);
                }
            }

            var totalGain = 0.00M;

            foreach (var resident in residents)
            {
                var effectiveDate = DateTime.Parse(resident.MedicaidEffectiveDate);

                var days = (decimal)(DateTime.UtcNow - effectiveDate).TotalDays;

                totalGain += Decimal.Multiply(days, facility.DailyRate);
            }

            totalGain = Math.Round(totalGain, 2);

            var totalLoss = 0.00M;

            foreach (var resident in residents)
            {
                var effectiveDate = DateTime.Parse(resident.MedicaidEffectiveDate);

                if (resident.MedicaidRequestedEffectiveDate.HasValue && resident.MedicaidRequestedEffectiveDate.Value <= effectiveDate)
                {
                    var days = (decimal)(effectiveDate - resident.MedicaidRequestedEffectiveDate.Value).TotalDays;
                    totalLoss += Decimal.Multiply(days, facility.DailyRate);
                }
            }

            totalLoss = Math.Round(totalLoss, 2);

            iTextSharp.text.Font summaryFont = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.Black);

            var summaryCell = new PdfPCell(new Phrase($"", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.Colspan = 7;
            dataTable.AddCell(summaryCell);
            dataTable.CompleteRow();

            summaryCell = new PdfPCell(new Phrase($"Summary", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.Colspan = 2;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Approval Count", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Approval Amount", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Umed Completed", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Total Gain", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Total Loss", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);
            dataTable.CompleteRow();

            summaryCell = new PdfPCell(new Phrase($"", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.Colspan = 2;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase(residents.Count.ToString(), fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"{totalApprovalAmount}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"{isUmedApprovedCount}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            var gain = totalGain.ToString("C");
            summaryCell = new PdfPCell(new Phrase($"{gain}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            dataTable.AddCell(summaryCell);

            var loss = totalLoss.ToString("C");
            summaryCell = new PdfPCell(new Phrase($"{loss}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            dataTable.AddCell(summaryCell);
            dataTable.CompleteRow();

            mainCell = new PdfPCell(dataTable);
            mainCell.Border = 0;
            table.AddCell(mainCell);

            pdf.Add(table);
        }

        public static PdfPTable GenerateSummaryHeader(PdfWriter writer, Document document, DateTime? startDate, DateTime? endDate)
        {
            float[] headerWidths = { 25, 50, 25 };
            PdfPTable table = new PdfPTable(1);
            table.WidthPercentage = 100;
            PdfPTable table2 = new PdfPTable(3);
            table2.SetWidths(headerWidths);

            //Left Block
            PdfPCell cell2 = new PdfPCell(new Phrase(""));
            cell2.Border = 0;
            cell2.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(cell2);

            //Center (Title) Block
            cell2 = new PdfPCell();
            cell2.Border = 0;
            Paragraph para = new Paragraph();
            para.Alignment = Element.ALIGN_CENTER;

            PdfPTable table3 = new PdfPTable(1);
            table3.WidthPercentage = 100;
            PdfPCell cell3 = new PdfPCell();
            cell3.Border = 0;

            Chunk title = new Chunk("Medicaid Approvals Report Summary", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 20, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE));
            para.Add(title);
            cell3.AddElement(para);
            table3.AddCell(cell3);
            table3.CompleteRow();

            string titleText = "";

            if (startDate == null && endDate == null)
            {
                titleText = "";
            }

            if (startDate == null && endDate != null)
            {
                titleText = $"Up until {Convert.ToDateTime(endDate).ToShortDateString()}";
            }

            if (startDate != null && endDate == null)
            {
                titleText = $"Starting from {Convert.ToDateTime(endDate).ToShortDateString()}";
            }

            if (startDate != null && endDate != null)
            {
                titleText = $"{Convert.ToDateTime(startDate).ToShortDateString()} to {Convert.ToDateTime(endDate).ToShortDateString()}";
            }

            para = new Paragraph();
            para.Alignment = Element.ALIGN_CENTER;
            title = new Chunk(titleText, new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 12, iTextSharp.text.Font.NORMAL));
            para.Add(title);
            cell3 = new PdfPCell();
            cell3.Border = 0;
            cell3.AddElement(para);
            table3.AddCell(cell3);
            table3.CompleteRow();

            cell2.AddElement(table3);
            table2.AddCell(cell2);

            //Daterun
            var runDate = DateTime.Now;
            cell2 = new PdfPCell(new Phrase($"Ran on: {runDate}", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
            cell2.BorderWidth = 0;
            cell2.HorizontalAlignment = Element.ALIGN_RIGHT;
            table2.AddCell(cell2);
            table2.CompleteRow();

            PdfPCell cell = new PdfPCell(table2);
            cell.PaddingBottom = 12;
            cell.BorderWidth = 0;
            cell.BackgroundColor = BaseColor.White;
            table.AddCell(cell);

            return table;
        }

        public static PdfPTable GenerateCompanySummary(PdfWriter writer, Document document, List<MedicaidApprovalsReportModel> residents, List<Facility> facilities)
        {
            float[] headerWidths = { 20, 20, 20, 20, 20 };
            PdfPTable dataTable = new PdfPTable(5);
            dataTable.WidthPercentage = 100;
            dataTable.SetWidths(headerWidths);

            var dataColor = new BaseColor(224, 232, 235);

            iTextSharp.text.Font fontDataCell = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.Black);
            iTextSharp.text.Font summaryFont = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.Black);

            var totalApprovalAmount = residents.Sum(x => x.MedicaidApprovedAmount != null ? x.MedicaidApprovedAmount : 0).Value.ToString("C");
            var isUmedApprovedCount = residents.Any(x => x.IsUmedApproved == true) ? residents.Where(x => x.IsUmedApproved == true).ToList().Count : 0;

            var totalGain = 0.00M;
            var totalLoss = 0.00M;

            foreach (var facility in facilities)
            {
                foreach (var resident in residents)
                {
                    var effectiveDate = DateTime.Parse(resident.MedicaidEffectiveDate);

                    var days = (decimal)(DateTime.UtcNow - effectiveDate).TotalDays;

                    totalGain += Decimal.Multiply(days, facility.DailyRate);

                    if (resident.MedicaidRequestedEffectiveDate.HasValue && resident.MedicaidRequestedEffectiveDate.Value <= effectiveDate)
                    {
                        days = (decimal)(effectiveDate - resident.MedicaidRequestedEffectiveDate.Value).TotalDays;
                        totalLoss += Decimal.Multiply(days, facility.DailyRate);
                    }
                }
            }

            totalGain = Math.Round(totalGain, 2);
            totalLoss = Math.Round(totalLoss, 2);

            var summaryCell = new PdfPCell(new Phrase($"Approval Count", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Approval Amount", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Umed Completed", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Total Gain", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"Total Loss", summaryFont));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = dataColor;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);
            dataTable.CompleteRow();

            summaryCell = new PdfPCell(new Phrase(residents.Count.ToString(), fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"{totalApprovalAmount}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            summaryCell = new PdfPCell(new Phrase($"{isUmedApprovedCount}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            var gain = totalGain.ToString("C");
            summaryCell = new PdfPCell(new Phrase($"{gain}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);

            var loss = totalLoss.ToString("C");
            summaryCell = new PdfPCell(new Phrase($"{loss}", fontDataCell));
            summaryCell.PaddingBottom = 5F;
            summaryCell.BackgroundColor = BaseColor.White;
            summaryCell.BorderColor = BaseColor.LightGray;
            summaryCell.BorderWidth = 0.25F;
            summaryCell.VerticalAlignment = Element.ALIGN_CENTER;
            summaryCell.HorizontalAlignment = Element.ALIGN_CENTER;
            dataTable.AddCell(summaryCell);
            dataTable.CompleteRow();

            return dataTable;
        }

        private static string GetUmedNeededText(bool? isUmedNeeded)
        {
            return isUmedNeeded.HasValue ? (isUmedNeeded == true ? "Yes" : "No") : "Undetermined";
        }
    }
}
