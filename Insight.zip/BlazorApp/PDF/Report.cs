﻿using System;
using System.Collections.Generic;
using System.IO;
using BlazorApp.Data;
using BlazorApp.Models;
using HelloWorld.Model.DataTables;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.JSInterop;
using BlazorApp.Services;
using System.Linq;

namespace BlazorApp.PDF
{
    public class Report
    {
        private int _pagenumber;

        public void Generate(IJSRuntime js, int pagenumber, string filename = "report.pdf")
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                                filename,
                                Convert.ToBase64String(ReportPDF())
                                );
        }

        public void GenerateMedicaidApprovalsReport(IJSRuntime js, int pagenumber, List<MedicaidApprovalsReportModel> residents, DateTime? startDate, DateTime? endDate, List<Facility> facilities)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "medicaidapprovalsreport.pdf",
                Convert.ToBase64String(MedicaidApprovalsReportReportPdf(residents, startDate, endDate, facilities))
            );
        }

        public void GenerateMedicaidRecertificationReport(IJSRuntime js, int pagenumber, List<MedicaidRecertificationReportModel> residents, DateTime? startDate, DateTime? endDate, List<Facility> facilities)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "medicaidrecertificationreport.pdf",
                Convert.ToBase64String(MedicaidRecertificationReportPDF(residents, startDate, endDate, facilities))
            );
        }

        public void GenerateMedicaidPendingReportReport(IJSRuntime js, int pagenumber, List<MedicaidPendingReportModel> residents, List<Facility> facilities, bool showCaseNotes, bool showChecklist, List<StateChecklistItem> checkListItems)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "medicaidpendingreport.pdf",
                Convert.ToBase64String(MedicaidPendingReportPDF(residents, facilities, showCaseNotes, showChecklist, checkListItems))
            );
        }

        public void GenerateltcplanneededReport(IJSRuntime js, int pagenumber, List<LTCPlanNeededReportModel> residents, List<Facility> facilities)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "LTCPlanNeededReport.pdf",
                Convert.ToBase64String(ltcplanneededPDF(residents, facilities))
            );
        }

        public void GeneratePatientResourceLiabilityReport(IJSRuntime js, int pagenumber, List<PatientResourceLiabilityReportModel> residents, int selectStatusFilter, List<Facility> facilities)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "PatientResourceLiabilityReport.pdf",
                Convert.ToBase64String(PatientResourceLiabilityReportPDF(residents, selectStatusFilter, facilities))
            );
        }

        public void GenerateMmaDsnpDaysUsedReport(IJSRuntime js, int pagenumber, List<MmaDsnpDaysUsedReportModel> residents, List<Facility> facilities)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "MmaDsnpDaysUsedReport.pdf",
                Convert.ToBase64String(MmaDsnpDaysUsedReportPDF(residents, facilities))
            );
        }

        public void GenerateLevelOfCareReport(IJSRuntime js, int pagenumber, List<TemporaryLevelOfCareReportModel> temporaryLocResidents, List<LevelOfCareNeededReportModel> levelOfCareNeededResidents, List<Facility> facilities)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "LevelOfCareReport.pdf",
                Convert.ToBase64String(LevelOfCareReportReportPDF(temporaryLocResidents, levelOfCareNeededResidents, facilities))
            );
        }

        public void OpenToIframe(IJSRuntime js, int pagenumber, string idiFrame)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsOpenToIframe",
                                idiFrame,
                                Convert.ToBase64String(ReportPDF())
                                );
        }
        public void OpenNewTab(IJSRuntime js, int pagenumber, string filename = "report.pdf")
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsOpenIntoNewTab",
                                filename,
                                Convert.ToBase64String(ReportPDF())
                                );
        }

        public void GenerateResidentCaseNotesReport(IJSRuntime js, int pagenumber, ResidentCaseNotesReportModel resident, Facility facility)
        {
            _pagenumber = pagenumber;

            js.InvokeVoidAsync("jsSaveAsFile",
                "ResidentCaseNotesReport.pdf",
                Convert.ToBase64String(ResidentCaseNotesReportPDF(resident, facility))
            );
        }

        private byte[] MedicaidApprovalsReportReportPdf(List<MedicaidApprovalsReportModel> residents, DateTime? startDate, DateTime? endDate, List<Facility> facilities)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                                    PageSize.A4.Rotate(),
                                    margeLeft.ToDpi(),
                                    margeRight.ToDpi(),
                                    margeTop.ToDpi(),
                                    margeBottom.ToDpi()
                                   );

            pdf.AddCreationDate();
            
            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            //HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            HeaderFooter footer = new HeaderFooter(labelFooter, true);
            footer.Alignment = Element.ALIGN_RIGHT;
            footer.Border = 1;
            footer.BorderWidth = 1;
            pdf.Footer = footer;

            pdf.Open();

            foreach (var facility in facilities)
            {
                var facilityResidents = residents.Where(x => x.FacilityId == facility.Id).ToList();

                pdf.Add(MedicaidApprovalsReport.GenerateHeader(writer, pdf, startDate, endDate, facility));

                MedicaidApprovalsReport.CreateTable(pdf, writer, facilityResidents, facility);

                pdf.NewPage();
            }

            if (facilities.Count > 1)
            {
                pdf.Add(MedicaidApprovalsReport.GenerateSummaryHeader(writer, pdf, startDate, endDate));
                pdf.Add(MedicaidApprovalsReport.GenerateCompanySummary(writer, pdf, residents, facilities));
            }

            pdf.Close();

            return memoryStream.ToArray();
        }
        
        private byte[] ltcplanneededPDF(List<LTCPlanNeededReportModel> residents, List<Facility> facilities)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                PageSize.A4.Rotate(),
                margeLeft.ToDpi(),
                margeRight.ToDpi(),
                margeTop.ToDpi(),
                margeBottom.ToDpi()
            );

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            //HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            HeaderFooter footer = new HeaderFooter(labelFooter, true)
            {
                Alignment = Element.ALIGN_RIGHT, 
                Border = 1, 
                BorderWidth = 1
            };
            pdf.Footer = footer;

            pdf.Open();

            for (int i = 0; i < facilities.Count; i++)
            {
                var facility = facilities[i];

                var facilityResidents = residents.Where(x => x.FacilityId == facility.Id).ToList();

                pdf.Add(LTCPlanNeededReport.GenerateHeader(writer, pdf, facility));

                LTCPlanNeededReport.CreateTable(pdf, writer, facilityResidents);

                if (i < facilities.Count - 1)
                {
                    pdf.NewPage();
                }
            }

            pdf.Close();

            return memoryStream.ToArray();
        }
        private byte[] MedicaidPendingReportPDF(List<MedicaidPendingReportModel> residents, List<Facility> facilities, bool showCaseNotes, bool showChecklist, List<StateChecklistItem> checkListItems)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                PageSize.A4.Rotate(),
                margeLeft.ToDpi(),
                margeRight.ToDpi(),
                margeTop.ToDpi(),
                margeBottom.ToDpi()
            );

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            //HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            HeaderFooter footer = new HeaderFooter(labelFooter, true);
            footer.Alignment = Element.ALIGN_RIGHT;
            footer.Border = 1;
            footer.BorderWidth = 1;
            pdf.Footer = footer;

            pdf.Open();

            for (int i = 0; i < facilities.Count; i++)
            {
                var facility = facilities[i];

                var facilityResidents = residents.Where(x => x.FacilityId == facility.Id).ToList();

                pdf.Add(MedicaidPendingReport.GenerateHeader(writer, pdf, facility));

                MedicaidPendingReport.CreateTable(pdf, writer, facilityResidents, facility, showCaseNotes, showChecklist, checkListItems);

                if (i < facilities.Count - 1)
                {
                    pdf.NewPage();
                }
            }

            pdf.Close();

            return memoryStream.ToArray();
        }

        private byte[] MedicaidRecertificationReportPDF(List<MedicaidRecertificationReportModel> residents, DateTime? startDate, DateTime? endDate, List<Facility> facilities)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                PageSize.A4.Rotate(),
                margeLeft.ToDpi(),
                margeRight.ToDpi(),
                margeTop.ToDpi(),
                margeBottom.ToDpi()
            );

            pdf.AddCreationDate();

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            //HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            HeaderFooter footer = new HeaderFooter(labelFooter, true);
            footer.Alignment = Element.ALIGN_RIGHT;
            footer.Border = 1;
            footer.BorderWidth = 1;
            pdf.Footer = footer;

            pdf.Open();

            for (int i = 0; i < facilities.Count; i++)
            {
                var facility = facilities[i];

                var facilityResidents = residents.Where(x => x.FacilityId == facility.Id).ToList();

                pdf.Add(MedicaidRecertificationReport.GenerateHeader(writer, pdf, startDate, endDate, facility));

                MedicaidRecertificationReport.CreateTable(pdf, writer, facilityResidents);

                if (i < facilities.Count - 1)
                {
                    pdf.NewPage();
                }
            }

            pdf.Close();

            return memoryStream.ToArray();
        }
        
        private byte[] PatientResourceLiabilityReportPDF(List<PatientResourceLiabilityReportModel> residents, int selectStatusFilter, List<Facility> facilities)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                PageSize.A4.Rotate(),
                margeLeft.ToDpi(),
                margeRight.ToDpi(),
                margeTop.ToDpi(),
                margeBottom.ToDpi()
            );

            pdf.AddCreationDate();

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            //HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            HeaderFooter footer = new HeaderFooter(labelFooter, true);
            footer.Alignment = Element.ALIGN_RIGHT;
            footer.Border = 1;
            footer.BorderWidth = 1;
            pdf.Footer = footer;

            pdf.Open();

            for (int i = 0; i < facilities.Count; i++)
            {
                var facility = facilities[i];

                var facilityResidents = residents.Where(x => x.FacilityId == facility.Id).ToList();

                pdf.Add(PatientResourceLiabilityReport.GenerateHeader(writer, pdf, selectStatusFilter, facility));

                PatientResourceLiabilityReport.CreateTable(pdf, writer, facilityResidents);

                if (i < facilities.Count - 1)
                {
                    pdf.NewPage();
                }
            }

            pdf.Close();

            return memoryStream.ToArray();
        }

        private byte[] MmaDsnpDaysUsedReportPDF(List<MmaDsnpDaysUsedReportModel> residents, List<Facility> facilities)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                PageSize.A4.Rotate(),
                margeLeft.ToDpi(),
                margeRight.ToDpi(),
                margeTop.ToDpi(),
                margeBottom.ToDpi()
            );

            pdf.AddCreationDate();

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            //HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            HeaderFooter footer = new HeaderFooter(labelFooter, true);
            footer.Alignment = Element.ALIGN_RIGHT;
            footer.Border = 1;
            footer.BorderWidth = 1;
            pdf.Footer = footer;

            pdf.Open();

            for (int i = 0; i < facilities.Count; i++)
            {
                var facility = facilities[i];

                var facilityResidents = residents.Where(x => x.FacilityId == facility.Id).ToList();

                pdf.Add(MmaDsnpDaysUsedReport.GenerateHeader(writer, pdf, facility));

                MmaDsnpDaysUsedReport.CreateTable(pdf, writer, facilityResidents);

                if (i < facilities.Count - 1)
                {
                    pdf.NewPage();
                }
            }

            pdf.Close();

            return memoryStream.ToArray();
        }

        private byte[] LevelOfCareReportReportPDF(List<TemporaryLevelOfCareReportModel> temporaryLocResidents, List<LevelOfCareNeededReportModel> levelOfCareNeededResidents, List<Facility> facilities)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                PageSize.A4.Rotate(),
                margeLeft.ToDpi(),
                margeRight.ToDpi(),
                margeTop.ToDpi(),
                margeBottom.ToDpi()
            );

            pdf.AddCreationDate();

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            //HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            HeaderFooter footer = new HeaderFooter(labelFooter, true);
            footer.Alignment = Element.ALIGN_RIGHT;
            footer.Border = 1;
            footer.BorderWidth = 1;
            pdf.Footer = footer;

            pdf.Open();

            for (int i = 0; i < facilities.Count; i++)
            {
                var facility = facilities[i];

                var facilityTempLocResidents = temporaryLocResidents.Where(x => x.FacilityId == facility.Id).ToList();
                var facilityLocNeededResidents = levelOfCareNeededResidents.Where(x => x.FacilityId == facility.Id).ToList();

                pdf.Add(LevelOfCareReport.GenerateHeader(writer, pdf, facility));

                LevelOfCareReport.CreateTable(pdf, writer, facilityTempLocResidents, facilityLocNeededResidents);

                if (i < facilities.Count - 1)
                {
                    pdf.NewPage();
                }
            }

            pdf.Close();

            return memoryStream.ToArray();
        }

        private byte[] ReportPDF()
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then I convert with .ToDpi()
            float margeLeft = 1.5f;
            float margeRight = 1.5f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                                    PageSize.A4,
                                    margeLeft.ToDpi(),
                                    margeRight.ToDpi(),
                                    margeTop.ToDpi(),
                                    margeBottom.ToDpi()
                                   );

            pdf.AddTitle("Blazor-PDF");
            pdf.AddAuthor("Christophe Peugnet");
            pdf.AddCreationDate();
            pdf.AddKeywords("blazor");
            pdf.AddSubject("Create a pdf file with iText");

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);

            //HEADER and FOOTER
            var fontStyle = FontFactory.GetFont("Arial", 16, BaseColor.White);
            var labelHeader = new Chunk("Header Blazor PDF", fontStyle);
            HeaderFooter header = new HeaderFooter(new Phrase(labelHeader), false)
            {
                BackgroundColor = new BaseColor(133, 76, 199),
                Alignment = Element.ALIGN_CENTER,
                Border = Rectangle.NO_BORDER
            };
            //header.Border = Rectangle.NO_BORDER;
            pdf.Header = header;


            var labelFooter = new Chunk("Page", fontStyle);
            HeaderFooter footer = new HeaderFooter(new Phrase(labelFooter), true)
            {
                Border = Rectangle.NO_BORDER,
                Alignment = Element.ALIGN_RIGHT
            };
            pdf.Footer = footer;

            pdf.Open();

            //if (_pagenumber == 1)
            //    Page1.PageText(pdf);
            //else if (_pagenumber == 2)
            //    Page2.PageBookmark(pdf);
            //else if (_pagenumber == 3)
            //    Page3.PageImage(pdf, writer);
            //else if (_pagenumber == 4)
            //    MedicaidApprovalsReport.CreateTable(pdf, writer);
            //else if (_pagenumber == 5)
            //    Page5.PageFonts(pdf, writer);
            //else if (_pagenumber == 6)
            //    Page6.PageList(pdf);
            //else if (_pagenumber == 7)
            //    page7.PageShapes(pdf, writer);

            pdf.Close();

            return memoryStream.ToArray();
        }

        private byte[] ResidentCaseNotesReportPDF(ResidentCaseNotesReportModel resident, Facility facility)
        {
            var memoryStream = new MemoryStream();

            // Marge in centimeter, then convert with .ToDpi()
            float margeLeft = 1.0f;
            float margeRight = 1.0f;
            float margeTop = 1.0f;
            float margeBottom = 1.0f;

            Document pdf = new Document(
                PageSize.A4.Rotate(),
                margeLeft.ToDpi(),
                margeRight.ToDpi(),
                margeTop.ToDpi(),
                margeBottom.ToDpi()
            );

            PdfWriter writer = PdfWriter.GetInstance(pdf, memoryStream);
            var labelFooter = new Phrase("Page");
            HeaderFooter footer = new HeaderFooter(labelFooter, true);
            footer.Alignment = Element.ALIGN_RIGHT;
            footer.Border = 1;
            footer.BorderWidth = 1;
            pdf.Footer = footer;

            pdf.Open();

            pdf.Add(ResidentCaseNotesReport.GenerateHeader(writer, pdf, resident, facility));

            ResidentCaseNotesReport.CreateTable(pdf, writer, resident, facility);

            pdf.Close();

            return memoryStream.ToArray();
        }

    }
}
