﻿using System;
using System.Collections.Generic;
using System.Linq;
using BlazorApp.Data;
using HelloWorld.Model.DataTables;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace BlazorApp.PDF
{
    public class LevelOfCareReport
    {
        public static PdfPTable GenerateHeader(PdfWriter writer, Document document, Facility facility)
        {
            float[] headerWidths = { 30, 40, 30 };
            PdfPTable table = new PdfPTable(1);
            table.WidthPercentage = 100;
            PdfPTable table2 = new PdfPTable(3);
            table2.SetWidths(headerWidths);

            var leftBlockText = new System.Text.StringBuilder();
            leftBlockText.AppendLine(facility.Name);
            leftBlockText.AppendLine(facility.AddressLine1);
            leftBlockText.AppendLine($"{facility.City}, {facility.StateCode}, {facility.Zip}");

            //Left Block
            PdfPCell cell2 = new PdfPCell(new Phrase(leftBlockText.ToString()));
            cell2.Border = 0;
            cell2.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(cell2);

            //Center (Title) Block
            cell2 = new PdfPCell();
            cell2.Border = 0;
            Paragraph para = new Paragraph();
            para.Alignment = Element.ALIGN_CENTER;

            PdfPTable table3 = new PdfPTable(1);
            table3.WidthPercentage = 100;
            PdfPCell cell3 = new PdfPCell();
            cell3.Border = 0;

            Chunk title = new Chunk("Level of Care Report", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 20, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE));
            para.Add(title);
            cell3.AddElement(para);
            table3.AddCell(cell3);
            table3.CompleteRow();

            cell2.AddElement(table3);
            table2.AddCell(cell2);

            //Daterun
            var runDate = DateTime.Now;
            cell2 = new PdfPCell(new Phrase($"Ran on: {runDate}", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
            cell2.BorderWidth = 0;
            cell2.HorizontalAlignment = Element.ALIGN_RIGHT;
            table2.AddCell(cell2);
            table2.CompleteRow();

            PdfPCell cell = new PdfPCell(table2);
            cell.PaddingBottom = 12;
            cell.BorderWidth = 0;
            cell.BackgroundColor = BaseColor.White;
            table.AddCell(cell);

            return table;
        }

        public static void CreateTable(Document pdf, PdfWriter writer, List<TemporaryLevelOfCareReportModel> temporaryLocResidents, List<LevelOfCareNeededReportModel> levelOfCareNeededResidents)
        {
            iTextSharp.text.Font fontH1 = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.BOLD, BaseColor.White);
            iTextSharp.text.Font fontDataCell = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.Black);
            var h1Color = new BaseColor(80, 110, 124);
            var dataColor = new BaseColor(224, 232, 235);

            iTextSharp.text.Font fontTableTitle = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 16, iTextSharp.text.Font.BOLD, BaseColor.Black);

            PdfPTable mainGrid = new PdfPTable(3);
            float[] gridCellWidths = { 48, 4, 48 };
            mainGrid.WidthPercentage = 100;
            mainGrid.SetWidths(gridCellWidths);
            mainGrid.HorizontalAlignment = Element.ALIGN_CENTER;
            mainGrid.HeaderRows = 0;

            PdfPCell mainGridCell = new PdfPCell(new Phrase("Temporary Level of Care", fontTableTitle));
            mainGridCell.PaddingBottom = 5F;
            mainGridCell.BackgroundColor = BaseColor.White;
            mainGridCell.BorderWidth = 0F;
            mainGridCell.HorizontalAlignment = Element.ALIGN_LEFT;
            mainGridCell.VerticalAlignment = Element.ALIGN_CENTER;
            mainGrid.AddCell(mainGridCell);

            mainGridCell = new PdfPCell(new Phrase("", fontTableTitle));
            mainGridCell.PaddingBottom = 5F;
            mainGridCell.BackgroundColor = BaseColor.White;
            mainGridCell.BorderWidth = 0F;
            mainGridCell.HorizontalAlignment = Element.ALIGN_LEFT;
            mainGridCell.VerticalAlignment = Element.ALIGN_CENTER;
            mainGrid.AddCell(mainGridCell);

            mainGridCell = new PdfPCell(new Phrase("Level of Care Needed", fontTableTitle));
            mainGridCell.PaddingBottom = 5F;
            mainGridCell.BackgroundColor = BaseColor.White;
            mainGridCell.BorderWidth = 0F;
            mainGridCell.HorizontalAlignment = Element.ALIGN_LEFT;
            mainGridCell.VerticalAlignment = Element.ALIGN_CENTER;
            mainGrid.AddCell(mainGridCell);
            mainGrid.CompleteRow();

            PdfPTable headertable = new PdfPTable(3);
            float[] h1widths = { 40, 40, 20 };
            headertable.WidthPercentage = 100;
            headertable.SetWidths(h1widths);
            headertable.HorizontalAlignment = Element.ALIGN_CENTER;
            headertable.HeaderRows = 0;

            //Temporary Level of Care
            PdfPCell h1Cell = new PdfPCell(new Phrase("Resident Name", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.BorderColorLeft = h1Color;
            h1Cell.BorderColorRight = BaseColor.White;
            h1Cell.BorderWidthLeft = .25F;
            h1Cell.BorderWidthTop = 0F;
            h1Cell.BorderWidthRight = .25F;
            h1Cell.BorderWidthBottom = 0F;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            h1Cell = new PdfPCell(new Phrase("Level of Care Date", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.BorderColorRight = BaseColor.White;
            h1Cell.BorderWidthLeft = 0F;
            h1Cell.BorderWidthTop = 0F;
            h1Cell.BorderWidthRight = .25F;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            h1Cell = new PdfPCell(new Phrase("Days Since", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.BorderColorRight = BaseColor.White;
            h1Cell.BorderWidthLeft = 0F;
            h1Cell.BorderWidthTop = 0F;
            h1Cell.BorderWidthRight = .25F;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            if (!temporaryLocResidents.Any())
            {
                var cell = new PdfPCell(new Phrase("No Records Found", fontDataCell));
                cell.PaddingBottom = 5F;
                cell.Colspan = 4;
                cell.BackgroundColor = BaseColor.White;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                headertable.AddCell(cell);
            }
            else
            {
                for (int i = 0; i < temporaryLocResidents.Count; i++)
                {
                    var resident = temporaryLocResidents[i];
                    var backgroundColor = (i % 2 == 0) ? BaseColor.White : dataColor;

                    var cell = new PdfPCell(new Phrase(resident.ResidentFullName, fontDataCell));
                    cell.PaddingBottom = 5F;
                    cell.BackgroundColor = backgroundColor;
                    cell.BorderColor = BaseColor.LightGray;
                    cell.BorderWidth = 0.25F;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    headertable.AddCell(cell);

                    var totalPatientLiability = resident.LevelOfCareDate;
                    cell = new PdfPCell(new Phrase(totalPatientLiability.ToString(), fontDataCell));
                    cell.PaddingBottom = 5F;
                    cell.BackgroundColor = backgroundColor;
                    cell.BorderColor = BaseColor.LightGray;
                    cell.BorderWidth = 0.25F;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    headertable.AddCell(cell);

                    var days = Convert.ToInt64(Convert.ToDouble(resident.DaysSince));

                    cell = new PdfPCell(new Phrase(days.ToString(), fontDataCell));
                    cell.PaddingBottom = 5F;
                    cell.BackgroundColor = backgroundColor;
                    cell.BorderColor = BaseColor.LightGray;
                    cell.BorderWidth = 0.25F;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    headertable.AddCell(cell);
                    headertable.CompleteRow();
                }
            }

            if (temporaryLocResidents.Count < 2)
            {
                var numOfCols = headertable.NumberOfColumns;

                var cell = new PdfPCell(new Phrase("", fontDataCell));
                cell.Border = 0;
                cell.BackgroundColor = BaseColor.White;

                for (int i = 0; i < numOfCols; i++)
                {
                    headertable.AddCell(cell);
                }
            }

            mainGridCell = new PdfPCell(headertable);
            mainGridCell.PaddingBottom = 5F;
            mainGridCell.BackgroundColor = BaseColor.White;
            mainGridCell.BorderWidth = 0F;
            mainGridCell.HorizontalAlignment = Element.ALIGN_LEFT;
            mainGridCell.VerticalAlignment = Element.ALIGN_CENTER;
            mainGrid.AddCell(mainGridCell);

            mainGridCell = new PdfPCell(new Phrase("", fontTableTitle));
            mainGridCell.PaddingBottom = 5F;
            mainGridCell.BackgroundColor = BaseColor.White;
            mainGridCell.BorderWidth = 0F;
            mainGridCell.HorizontalAlignment = Element.ALIGN_LEFT;
            mainGridCell.VerticalAlignment = Element.ALIGN_CENTER;
            mainGrid.AddCell(mainGridCell);

            headertable = new PdfPTable(3);
            headertable.WidthPercentage = 100;
            headertable.SetWidths(h1widths);
            headertable.HorizontalAlignment = Element.ALIGN_CENTER;
            headertable.HeaderRows = 0;

            //Temporary Level of Care
            h1Cell = new PdfPCell(new Phrase("Resident Name", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.BorderColorLeft = h1Color;
            h1Cell.BorderColorRight = BaseColor.White;
            h1Cell.BorderWidthLeft = .25F;
            h1Cell.BorderWidthTop = 0F;
            h1Cell.BorderWidthRight = .25F;
            h1Cell.BorderWidthBottom = 0F;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            h1Cell = new PdfPCell(new Phrase("Requested Effective Date", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.BorderColorRight = BaseColor.White;
            h1Cell.BorderWidthLeft = 0F;
            h1Cell.BorderWidthTop = 0F;
            h1Cell.BorderWidthRight = .25F;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            h1Cell = new PdfPCell(new Phrase("Days Since", fontH1));
            h1Cell.PaddingBottom = 5F;
            h1Cell.BackgroundColor = h1Color;
            h1Cell.BorderColorRight = BaseColor.White;
            h1Cell.BorderWidthLeft = 0F;
            h1Cell.BorderWidthTop = 0F;
            h1Cell.BorderWidthRight = .25F;
            h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
            h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
            headertable.AddCell(h1Cell);

            if (!levelOfCareNeededResidents.Any())
            {
                var cell = new PdfPCell(new Phrase("No Records Found", fontDataCell));
                cell.PaddingBottom = 5F;
                cell.Colspan = 4;
                cell.BackgroundColor = BaseColor.White;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                headertable.AddCell(cell);
            }
            else
            {
                for (int i = 0; i < levelOfCareNeededResidents.Count; i++)
                {
                    var resident = levelOfCareNeededResidents[i];
                    var backgroundColor = (i % 2 == 0) ? BaseColor.White : dataColor;

                    var cell = new PdfPCell(new Phrase(resident.ResidentFullName, fontDataCell));
                    cell.PaddingBottom = 5F;
                    cell.BackgroundColor = backgroundColor;
                    cell.BorderColor = BaseColor.LightGray;
                    cell.BorderWidth = 0.25F;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    headertable.AddCell(cell);

                    var totalPatientLiability = resident.RequestedEffectiveDate;
                    cell = new PdfPCell(new Phrase(totalPatientLiability.ToString(), fontDataCell));
                    cell.PaddingBottom = 5F;
                    cell.BackgroundColor = backgroundColor;
                    cell.BorderColor = BaseColor.LightGray;
                    cell.BorderWidth = 0.25F;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    headertable.AddCell(cell);

                    string days = "";
                    double daysSince;

                    if (double.TryParse(resident.DaysSince, out daysSince))
                    {
                        days = Convert.ToInt64(daysSince).ToString();
                    }

                    cell = new PdfPCell(new Phrase(days, fontDataCell));
                    cell.PaddingBottom = 5F;
                    cell.BackgroundColor = backgroundColor;
                    cell.BorderColor = BaseColor.LightGray;
                    cell.BorderWidth = 0.25F;
                    cell.VerticalAlignment = Element.ALIGN_CENTER;
                    headertable.AddCell(cell);
                    headertable.CompleteRow();
                }
            }

            if (levelOfCareNeededResidents.Count < 2)
            {
                var numOfCols = headertable.NumberOfColumns;

                var cell = new PdfPCell(new Phrase("", fontDataCell));
                cell.Border = 0;
                cell.BackgroundColor = BaseColor.White;

                for (int i = 0; i < numOfCols; i++)
                {
                    headertable.AddCell(cell);
                }
            }

            mainGridCell = new PdfPCell(headertable);
            mainGridCell.PaddingBottom = 5F;
            mainGridCell.BackgroundColor = BaseColor.White;
            mainGridCell.BorderWidth = 0F;
            mainGridCell.HorizontalAlignment = Element.ALIGN_LEFT;
            mainGridCell.VerticalAlignment = Element.ALIGN_CENTER;
            mainGrid.AddCell(mainGridCell);

            mainGrid.CompleteRow();

            pdf.Add(mainGrid);
        }
    }
}
