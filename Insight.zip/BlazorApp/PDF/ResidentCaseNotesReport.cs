﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using BlazorApp.Data;
using BlazorApp.Services;
using HelloWorld.Common.Enumerations;
using HelloWorld.Common.Helpers;
using HelloWorld.Model.DataTables;
using iTextSharp.text;
using iTextSharp.text.pdf;
using OneOf.Types;

namespace BlazorApp.PDF
{
    public class ResidentCaseNotesReport
    {
        public static PdfPTable GenerateHeader(PdfWriter writer, Document document, ResidentCaseNotesReportModel resident, Facility facility)
        {
            float[] headerWidths = { 30, 40, 30 };
            PdfPTable table = new PdfPTable(1);
            table.WidthPercentage = 100;
            PdfPTable table2 = new PdfPTable(3);
            table2.SetWidths(headerWidths);

            var leftBlockText = new System.Text.StringBuilder();
            leftBlockText.AppendLine(facility.Name);
            leftBlockText.AppendLine(facility.AddressLine1);
            leftBlockText.AppendLine($"{facility.City}, {facility.StateCode}, {facility.Zip}");

            //Left Block
            PdfPCell cell2 = new PdfPCell(new Phrase(leftBlockText.ToString()));
            cell2.Border = 0;
            cell2.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(cell2);

            //Center (Title) Block
            cell2 = new PdfPCell();
            cell2.Border = 0;
            Paragraph para = new Paragraph();
            para.Alignment = Element.ALIGN_CENTER;

            PdfPTable table3 = new PdfPTable(1);
            table3.WidthPercentage = 100;
            PdfPCell cell3 = new PdfPCell();
            cell3.Border = 0;

            Chunk title = new Chunk($"Case Notes - {resident.ResidentFullName}", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 20, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE));
            para.Add(title);
            cell3.AddElement(para);
            table3.AddCell(cell3);
            table3.CompleteRow();

            cell2.AddElement(table3);
            table2.AddCell(cell2);

            //Daterun
            var runDate = DateTime.Now;
            cell2 = new PdfPCell(new Phrase($"Ran on: {runDate}", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
            cell2.BorderWidth = 0;
            cell2.HorizontalAlignment = Element.ALIGN_RIGHT;
            table2.AddCell(cell2);
            table2.CompleteRow();

            PdfPCell cell = new PdfPCell(table2);
            cell.PaddingBottom = 12;
            cell.BorderWidth = 0;
            cell.BackgroundColor = BaseColor.White;
            table.AddCell(cell);

            return table;
        }

        public static void CreateTable(Document pdf, PdfWriter writer, ResidentCaseNotesReportModel resident, Facility facility)
        {
            iTextSharp.text.Font fontH1 = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 9, iTextSharp.text.Font.BOLD, BaseColor.White);
            iTextSharp.text.Font fontDataCell = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.Black);
            var headerColor = new BaseColor(108, 145, 162);
            var h1Color = new BaseColor(224, 232, 235);
            var dataColor = new BaseColor(224, 232, 235);

            var today = DateHelper.OffsetDateTimeFromUtcToLocal(DateTime.UtcNow, DateHelper.GetTimeZoneInfo(facility.TimeZoneId));

            PdfPTable mainTable = new PdfPTable(1);
            mainTable.WidthPercentage = 100;

            if (!resident.CaseNotes.Any())
            {
                var cell = new PdfPCell(new Phrase("No Records Found", fontDataCell));
                cell.PaddingBottom = 5F;
                cell.Colspan = 4;
                cell.BackgroundColor = BaseColor.White;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                mainTable.AddCell(cell);
            }
            else { 
                for (int i = 0; i < resident.CaseNotes.Count; i++)
                {
                    var caseNote = resident.CaseNotes[i];

                    PdfPTable tbl2 = new PdfPTable(1);
                    tbl2.WidthPercentage = 100;

                    PdfPTable tbl3 = new PdfPTable(8);
                    float[] headerWidths = { 17, 12, 16, 14, 13, 12, 16, 12 };
                    tbl3.WidthPercentage = 100;
                    tbl3.SetWidths(headerWidths);

                    var h1Cell = new PdfPCell(new Phrase("Created On", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = BaseColor.White;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Created By", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Note Type", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Checklist Link", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Assigned To", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Updated On", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Updated By", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Status", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);
                    tbl3.CompleteRow();

                    h1Cell = new PdfPCell(new Phrase(caseNote.CreatedDate, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(caseNote.CreatedByFullName, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(caseNote.NoteType, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(caseNote.ChecklistLink, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(caseNote.AssignedToFullName, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(caseNote.UpdatedOnDate, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(caseNote.UpdatedByFullName, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(caseNote.Status, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);
                    tbl3.CompleteRow();

                    tbl2.AddCell(new PdfPCell(tbl3) { Border = 0 });
                    tbl2.CompleteRow();

                    PdfPTable tbl4 = new PdfPTable(1);
                    tbl4.WidthPercentage = 100;

                    h1Cell = new PdfPCell(new Phrase("Case Notes", fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = h1Color;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = 0F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl4.AddCell(h1Cell);
                    tbl4.CompleteRow();

                    h1Cell = new PdfPCell(new Phrase(caseNote.Note, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = .25F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl4.AddCell(h1Cell);
                    tbl4.CompleteRow();

                    tbl2.AddCell(new PdfPCell(tbl4) { Border = 0 });

                    if (!string.IsNullOrEmpty(caseNote.CompletedNote))
                    {
                        PdfPTable tbl5 = new PdfPTable(1);
                        tbl5.WidthPercentage = 100;
                        h1Cell = new PdfPCell(new Phrase("Completion Comment", fontDataCell));
                        h1Cell.PaddingBottom = 5F;
                        h1Cell.BackgroundColor = h1Color;
                        h1Cell.BorderColor = BaseColor.LightGray;
                        h1Cell.BorderWidthLeft = 0F;
                        h1Cell.BorderWidthTop = 0F;
                        h1Cell.BorderWidthRight = .25F;
                        h1Cell.BorderWidthBottom = 0F;
                        h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                        tbl5.AddCell(h1Cell);
                        tbl5.CompleteRow();

                        h1Cell = new PdfPCell(new Phrase(caseNote.CompletedNote, fontDataCell));
                        h1Cell.PaddingBottom = 5F;
                        h1Cell.BorderColor = BaseColor.LightGray;
                        h1Cell.BorderWidthLeft = .25F;
                        h1Cell.BorderWidthTop = 0F;
                        h1Cell.BorderWidthRight = .25F;
                        h1Cell.BorderWidthBottom = .25F;
                        h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                        h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                        tbl5.AddCell(h1Cell);
                        tbl5.CompleteRow();

                        tbl2.AddCell(new PdfPCell(tbl5) { Border = 0 });
                    }
                    var cell = new PdfPCell(tbl2);
                    cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = .25F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = .25F;
                    mainTable.AddCell(cell);
                }
        }

            pdf.Add(mainTable);
        }
    }
}
