﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using BlazorApp.Data;
using HelloWorld.Common.Helpers;
using HelloWorld.Model.DataTables;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace BlazorApp.PDF
{
    public class MedicaidPendingReport
    {
        public static PdfPTable GenerateHeader(PdfWriter writer, Document document, Facility facility)
        {
            float[] headerWidths = { 30, 40, 30 };
            PdfPTable table = new PdfPTable(1);
            table.WidthPercentage = 100;
            PdfPTable table2 = new PdfPTable(3);
            table2.SetWidths(headerWidths);

            var leftBlockText = new System.Text.StringBuilder();
            leftBlockText.AppendLine(facility.Name);
            leftBlockText.AppendLine(facility.AddressLine1);
            leftBlockText.AppendLine($"{facility.City}, {facility.StateCode}, {facility.Zip}");

            //Left Block
            PdfPCell cell2 = new PdfPCell(new Phrase(leftBlockText.ToString()));
            cell2.Border = 0;
            cell2.HorizontalAlignment = Element.ALIGN_LEFT;
            table2.AddCell(cell2);

            //Center (Title) Block
            cell2 = new PdfPCell();
            cell2.Border = 0;
            Paragraph para = new Paragraph();
            para.Alignment = Element.ALIGN_CENTER;

            PdfPTable table3 = new PdfPTable(1);
            table3.WidthPercentage = 100;
            PdfPCell cell3 = new PdfPCell();
            cell3.Border = 0;

            Chunk title = new Chunk("Medicaid Pending Report", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 20, iTextSharp.text.Font.BOLD | iTextSharp.text.Font.UNDERLINE));
            para.Add(title);
            cell3.AddElement(para);
            table3.AddCell(cell3);
            table3.CompleteRow();

            cell2.AddElement(table3);
            table2.AddCell(cell2);

            //Daterun
            var runDate = DateTime.Now;
            cell2 = new PdfPCell(new Phrase($"Ran on: {runDate}", new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 10, iTextSharp.text.Font.NORMAL)));
            cell2.BorderWidth = 0;
            cell2.HorizontalAlignment = Element.ALIGN_RIGHT;
            table2.AddCell(cell2);
            table2.CompleteRow();

            PdfPCell cell = new PdfPCell(table2);
            cell.PaddingBottom = 12;
            cell.BorderWidth = 0;
            cell.BackgroundColor = BaseColor.White;
            table.AddCell(cell);

            return table;
        }

        public static void CreateTable(Document pdf, PdfWriter writer, List<MedicaidPendingReportModel> residents, Facility facility, bool showCaseNotes, bool showChecklist, List<StateChecklistItem> checkListItems)
        {
            iTextSharp.text.Font fontH1 = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 9, iTextSharp.text.Font.BOLD, BaseColor.White);
            iTextSharp.text.Font fontDataCell = new iTextSharp.text.Font(iTextSharp.text.Font.HELVETICA, 9, iTextSharp.text.Font.NORMAL, BaseColor.Black);
            var headerColor = new BaseColor(108, 145, 162);
            var h1Color = new BaseColor(224, 232, 235);
            var dataColor = new BaseColor(224, 232, 235);

            var today = DateHelper.OffsetDateTimeFromUtcToLocal(DateTime.UtcNow, DateHelper.GetTimeZoneInfo(facility.TimeZoneId));

            PdfPTable mainTable = new PdfPTable(2);
            float[] mainTableHdrWidths = { 12, 88 };

            mainTable.WidthPercentage = 100;
            mainTable.SetWidths(mainTableHdrWidths);

            if (!residents.Any())
            {
                var cell = new PdfPCell(new Phrase("No Records Found", fontDataCell));
                cell.PaddingBottom = 5F;
                cell.Colspan = 4;
                cell.BackgroundColor = BaseColor.White;
                cell.BorderColor = BaseColor.LightGray;
                cell.BorderWidth = 0.25F;
                cell.VerticalAlignment = Element.ALIGN_CENTER;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                mainTable.AddCell(cell);
            }
            else
            {
                for (int i = 0; i < residents.Count; i++)
                {
                    var resident = residents[i];
                    var backgroundColor = (i % 2 == 0) ? BaseColor.White : dataColor;

                    var residentIsUnder65 = resident.DateOfBirth.HasValue && today.Date.AddYears(-65) < Convert.ToDateTime(resident.DateOfBirth).Date;

                    PdfPTable tbl1 = new PdfPTable(1);
                    tbl1.WidthPercentage = 100;

                    var h1Cell = new PdfPCell(new Phrase("Name", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderColor = headerColor;
                    h1Cell.BorderColorRight = BaseColor.White;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl1.AddCell(h1Cell);
                    tbl1.CompleteRow();

                    h1Cell = new PdfPCell(new Phrase(resident.ResidentFullName, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = .25F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                    tbl1.AddCell(h1Cell);
                    tbl1.CompleteRow();

                    var cell = new PdfPCell(tbl1);
                    cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = .25F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = .25F;
                    mainTable.AddCell(cell);

                    PdfPTable tbl2 = new PdfPTable(1);
                    tbl2.WidthPercentage = 100;

                    PdfPTable tbl3 = new PdfPTable(7);
                    float[] headerWidths = { 17, 12, 16, 14, 13, 12, 16 };
                    tbl3.WidthPercentage = 100;
                    tbl3.SetWidths(headerWidths);

                    h1Cell = new PdfPCell(new Phrase("Requested Effective Date", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = BaseColor.White;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Application Date", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = BaseColor.White;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Days Since Application", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Estimated Liability", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = BaseColor.White;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Approval Status", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = BaseColor.White;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Umed Needed?", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = BaseColor.White;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase("Umed Application Date", fontH1));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BackgroundColor = headerColor;
                    h1Cell.BorderColorLeft = BaseColor.White;
                    h1Cell.BorderColorRight = headerColor;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);
                    tbl3.CompleteRow();

                    h1Cell = new PdfPCell(new Phrase(resident.MedicaidRequestedEffectiveDate, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(resident.MedicaidApplicationDate, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    var daysSince = (int)(today.Date - Convert.ToDateTime((string.IsNullOrEmpty(resident.MedicaidApplicationDate)) ? today.Date : DateTime.Parse(resident.MedicaidApplicationDate).Date)).TotalDays;
                    h1Cell = new PdfPCell(new Phrase(daysSince.ToString(), fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(resident.EstimatedLiability.ToString("C"), fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(resident.MedicaidStatus, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(resident.UmedNeeded, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);

                    h1Cell = new PdfPCell(new Phrase(resident.UmedApplicationDate, fontDataCell));
                    h1Cell.PaddingBottom = 5F;
                    h1Cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = 0F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = 0F;
                    h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                    tbl3.AddCell(h1Cell);
                    tbl3.CompleteRow();

                    tbl2.AddCell(new PdfPCell(tbl3) { Border = 0 });
                    tbl2.CompleteRow();

                    if (showChecklist)
                    {
                        tbl3 = new PdfPTable(checkListItems.Count);
                        tbl3.WidthPercentage = 100;
                        foreach (var item in checkListItems)
                        {
                            //check for SSDI App Complete and if resident is < 65
                            if (item.Name == "SSDI App")
                            {
                                if (residentIsUnder65)
                                {
                                    h1Cell = new PdfPCell(new Phrase(item.Name, fontDataCell));
                                    h1Cell.PaddingBottom = 5F;
                                    h1Cell.BorderColor = BaseColor.LightGray;
                                    h1Cell.BorderWidthLeft = 0F;
                                    h1Cell.BorderWidthTop = .25F;
                                    h1Cell.BorderWidthRight = 0F;
                                    h1Cell.BorderWidthBottom = 0F;
                                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                                    tbl3.AddCell(h1Cell);
                                }
                                else
                                {
                                    h1Cell = new PdfPCell(new Phrase("", fontDataCell));
                                    h1Cell.PaddingBottom = 5F;
                                    h1Cell.BorderColor = BaseColor.LightGray;
                                    h1Cell.BorderWidthLeft = 0F;
                                    h1Cell.BorderWidthTop = .25F;
                                    h1Cell.BorderWidthRight = 0F;
                                    h1Cell.BorderWidthBottom = 0F;
                                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                                    tbl3.AddCell(h1Cell);
                                }
                            }
                            else
                            {
                                h1Cell = new PdfPCell(new Phrase(item.Name, fontDataCell));
                                h1Cell.PaddingBottom = 5F;
                                h1Cell.BorderColor = BaseColor.LightGray;
                                h1Cell.BorderWidthLeft = 0F;
                                h1Cell.BorderWidthTop = .25F;
                                h1Cell.BorderWidthRight = 0F;
                                h1Cell.BorderWidthBottom = 0F;
                                h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                                h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                                tbl3.AddCell(h1Cell);
                            }
                        }
                        tbl3.CompleteRow();

                        iTextSharp.text.Font checkboxFont = new iTextSharp.text.Font(iTextSharp.text.Font.ZAPFDINGBATS, 9, iTextSharp.text.Font.BOLD, BaseColor.Black);
                        foreach (var item in checkListItems)
                        {
                            string checkboxString = "";

                            if (item.Name == "SSDI App")
                            {
                                if (residentIsUnder65)
                                {
                                    if (resident.ResidentCompletedChecklistItems.Any(x => x.ChecklistItemId == item.Id))
                                    {
                                        checkboxString = "4";
                                    }

                                    h1Cell = new PdfPCell(new Phrase(checkboxString, checkboxFont));
                                    h1Cell.PaddingBottom = 5F;
                                    h1Cell.BorderColor = BaseColor.LightGray;
                                    h1Cell.BorderWidthLeft = 0F;
                                    h1Cell.BorderWidthTop = 0F;
                                    h1Cell.BorderWidthRight = 0F;
                                    h1Cell.BorderWidthBottom = .25F;
                                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                                    tbl3.AddCell(h1Cell);
                                }
                                else
                                {
                                    h1Cell = new PdfPCell(new Phrase("", checkboxFont));
                                    h1Cell.PaddingBottom = 5F;
                                    h1Cell.BorderColor = BaseColor.LightGray;
                                    h1Cell.BorderWidthLeft = 0F;
                                    h1Cell.BorderWidthTop = 0F;
                                    h1Cell.BorderWidthRight = 0F;
                                    h1Cell.BorderWidthBottom = .25F;
                                    h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                                    h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                                    tbl3.AddCell(h1Cell);
                                }
                            }
                            else
                            {
                                if (resident.ResidentCompletedChecklistItems.Any(x => x.ChecklistItemId == item.Id))
                                {
                                    checkboxString = "4";
                                }

                                h1Cell = new PdfPCell(new Phrase(checkboxString, checkboxFont));
                                h1Cell.PaddingBottom = 5F;
                                h1Cell.BorderColor = BaseColor.LightGray;
                                h1Cell.BorderWidthLeft = 0F;
                                h1Cell.BorderWidthTop = 0F;
                                h1Cell.BorderWidthRight = 0F;
                                h1Cell.BorderWidthBottom = .25F;
                                h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                                h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                                tbl3.AddCell(h1Cell);
                            }
                        }
                        tbl3.CompleteRow();

                        tbl2.AddCell(new PdfPCell(tbl3) { Border = 0 });
                    }

                    if (showCaseNotes)
                    {
                        PdfPTable tbl4 = new PdfPTable(1);
                        tbl4.WidthPercentage = 100;

                        h1Cell = new PdfPCell(new Phrase("Case Notes", fontDataCell));
                        h1Cell.PaddingBottom = 5F;
                        h1Cell.BackgroundColor = h1Color;
                        h1Cell.BorderColor = BaseColor.LightGray;
                        h1Cell.BorderWidthLeft = 0F;
                        h1Cell.BorderWidthTop = 0F;
                        h1Cell.BorderWidthRight = .25F;
                        h1Cell.BorderWidthBottom = 0F;
                        h1Cell.HorizontalAlignment = Element.ALIGN_CENTER;
                        h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                        tbl4.AddCell(h1Cell);
                        tbl4.CompleteRow();

                        h1Cell = new PdfPCell(new Phrase(resident.FormattedCaseNotes, fontDataCell));
                        h1Cell.PaddingBottom = 5F;
                        h1Cell.BorderColor = BaseColor.LightGray;
                        h1Cell.BorderWidthLeft = .25F;
                        h1Cell.BorderWidthTop = 0F;
                        h1Cell.BorderWidthRight = .25F;
                        h1Cell.BorderWidthBottom = .25F;
                        h1Cell.HorizontalAlignment = Element.ALIGN_LEFT;
                        h1Cell.VerticalAlignment = Element.ALIGN_CENTER;
                        tbl4.AddCell(h1Cell);
                        tbl4.CompleteRow();

                        tbl2.AddCell(new PdfPCell(tbl4) { Border = 0 });
                    }

                    cell = new PdfPCell(tbl2);
                    cell.BorderColor = BaseColor.LightGray;
                    h1Cell.BorderWidthLeft = .25F;
                    h1Cell.BorderWidthTop = .25F;
                    h1Cell.BorderWidthRight = .25F;
                    h1Cell.BorderWidthBottom = .25F;
                    mainTable.AddCell(cell);
                }
            }

            if (residents.Count < 2)
            {
                var numOfCols = mainTable.NumberOfColumns;

                var cell = new PdfPCell(new Phrase("", fontDataCell));
                cell.Border = 0;
                cell.BackgroundColor = BaseColor.White;

                for (int i = 0; i < numOfCols; i++)
                {
                    mainTable.AddCell(cell);
                }
            }

            pdf.Add(mainTable);
        }
    }
}
