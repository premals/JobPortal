﻿using System;
using System.Collections.Generic;
using System.Text;
using BlazorApp.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BlazorApp.Data
{
    public class BlazorAppIdentityDbContext : IdentityDbContext<ApplicationUser>
    {
        public BlazorAppIdentityDbContext(DbContextOptions<BlazorAppIdentityDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
    }
}
