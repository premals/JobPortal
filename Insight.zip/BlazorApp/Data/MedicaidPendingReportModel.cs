﻿using HelloWorld.Model.DataTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Data
{
    public class MedicaidPendingReportModel
    {
        public int Id { get; set; }
        public string ResidentFullName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string MedicaidRequestedEffectiveDate { get; set; }
        public string MedicaidApplicationDate { get; set; }
        public decimal EstimatedLiability { get; set; }
        public string MedicaidStatus { get; set; }
        public string UmedNeeded { get; set; }
        public string UmedApplicationDate { get; set; }
        public List<CaseNote> CaseNotes { get; set; }
        public string FormattedCaseNotes { get; set; }
        public List<ResidentCompletedChecklistItem> ResidentCompletedChecklistItems { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }
    }
}
