﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Data
{
    public class ReportModel
    {
        public string Name { get; set; }
        public string Href { get; set; }
    }
}
