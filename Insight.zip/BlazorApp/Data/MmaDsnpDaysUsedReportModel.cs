﻿using System;

namespace BlazorApp.Data
{
    public class MmaDsnpDaysUsedReportModel
    {
        public string ResidentFullName { get; set; }
        public string AdmissionDate { get; set; }
        public DateTime? MmaEffectiveDate { get; set; }
        public string PlanName { get; set; }
        public int DaysUsed { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }
    }
}
