﻿using HelloWorld.Model.DataTables;
using System.Collections.Generic;

namespace BlazorApp.Data
{
    public class MedicaidPendingResidentModel : MedicaidPendingReportModel
    {
        public bool ShowDetails { get; set; }
        public bool IsUmedNeeded { get; set; }

        public MedicaidPendingResidentModel(MedicaidPendingReportModel resident)
        {
            Id = resident.Id;
            ResidentFullName = resident.ResidentFullName;
            DateOfBirth = resident.DateOfBirth;
            MedicaidRequestedEffectiveDate = resident.MedicaidRequestedEffectiveDate;
            MedicaidApplicationDate = resident.MedicaidApplicationDate;
            EstimatedLiability = resident.EstimatedLiability;
            MedicaidStatus = resident.MedicaidStatus;
            IsUmedNeeded = resident.UmedNeeded == "YES" ? true : false;
            UmedApplicationDate = resident.UmedApplicationDate;
            CaseNotes = resident.CaseNotes;
            FormattedCaseNotes = resident.FormattedCaseNotes;
            ResidentCompletedChecklistItems = resident.ResidentCompletedChecklistItems;
            FacilityName = resident.FacilityName;
            FacilityId = resident.FacilityId;
        }
    }
}
