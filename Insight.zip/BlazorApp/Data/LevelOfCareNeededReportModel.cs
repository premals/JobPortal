﻿using System;

namespace BlazorApp.Data
{
    public class LevelOfCareNeededReportModel
    {
        public string ResidentFullName { get; set; }
        public string RequestedEffectiveDate { get; set; }
        public string DaysSince { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }
    }
}
