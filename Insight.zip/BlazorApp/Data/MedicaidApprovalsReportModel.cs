﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Data
{
    public class MedicaidApprovalsReportModel
    {
        public string ResidentFullName { get; set; }
        public string MedicaidApplicationDate { get; set; }
        public string MedicaidEffectiveDate { get; set; }
        public DateTime? MedicaidRequestedEffectiveDate { get; set; }
        public decimal? MedicaidApprovedAmount { get; set; }
        public string UmedNeeded { get; set; }
        public bool? IsUmedApproved { get; set; }
        public string UmedApplicationDate { get; set; }
        public decimal? UmedRequestedAmount { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }
    }
}
