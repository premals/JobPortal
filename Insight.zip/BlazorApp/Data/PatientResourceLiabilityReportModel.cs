﻿using System;
using BlazorApp.Services;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Data
{
    public class PatientResourceLiabilityReportModel
    {
        public PatientResourceLiabilityReportModel(Resident resident)
        {
            var assetInfoHelper = new AssetInfoHelper();

            Id = resident.Id;
            ResidentFullName = resident.LastName + ", " + resident.FirstName;
            TotalPatientLiability = assetInfoHelper.GetTotalPatientLiability(resident);
            DateOfBirth = resident.DateOfBirth.HasValue ? Convert.ToDateTime(resident.DateOfBirth).Date.ToString("d") : string.Empty;
            MedicaidNumber = resident.MedicaidNumber;
            FacilityName = resident.Facility.Name;
            FacilityId = resident.FacilityId;
        }

        public int Id { get; set; }
        public string ResidentFullName { get; set; }
        public decimal TotalPatientLiability { get; set; }
        public string DateOfBirth { get; set; }
        public string MedicaidNumber { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }
    }
}
