﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Data
{
    public class MedicaidRecertificationReportModel
    {
        public string ResidentFullName { get; set; }
        public string RecertificationDate { get; set; }
        public string DateOfBirth { get; set; }
        public string MedicaidNumber { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }

    }
}
