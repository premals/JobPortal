﻿using System.Collections.Generic;

namespace BlazorApp.Data
{
    public class AccessLevelTreeModel
    {
        public int Id { get; set; }
        public int ParentId { get; set; }
        public string Name { get; set; }
        public bool Expanded { get; set; }
        public bool? IsChecked { get; set; }
        public bool HasChild { get; set; }
        public List<AccessLevelTreeModel> Children { get; set; }
        public bool IsCollapsed { get; set; }
    }
}
