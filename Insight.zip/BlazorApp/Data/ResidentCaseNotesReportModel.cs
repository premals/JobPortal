﻿using System.Collections.Generic;

namespace BlazorApp.Data
{
    public class ResidentCaseNotesReportModel
    {
        public string ResidentFullName { get; set; }
        public List<ResidentCaseNotes> CaseNotes { get; set; }
    }

    public class ResidentCaseNotes
    {
        public int Id { get; set; }
        public string CreatedByFullName { get; set; }
        public string CreatedDate { get; set; }
        public string NoteType { get; set; }
        public string ChecklistLink { get; set; }
        public string AssignedToFullName { get; set; }
        public string UpdatedOnDate { get; set; }
        public string UpdatedByFullName { get; set; }
        public string Status { get; set; }
        public string Note { get; set; }
        public string CompletedNote { get; set; }
    }

}
