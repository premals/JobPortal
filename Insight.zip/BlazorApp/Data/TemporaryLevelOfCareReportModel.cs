﻿using System;

namespace BlazorApp.Data
{
    public class TemporaryLevelOfCareReportModel
    {
        public string ResidentFullName { get; set; }
        public string LevelOfCareDate { get; set; }
        public string DaysSince { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }
    }
}
