﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Data
{
    public class TabFormStateModel
    {
        public bool HasFormStateChanged { get; set; }
        public string TabName { get; set; }
    }
}
