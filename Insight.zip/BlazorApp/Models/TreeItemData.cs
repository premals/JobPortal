﻿using HelloWorld.Common.Enumerations;
using MudBlazor;
using System.Collections.Generic;
using System.Linq;

namespace BlazorApp.Models
{
    public class TreeItemData
    {
        public TreeItemData Parent { get; set; } = null;

        public string Text { get; set; }

        public int EntityId { get; set; }

        public int LevelTypeId { get; set; }

        public bool IsExpanded { get; set; } = false;

        public bool IsChecked { get; set; } = false;

        public bool HasChild => TreeItems != null && TreeItems.Count > 0;

        public HashSet<TreeItemData> TreeItems { get; set; } = new HashSet<TreeItemData>();

        public TreeItemData(string text)
        {
            Text = text;
        }

        public TreeItemData(string itemName, int levelTypeId, int entityId)
        {
            Text = itemName;
            LevelTypeId = levelTypeId;
            EntityId = entityId;
        }

        public void AddChild(string itemName, int levelTypeId, int entityId)
        {
            TreeItemData item = new TreeItemData(itemName, levelTypeId, entityId);
            item.Parent = this;
            this.TreeItems.Add(item);
        }

        public void AddChild(TreeItemData item)
        {
            this.TreeItems.Add(item);
        }

        public bool HasPartialChildSelection()
        {
            int iChildrenCheckedCount = (from c in TreeItems where c.IsChecked select c).Count();
            return HasChild && iChildrenCheckedCount > 0 && iChildrenCheckedCount < TreeItems.Count();
        }

    }
}