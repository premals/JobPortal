﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace BlazorApp.Models
{
    public class ApplicationUser : IdentityUser
    {
        public bool IsActive { get; set; }
        public int TenantId { get; set; }
        public int EmployeeId { get; set; }
        public ApplicationUser(string userName, bool isActive, int tenantId, int employeeId) : base(userName)
        {
            IsActive = isActive;
            TenantId = tenantId;
            EmployeeId = employeeId;
        }
    }
}
