﻿using MudBlazor;

namespace BlazorApp.Models
{
    public class Dimensions
    {
        public int Width { get; set; }
        public int Height { get; set; }

        public string GetTopLevelPageStyle()
        {
            return $"height: {Height}px; overflow-y: auto; overflow-x: hidden;";
        }
    }
}
