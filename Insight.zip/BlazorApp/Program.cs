using System;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using Azure.Core.Extensions;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using BlazorApp.Areas.Identity;
using BlazorApp.Data;
using BlazorApp.Models;
using BlazorApp.Pages.Dashboard;
using BlazorApp.Services;
using BlazorApp.Services.Interfaces;
using Blazored.Toast;
using HelloWorld.EntityFramework;
using HelloWorld.EntityFramework.Context;
using HelloWorld.EntityFramework.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MudBlazor.Extensions;
using MudBlazor.Services;
using Radzen;

try
{
    var builder = WebApplication.CreateBuilder(args);

    var configuration = builder.Configuration;

    builder.Logging.AddApplicationInsights(
        configureTelemetryConfiguration: (config) =>
            config.ConnectionString = configuration.GetConnectionString("APPLICATIONINSIGHTS_CONNECTION_STRING"),
            configureApplicationInsightsLoggerOptions: (options) => { }
    );

    builder.Services.AddMudServicesWithExtensions();
    builder.Services.AddMudExtensions();
    builder.Services.AddRazorPages();
    builder.Services.AddServerSideBlazor()
        .AddCircuitOptions(option => { option.DetailedErrors = true; })
        .AddHubOptions(o =>
        {
            o.ClientTimeoutInterval = TimeSpan.FromSeconds(60);
            o.KeepAliveInterval = TimeSpan.FromSeconds(30);
        });

    builder.Services.AddBlazoredToast();
    builder.Services.AddMudServices();
    builder.Services.AddScoped<DialogService>(); 
    builder.Services.AddScoped<TooltipService>();
    builder.Services.AddScoped<IBrowserService, BrowserService>();

    builder.Services.AddScoped<AuthenticationStateProvider, RevalidatingIdentityAuthenticationStateProvider<ApplicationUser>>();
    builder.Services.AddTransient<IApplicationUserService, ApplicationUserService>();

    builder.Services.AddScoped<ITenantService, TenantService>();
    builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
    builder.Services.AddScoped<IConfigRepository, ConfigRepository>();

    builder.Services.AddDbContext<HelloWorldTenantContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("HelloWorldTenantContext")));

    builder.Services.AddDbContext<HelloWorldConfigContext>(options =>
        options.UseSqlServer(configuration.GetConnectionString("HelloWorldConfigContext")));

    builder.Services.AddDbContext<BlazorAppIdentityDbContext>(options =>
        options.UseSqlServer(configuration.GetConnectionString("BlazorAppIdentityContext")));

    builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
        .AddEntityFrameworkStores<BlazorAppIdentityDbContext>()
        .AddDefaultTokenProviders();

    builder.Services.AddAzureClients(builder =>
    {
        builder.AddBlobServiceClient(configuration["ConnectionStrings:StorageConnectionString:blob"], preferMsi: true);
        builder.AddQueueServiceClient(configuration["ConnectionStrings:StorageConnectionString:queue"], preferMsi: true);
    });

    var kvUri = configuration.GetSection("AzureKeyVaultUri").Value;
    var certName = configuration.GetSection("CertificateName").Value;

    if (kvUri == null)
    {
        throw new Exception("Could not retrieve AzureKeyVaultUri.");
    }

    if (certName == null)
    {
        throw new Exception("Could not retrieve certName.");
    }

    var secretClient = new SecretClient(new Uri(kvUri), new DefaultAzureCredential());

    var response = secretClient.GetSecret(certName);
    var keyVaultSecret = response?.Value;

    if (keyVaultSecret == null)
    {
        throw new Exception("Could not find certificate.");
    }

    var privateKeyBytes = Convert.FromBase64String(keyVaultSecret.Value);
    var clientCertificate = new X509Certificate2(privateKeyBytes);

    builder.Services.AddHttpClient("namedClient", c =>
    {
    }).ConfigurePrimaryHttpMessageHandler(() =>
    {
        var handler = new HttpClientHandler();
        handler.ClientCertificates.Add(clientCertificate);
        return handler;
    });

    builder.Services.AddHttpClient("MatrixCareClient")
    .ConfigurePrimaryHttpMessageHandler(() => {
        var handler = new HttpClientHandler();
        handler.ClientCertificates.Add(clientCertificate);
        return handler;
    });

    var basicTokenResponse = secretClient.GetSecret("rs-pcc-basic-token");
    var basicToken = basicTokenResponse?.Value.Value;

    configuration["PccIntegration:BasicToken"] = basicToken;

    var app = builder.Build();

    if (app.Environment.IsDevelopment())
    {
        app.UseDeveloperExceptionPage();
    }
    else
    {
        app.UseExceptionHandler("/Error");
        // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
        app.UseHsts();
    }

    app.UseHttpsRedirection();
    app.UseStaticFiles();

    app.UseRouting();

    app.UseAuthentication();
    app.UseAuthorization();

    app.MapControllers();
    app.MapBlazorHub();
    app.MapFallbackToPage("/_Host");

    app.UseMudExtensions();

    app.Run();
}
catch (Exception ex)
{
    var message = ex.Message;
}

internal static class StartupExtensions
{
    public static IAzureClientBuilder<BlobServiceClient, BlobClientOptions> AddBlobServiceClient(this AzureClientFactoryBuilder builder, string serviceUriOrConnectionString, bool preferMsi)
    {
        if (preferMsi && Uri.TryCreate(serviceUriOrConnectionString, UriKind.Absolute, out Uri serviceUri))
        {
            return builder.AddBlobServiceClient(serviceUri);
        }
        else
        {
            return builder.AddBlobServiceClient(serviceUriOrConnectionString);
        }
    }
    public static IAzureClientBuilder<QueueServiceClient, QueueClientOptions> AddQueueServiceClient(this AzureClientFactoryBuilder builder, string serviceUriOrConnectionString, bool preferMsi)
    {
        if (preferMsi && Uri.TryCreate(serviceUriOrConnectionString, UriKind.Absolute, out Uri serviceUri))
        {
            return builder.AddQueueServiceClient(serviceUri);
        }
        else
        {
            return builder.AddQueueServiceClient(serviceUriOrConnectionString);
        }
    }
}

//namespace BlazorApp
//{
//    public class Program
//    {
//        public static void Main(string[] args)
//        {
//            CreateHostBuilder(args).Build().Run();
//        }

//        public static IHostBuilder CreateHostBuilder(string[] args) =>
//            Host.CreateDefaultBuilder(args)
//                .ConfigureWebHostDefaults(webBuilder =>
//                {
//                    webBuilder.UseStartup<Startup>();
//                });
//    }
//}
