﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Services
{
    public class ResidentIncomeService : IResidentIncomeService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public ResidentIncomeService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public ResidentIncomeService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public ResidentIncome Add(ResidentIncome income)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.ResidentIncome.Add(income);
                context.SaveChanges();
                return income;
            }
        }

        public List<ResidentIncome> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentIncome.ToList();
            }
        }

        public List<ResidentIncome> GetIncomesForResident(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentIncome.Where(x => x.ResidentId == residentId && !x.IsDeleted).ToList();
            }
        }

        public ResidentIncome Get(int id)
        {
            var income = new ResidentIncome();

            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                income = context.ResidentIncome.FirstOrDefault(x => x.Id == id);
            }

            return income;
        }

        public ResidentIncome Update(ResidentIncome income)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(income).State = EntityState.Modified;
                context.SaveChanges();
                return Get(income.Id);
            }
        }
    }
}
