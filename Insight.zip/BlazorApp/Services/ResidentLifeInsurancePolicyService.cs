﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Services
{
    public class ResidentLifeInsurancePolicyService : IResidentLifeInsurancePolicyService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public ResidentLifeInsurancePolicyService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public ResidentLifeInsurancePolicyService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public ResidentLifeInsurancePolicy Add(ResidentLifeInsurancePolicy policy)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.ResidentLifeInsurancePolicy.Add(policy);
                context.SaveChanges();
                return policy;
            }
        }

        public List<ResidentLifeInsurancePolicy> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentLifeInsurancePolicy.ToList();
            }
        }

        public List<ResidentLifeInsurancePolicy> GetInsurancePoliciesForResident(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentLifeInsurancePolicy.Where(x => x.ResidentId == residentId && !x.IsDeleted).ToList();
            }
        }

        public ResidentLifeInsurancePolicy Get(int id)
        {
            var policy = new ResidentLifeInsurancePolicy();

            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                policy = context.ResidentLifeInsurancePolicy.FirstOrDefault(x => x.Id == id);
            }

            return policy;
        }

        public ResidentLifeInsurancePolicy Update(ResidentLifeInsurancePolicy policy)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(policy).State = EntityState.Modified;
                context.SaveChanges();
                return Get(policy.Id);
            }
        }
    }
}
