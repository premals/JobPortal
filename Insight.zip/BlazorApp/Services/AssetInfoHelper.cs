﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelloWorld.Common.Enumerations;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services
{
    public class AssetInfoHelper
    {
        #region Income
        public List<ResidentIncome> GetPensionIncomes(List<ResidentIncome> residentIncomes, bool isSpouseIncome = false)
        {
            return residentIncomes.Where(i => i.IncomeType == (int) ResidentIncomeTypes.Pension && i.IsSpouseIncome == isSpouseIncome && i.IsDeleted == false)?.ToList();
        }

        public List<ResidentIncome> GetOtherIncomes(List<ResidentIncome> residentIncomes, bool isSpouseIncome = false)
        {
            return residentIncomes.Where(i => i.IncomeType == (int)ResidentIncomeTypes.Other && i.IsSpouseIncome == isSpouseIncome && i.IsDeleted == false)?.ToList();
        }

        public List<ResidentIncome> GetSsaIncomes(List<ResidentIncome> residentIncomes)
        {
            return residentIncomes.Where(i => i.IncomeType == (int)ResidentIncomeTypes.Ssa).ToList();
        }

        public List<ResidentIncome> GetSsiIncomes(List<ResidentIncome> residentIncomes)
        {
            return residentIncomes.Where(i => i.IncomeType == (int)ResidentIncomeTypes.Ssi).ToList();
        }

        public List<ResidentIncome> GetVaIncomes(List<ResidentIncome> residentIncomes)
        {
            return residentIncomes.Where(i => i.IncomeType == (int)ResidentIncomeTypes.Va).ToList();
        }

        public decimal GetTotalResidentIncome(List<ResidentIncome> residentIncomes)
        {
            var ssaIncomes = GetSsaIncomes(residentIncomes);
            var ssiIncomes = GetSsiIncomes(residentIncomes);
            var vaIncomes = GetVaIncomes(residentIncomes);
            var pensionIncomes = GetPensionIncomes(residentIncomes);
            var otherIncomes = GetOtherIncomes(residentIncomes);

            var pensionTotal = (pensionIncomes.Any(i => i.IsSpouseIncome == false)) ? pensionIncomes.Where(i => i.IsSpouseIncome == false).Sum(x => x.Amount) : 0.00M;
            var otherTotal = (otherIncomes.Any(i => i.IsSpouseIncome == false)) ? otherIncomes.Where(i => i.IsSpouseIncome == false).Sum(x => x.Amount) : 0.00M;
            var ssaAmount = (ssaIncomes.Any(i => i.IsSpouseIncome == false)) ? ssaIncomes.Where(i => i.IsSpouseIncome == false).Sum(x => x.Amount) : 0.00M;
            var ssiAmount = (ssiIncomes.Any(i => i.IsSpouseIncome == false)) ? ssiIncomes.Where(i => i.IsSpouseIncome == false).Sum(x => x.Amount) : 0.00M;
            var vaAmount = (vaIncomes.Any(i => i.IsSpouseIncome == false)) ? vaIncomes.Where(i => i.IsSpouseIncome == false).Sum(x => x.Amount) : 0.00M;

            return ssaAmount + ssiAmount + vaAmount + pensionTotal + otherTotal;
        }

        #endregion

        #region Asset Accounts 

        public List<ResidentAssetAccount> GetResidentBankAccounts(List<ResidentAssetAccount> residentAccounts, bool isSpouseAccounts = false)
        {
            return residentAccounts.Where(acct => (acct.AssetTypeId == (int)AssetTypes.Checking
                                            || acct.AssetTypeId == (int)AssetTypes.Savings
                                            || acct.AssetTypeId == (int)AssetTypes.MoneyMarket
                                            || acct.AssetTypeId == (int)AssetTypes.CertificateOfDeposit)
                                            && !acct.IsDeleted
                                            && acct.IsSpouseAccount == isSpouseAccounts).ToList();
        }

        public List<ResidentAssetAccount> GetResidentInvestmentAccounts(List<ResidentAssetAccount> residentAccounts, bool isSpouseAccounts = false)
        {
            return residentAccounts.Where(acct => (acct.AssetTypeId == (int)AssetTypes.Annuity
                                            || acct.AssetTypeId == (int)AssetTypes.MutualFund
                                            || acct.AssetTypeId == (int)AssetTypes.FourOhOneK
                                            || acct.AssetTypeId == (int)AssetTypes.IRA
                                            || acct.AssetTypeId == (int)AssetTypes.StocksBonds)
                                            && !acct.IsDeleted
                                            && acct.IsSpouseAccount == isSpouseAccounts).ToList();
        }

        public List<ResidentAssetAccount> GetResidentOtherAccounts(List<ResidentAssetAccount> residentAccounts, bool isSpouseAccounts = false)
        {
            return residentAccounts.Where(acct => acct.AssetTypeId == (int)AssetTypes.Other
                                            && !acct.IsDeleted
                                            && acct.IsSpouseAccount == isSpouseAccounts).ToList();
        }

        #endregion

        public decimal GetTotalPatientLiability(Resident resident)
        { 
            var liabilityAllowance = resident.Facility.PatientLiabilityAllowance;
            var totalResidentIncome = GetTotalResidentIncome(resident.ResidentIncomes);
            var residentHealthInsurancePremium = (resident.ResidentExpenses.Any(x => x.ExpenseType == (int)ResidentExpenseTypes.HealthInsurancePremium && x.IsSpouseExpense == false))
                ? resident.ResidentExpenses.FirstOrDefault(x => x.ExpenseType == (int)ResidentExpenseTypes.HealthInsurancePremium && x.IsSpouseExpense == false).Amount
                : 0.00M;
            var totalPatientLiability = totalResidentIncome - liabilityAllowance - residentHealthInsurancePremium;

            return totalPatientLiability > 0 ? totalPatientLiability : 0.00M;
        }
    }
}
