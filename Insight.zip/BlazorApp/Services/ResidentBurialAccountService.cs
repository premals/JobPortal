﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Services
{
    public class ResidentBurialAccountService : IResidentBurialAccountService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public ResidentBurialAccountService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public ResidentBurialAccountService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public ResidentBurialAccount Add(ResidentBurialAccount account)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.ResidentBurialAccount.Add(account);
                context.SaveChanges();
                return account;
            }
        }

        public List<ResidentBurialAccount> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentBurialAccount.ToList();
            }
        }

        public ResidentBurialAccount Get(int id)
        {
            var account = new ResidentBurialAccount();

            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                account = context.ResidentBurialAccount.FirstOrDefault(x => x.Id == id);
            }

            return account;
        }

        public ResidentBurialAccount Update(ResidentBurialAccount account)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(account).State = EntityState.Modified;
                context.SaveChanges();
                return Get(account.Id);
            }
        }
    }
}
