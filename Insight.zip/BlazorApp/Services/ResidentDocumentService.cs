﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using BlazorApp.Services.Interfaces;
using Microsoft.Extensions.Configuration;

namespace BlazorApp.Services
{
    public class ResidentDocumentService : IResidentDocumentService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public ResidentDocumentService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public ResidentDocumentService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<ResidentDocument> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentDocument.ToList();
            }
        }

        public ResidentDocument Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentDocument.Find(id);
            }
        }

        public List<ResidentDocument> GetByResidentId(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentDocument.Where(x => x.ResidentId == residentId && !x.IsDeleted).ToList();
            }
        }

        //public async Task<List<ResidentDocument>> GetAsyncByResidentId(int residentId)
        //{
        //    using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
        //    {
        //        return await context.ResidentDocument.Where(x => x.ResidentId == residentId && !x.IsDeleted).ToListAsync();
        //    }
        //}

        public ResidentDocument Add(ResidentDocument residentDocument)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.ResidentDocument.Add(residentDocument);
                context.SaveChanges();
                return residentDocument;
            }
        }

        public ResidentDocument Update(ResidentDocument residentDocument)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(residentDocument).State = EntityState.Modified;
                context.SaveChanges();
                return residentDocument;
            }
        }
    }
}
