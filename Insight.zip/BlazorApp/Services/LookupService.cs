﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Services
{
    public class LookupService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public LookupService(IConfiguration configuration)
        {
        }

        public LookupService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<AssetType> GetAssetTypes()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.AssetType.ToList();
            }
        }
    }
}
