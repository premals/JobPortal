﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using BlazorApp.Services.Interfaces;
using Microsoft.Extensions.Configuration;

namespace BlazorApp.Services
{
    public class RegionService : IRegionService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public RegionService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public RegionService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<Region> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Region.Include("Facilities").ToList();
            }
        }

        public Region Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Region.Find(id);
            }
        }

        public bool DuplicateRegionNameExists(string name, int currentRegionId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Region.Any(x => x.Name == name && x.Id != currentRegionId);
            }
        }

        public Region AddRegion(Region region)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Region.Add(region);
                context.SaveChanges();
                return region;
            }
        }

        public Region Add(Region region)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Region.Add(region);
                context.SaveChanges();
                return region;
            }
        }

        public Region Update(Region region)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(region).State = EntityState.Modified;
                context.SaveChanges();
                return region;
            }
        }
    }
}
