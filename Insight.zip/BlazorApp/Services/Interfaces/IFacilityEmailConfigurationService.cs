﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IFacilityEmailConfigurationService
    {
        List<FacilityEmailConfiguration> GetFacilityEmailConfigurationByFacility(int facilityId);
        void SaveFacilityEmailConfiguration(List<FacilityEmailConfiguration> configurations, int facilityId);
    }
}
