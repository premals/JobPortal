﻿using BlazorApp.Models;
using System.Threading.Tasks;

namespace BlazorApp.Services.Interfaces
{
    public interface IBrowserService
    {
        public Task<Dimensions> GetDimensions(string? toMeasure = null);
        public Task<int> GetHeight(string heightCalculatingFunction);
        public Task RegisterOnResizeCallback<T>(T component) where T : class;
    }
}
