﻿using System.Collections.Generic;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IFacilityDocumentService : IService<FacilityDocument>
    {
        List<FacilityDocument> GetByFacilityId(int facilityId);
    }
}