﻿using System.Collections.Generic;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IFacilityPlanNameService : IService<FacilityPlanName>
    {
        List<FacilityPlanName> GetByFacilityId(int facilityId);
    }
}
