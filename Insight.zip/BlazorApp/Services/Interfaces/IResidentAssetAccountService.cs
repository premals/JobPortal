﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IResidentAssetAccountService : IService<ResidentAssetAccount>
    {
        List<ResidentAssetAccount> GetAssetAccountsForResident(int residentId);
    }
}
