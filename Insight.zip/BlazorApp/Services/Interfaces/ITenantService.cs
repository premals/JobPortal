﻿using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface ITenantService
    {
        public Tenant Get(int id);

        public string GetConnectionString(string dbName);

        public Tenant Add(Tenant tenant);

        public Tenant Update(Tenant tenant);
    }
}
