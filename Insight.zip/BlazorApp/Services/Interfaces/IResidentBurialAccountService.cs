﻿using HelloWorld.Model.DataTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Services.Interfaces
{
    interface IResidentBurialAccountService : IService<ResidentBurialAccount>
    {

    }
}
