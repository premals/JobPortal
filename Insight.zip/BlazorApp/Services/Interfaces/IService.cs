﻿using System.Collections.Generic;

namespace BlazorApp.Services.Interfaces
{
    public interface IService<T>
    {
        List<T> Get();
        T Get(int id);
        T Add(T model);
        T Update(T model);
    }
}
