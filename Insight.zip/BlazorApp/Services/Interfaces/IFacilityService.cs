﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IFacilityService : IService<Facility>
    {
        public Facility GetFacilityWithRegion(int id);
    }
}
