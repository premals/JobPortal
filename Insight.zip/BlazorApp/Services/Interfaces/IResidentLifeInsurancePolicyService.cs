﻿using HelloWorld.Model.DataTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Services.Interfaces
{
    public interface IResidentLifeInsurancePolicyService : IService<ResidentLifeInsurancePolicy>
    {
        List<ResidentLifeInsurancePolicy> GetInsurancePoliciesForResident(int residentId);
    }
}
