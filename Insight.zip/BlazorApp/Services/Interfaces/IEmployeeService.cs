﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IEmployeeService : IService<Employee>
    {
        bool IsUsernameAvailable(string username, int id);
        List<Employee> GetEmployeesForNotifications();
        Employee GetByUsername(string username);
        Employee GetById(int employeeId);
        void AddEmployeeAccess(List<EmployeeAccessLevel> employeeAccess);
        void DeleteEmployeeAccessLevel(List<EmployeeAccessLevel> employeeAccess);
    }
}
