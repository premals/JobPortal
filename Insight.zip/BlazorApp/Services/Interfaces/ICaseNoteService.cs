﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface ICaseNoteService 
    {
        List<CaseNote> GetCaseNotesFollowUp(int facilityId);
        List<CaseNote> GetByResidentId(int residentId);
        CaseNote Add(CaseNote caseNote);
        CaseNote Update(CaseNote caseNote);
    }
}
