﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IRegionService : IService<Region>
    {
        bool DuplicateRegionNameExists(string name, int currentRegionId);
    }
}
