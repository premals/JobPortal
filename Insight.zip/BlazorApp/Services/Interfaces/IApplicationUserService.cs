﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorApp.Models;

namespace BlazorApp.Services.Interfaces
{
    public interface IApplicationUserService
    {
        ApplicationUser AddApplicationUser(ApplicationUser user);
        ApplicationUser GetApplicationUser(int employeeId, int tenantId);
        bool IsUsernameAvailable(string username, int employeeId, int tenantId);
    }
}
