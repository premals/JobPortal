﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;

namespace BlazorApp.Services.Interfaces
{
    public interface IResidentDocumentService : IService<ResidentDocument>
    {
        //Task<List<ResidentDocument>> GetAsyncByResidentId(int residentId);
        List<ResidentDocument> GetByResidentId(int residentId);
    }
}
