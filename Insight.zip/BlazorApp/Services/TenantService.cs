﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using HelloWorld.Model.DataTables;
using System.Linq.Dynamic.Core;
using System.Linq;

namespace BlazorApp.Services
{
    public class TenantService : ITenantService
    {
        private readonly IConfiguration _configuration;
        private IHttpContextAccessor _httpContextAccessor;
        private DbContextOptionsBuilder<HelloWorldConfigContext> _optionsBuilder;

        public TenantService(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldConfigContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldConfigContext"));
        }

        public Tenant Get(int id)
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                return context.Tenant.FirstOrDefault(x => x.Id == id);
            }
        }

        public string GetConnectionString(string dbName)
        {
            return _configuration.GetConnectionString("HelloWorldTenantContext").Replace("{dbName}", dbName);
        }

        public Tenant Add(Tenant tenant)
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                context.Tenant.Add(tenant);
                context.SaveChanges();
                return tenant;
            }
        }

        public Tenant Update(Tenant tenant)
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                context.Tenant.Update(tenant);
                context.SaveChanges();
                return tenant;
            }
        }
    }
}
