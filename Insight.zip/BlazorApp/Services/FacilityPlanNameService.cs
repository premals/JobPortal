﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;

namespace BlazorApp.Services
{
    public class FacilityPlanNameService : IFacilityPlanNameService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public FacilityPlanNameService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public FacilityPlanNameService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<FacilityPlanName> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPlanName.ToList();
            }
        }

        public FacilityPlanName Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPlanName.Find(id);
            }
        }

        public List<FacilityPlanName> GetByFacilityId(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPlanName.Where(x => x.FacilityId == facilityId && x.IsActive).ToList();
            }
        }

        public FacilityPlanName Add(FacilityPlanName facilityPlanName)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(facilityPlanName).State = EntityState.Added;
                context.FacilityPlanName.Add(facilityPlanName);
                context.SaveChanges();
                return facilityPlanName;
            }
        }

        public FacilityPlanName Update(FacilityPlanName facilityPlanName)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(facilityPlanName).State = EntityState.Modified;
                context.SaveChanges();
                return facilityPlanName;
            }
        }
    }
}
