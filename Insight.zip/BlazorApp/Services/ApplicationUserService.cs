﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorApp.Data;
using BlazorApp.Models;
using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace BlazorApp.Services
{
    public class ApplicationUserService : IApplicationUserService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<BlazorAppIdentityDbContext> _identityContextOptionsBuilder;
        public ApplicationUserService(IConfiguration configuration)
        {
            _configuration = configuration;
            _identityContextOptionsBuilder = new DbContextOptionsBuilder<BlazorAppIdentityDbContext>();
            _identityContextOptionsBuilder.UseSqlServer(_configuration.GetConnectionString("BlazorAppIdentityContext"));
        }

        public ApplicationUser AddApplicationUser(ApplicationUser user)
        {
            using (var context = new BlazorAppIdentityDbContext(_identityContextOptionsBuilder.Options))
            {
                context.Users.Add(user);
                context.SaveChanges();
                return user;
            }
        }

        public ApplicationUser GetApplicationUser(int employeeId, int tenantId)
        {
            using (var context = new BlazorAppIdentityDbContext(_identityContextOptionsBuilder.Options))
            {
                return context.Users.FirstOrDefault(x => x.EmployeeId == employeeId && x.TenantId == tenantId);
            }
        }

        public bool IsUsernameAvailable(string username, int employeeId, int tenantId)
        {
            using (var context = new BlazorAppIdentityDbContext(_identityContextOptionsBuilder.Options))
            {
                return context.Users.Any(x => x.UserName == username && x.EmployeeId != employeeId && x.TenantId == tenantId) == false;
            }
        }
    }
}