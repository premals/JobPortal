﻿using System.Linq;
using System.Collections.Generic;
using HelloWorld.Model.DataTables;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using BlazorApp.Services.Interfaces;
using Microsoft.Extensions.Configuration;

namespace BlazorApp.Services
{
    public class FacilityDocumentService : IFacilityDocumentService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public FacilityDocumentService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public FacilityDocumentService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }
        public List<FacilityDocument> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityDocument.ToList();
            }
        }

        public FacilityDocument Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityDocument.Find(id);
            }
        }

        public List<FacilityDocument> GetByFacilityId(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityDocument.Where(x => x.FacilityId == facilityId && !x.IsDeleted).ToList();
            }
        }

        public FacilityDocument Add(FacilityDocument facilityDocument)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.FacilityDocument.Add(facilityDocument);
                context.SaveChanges();
                return facilityDocument;
            }
        }

        public FacilityDocument Update(FacilityDocument facilityDocument)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(facilityDocument).State = EntityState.Modified;
                context.SaveChanges();
                return facilityDocument;
            }
        }
    }
}
