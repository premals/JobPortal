﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace BlazorApp.Services
{
    public class FacilityEmailConfigurationService 
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public FacilityEmailConfigurationService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public FacilityEmailConfigurationService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<FacilityEmailConfiguration> GetFacilityEmailConfigurationByFacility(int facilityId)
        {
            using var context = new HelloWorldTenantContext(_optionsBuilder.Options);
            return context.FacilityEmailConfiguration.Where(x => x.FacilityId == facilityId).ToList();
        }

        public void SaveFacilityEmailConfiguration(List<FacilityEmailConfiguration> configurations, int facilityId, int employeeId)
        {
            var existingFacilityEmailConfigurations = GetFacilityEmailConfigurationByFacility(facilityId);
            
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                foreach (var existingConfig in existingFacilityEmailConfigurations)
                {
                    if (configurations.Select(x => x.EmailNotificationTypeId).Contains(existingConfig.EmailNotificationTypeId))
                    {
                        continue;
                    }
                    else
                    {
                        context.Entry(existingConfig).State = EntityState.Deleted;
                    }
                }
                
                foreach (var configuration in configurations)
                {
                    if (existingFacilityEmailConfigurations.Select(x => x.EmailNotificationTypeId).Contains(configuration.EmailNotificationTypeId))
                    {
                        var existingConfig = existingFacilityEmailConfigurations.FirstOrDefault(x => x.EmailNotificationTypeId == configuration.EmailNotificationTypeId);
                        existingConfig.Day = configurations.FirstOrDefault()?.Day ?? 0;
                        existingConfig.Time = configurations.FirstOrDefault()?.Time ?? DateTime.Now;
                        existingConfig.UpdatedBy = employeeId;
                        existingConfig.UpdatedDate = DateTime.UtcNow;
                        context.Entry(existingConfig).State = EntityState.Modified;  
                    }
                    else
                    {
                        context.Set<FacilityEmailConfiguration>().Attach(configuration);
                        context.Entry(configuration).State = EntityState.Added;
                    }
                }
                context.SaveChanges();
            }
        }
    }
}
