﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorApp.Services.Interfaces;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace BlazorApp.Services
{
    public class CaseNoteService : ICaseNoteService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        //public CaseNoteService(IConfiguration configuration)
        //{
        //    _configuration = configuration;
        //    _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
        //    _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        //}
        public CaseNoteService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<CaseNote> GetCaseNotesByAssignee(int assigneeId, int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.CaseNote.Include(x => x.Resident)
                .Where(x => x.Resident.FacilityId == facilityId 
                            && x.Resident.ResidentStatusId != (int)ResidentStatuses.Discharged 
                            && x.Status != (int)CaseNoteStatus.Complete
                            && !x.IsDeleted
                            && x.AssigneeId == assigneeId)
                .OrderBy(x => x.Resident.LastName)
                .ThenBy(x => x.Resident.FirstName)
                .ToList();
            }
        }
        public List<CaseNote> GetCaseNotesFollowUp(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.CaseNote.Include(x => x.Resident)
                .Where(x => x.Resident.FacilityId == facilityId 
                                && x.Resident.ResidentStatusId != (int)ResidentStatuses.Discharged 
                                && x.Status != (int)CaseNoteStatus.Complete
                                && !x.IsDeleted
                                && (x.FollowUpDate != null || (!x.FollowUpDate.HasValue && (x.UpdatedDate.HasValue ? x.UpdatedDate.Value : x.CreatedDate) < DateTime.UtcNow.AddDays(-7))))
                .OrderBy(x => x.FollowUpDate)
                .ToList();
            }
        }

        public List<CaseNote> GetByResidentId(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.CaseNote.Where(x => x.ResidentId == residentId && !x.IsDeleted).ToList();
            }
        }

        public CaseNote Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.CaseNote.FirstOrDefault(x => x.Id == id);
            }
        }

        public CaseNote Add(CaseNote caseNote)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(caseNote).State = EntityState.Added;
                context.CaseNote.Add(caseNote);
                context.SaveChanges();
                return caseNote;
            }
        }

        public CaseNote Update(CaseNote caseNote)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(caseNote).State = EntityState.Modified;
                context.SaveChanges();
                return caseNote;
            }
        }
    }
}
