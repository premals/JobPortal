﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using BlazorApp.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace BlazorApp.Services
{
    public class ResidentAssetAccountService : IResidentAssetAccountService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public ResidentAssetAccountService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public ResidentAssetAccountService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public ResidentAssetAccount Add(ResidentAssetAccount account)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.ResidentAssetAccount.Add(account);
                context.SaveChanges();
                return Get(account.Id);
            }
        }

        public List<ResidentAssetAccount> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentAssetAccount.ToList();
            }
        }

        public List<ResidentAssetAccount> GetIncomesForResident(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentAssetAccount.Where(x => x.ResidentId == residentId && !x.IsDeleted).ToList();
            }
        }

        public ResidentAssetAccount Get(int id)
        {
            var account = new ResidentAssetAccount();

            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                account = context.ResidentAssetAccount.FirstOrDefault(x => x.Id == id);
            }

            return account;
        }

        public ResidentAssetAccount Update(ResidentAssetAccount account)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(account).State = EntityState.Modified;
                context.SaveChanges();
                return Get(account.Id);
            }
        }

        public List<ResidentAssetAccount> GetAssetAccountsForResident(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentAssetAccount.Where(x => x.ResidentId == residentId && !x.IsDeleted)
                    .Include(x => x.AssetType)
                    .ToList();
            }
        }
    }
}
