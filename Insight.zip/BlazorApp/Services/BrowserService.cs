﻿using BlazorApp.Services.Interfaces;
using BlazorApp.Models;

using Microsoft.JSInterop;
using System.Threading.Tasks;
using System;

namespace BlazorApp.Services
{
    public class BrowserService(IJSRuntime jsRuntime) : IBrowserService
    {
        private readonly IJSRuntime _jsRuntime = jsRuntime;

        public async Task<Dimensions> GetDimensions(string? toMeasure = null)
        {
            return await _jsRuntime.InvokeAsync<Dimensions>(toMeasure ?? "getDimensions");
        }

        public async Task<int> GetHeight(string heightCalculatingFunction)
        {
            return Convert.ToInt32(await _jsRuntime.InvokeAsync<double>(heightCalculatingFunction));
        }

        public async Task RegisterOnResizeCallback<T>(T component) where T : class
        {
            await _jsRuntime.InvokeVoidAsync("window.registerViewportChangeCallback", DotNetObjectReference.Create(component));
        }
    }
}
