﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using HelloWorld.Model.DataTables;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using BlazorApp.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using HelloWorld.Common.Enumerations;
using System.Text;
using SendGrid.Helpers.Mail;
using SendGrid;

namespace BlazorApp.Services
{
    public class EmployeeService : IEmployeeService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public EmployeeService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public EmployeeService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<Employee> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Employee.Include(x => x.Facility.Region).ToList();
            }
        }

        public List<Employee> GetEmployeesForNotifications()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Employee.Where(x => x.OptIntoEmail && !string.IsNullOrEmpty(x.Email)).ToList();
            }
        }

        public Employee Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var employee = context.Employee
                .Include(x => x.Facility.Region)
                .Include(x => x.EmployeeAccessLevel)
                .FirstOrDefault(x => x.Id == id);

                return employee;
            }
        }
        public Employee GetByUsername(string username)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var employee = context.Employee
                    .Include(x => x.Facility.Region)
                    .Include(x => x.EmployeeAccessLevel)
                    .FirstOrDefault(x => x.Username == username);

                return employee;
            }
        }

        public Employee GetById(int employeeId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var employee = context.Employee
                    .Include(x => x.Facility.Region)
                    .Include(x => x.EmployeeAccessLevel)
                    .FirstOrDefault(x => x.Id == employeeId);

                return employee;
            }
        }

        public Employee Add(Employee employee)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Employee.Add(employee);
                context.SaveChanges();
                return employee;
            }
        }

        public void AddEmployeeAccess(List<EmployeeAccessLevel> employeeAccess)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.AddRange(employeeAccess);
                context.SaveChanges();
            }
        }

        public Employee Update(Employee employee)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(employee).State = EntityState.Modified;
                context.SaveChanges();
                return employee;
            }
        }

        public bool IsUsernameAvailable(string username, int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var employees = from s in context.Employee.Where(x => x.Username == username && x.Id != id)
                                select s;

                return !employees.Any();
            }
        }

        public void DeleteEmployeeAccessLevel(List<EmployeeAccessLevel> employeeAccess)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.RemoveRange(employeeAccess);
                context.SaveChanges();
            }
        }

        public async Task<bool> SendWelcomeEmail(Employee employee, string tenantCode, string sendGridApiKey, string workstationName, bool firstTimeUser = true)
        {
            workstationName = firstTimeUser ? workstationName : "Please contact your administrator";

            StringBuilder plainText = new StringBuilder($"Hello, {employee.FirstName} and welcome to Insight!");
            plainText.Append("<br/><br/>");
            plainText.Append($"Below you will find your username, organization code, and workstation name you need to login to the Insight software solution. You will receive your passowrd in a separate email.");
            plainText.Append("<br/><br/>");
            plainText.Append("<ul>");
            plainText.Append($"<li>Site: https://insight.revsuitesolutions.com</li>");
            plainText.Append($"<li>Username: <b>{employee.Username}</b></li>");
            plainText.Append($"<li>Code: <b>{tenantCode}</b></li>");
            plainText.Append($"<li>Workstation: <b>{workstationName}</b></li>");
            plainText.Append("</ul>");
            plainText.Append("<br/><br/>");
            plainText.Append($"Again, we want to welcome you to Insight!");
            plainText.Append("<br/><br/>");
            plainText.Append("<br/><br/>");
            plainText.Append("From,<br/>");
            plainText.Append("All of us at Revsuite Solutions");

            var success = await SendEmail(employee, sendGridApiKey, plainText.ToString(), plainText.ToString());

            return success;
        }

        public async Task<bool> SendPasswordEmail(Employee employee, string password, string sendGridApiKey)
        {
            StringBuilder plainText = new StringBuilder($"Hello, {employee.FirstName} and welcome to Insight!");
            plainText.Append("<br/><br/>");
            plainText.Append($"Your first time user password is {password}<br/>");
            plainText.Append("<br/><br/>");
            plainText.Append("When you first login, you will be prompted to change your password.");
            plainText.Append("<br/><br/>");
            plainText.Append("<br/><br/>");
            plainText.Append("From,<br/>");
            plainText.Append("All of us at Revsuite Solutions");

            var success = await SendEmail(employee, sendGridApiKey, plainText.ToString(), plainText.ToString());

            return success;
        }

        public async Task<bool> SendCaseNoteApprovalEmail(Employee employee, Employee requestor, string residentNumber, string facilityName, string sendGridApiKey)
        {
            StringBuilder plainText = new StringBuilder($"{requestor.FirstName} {requestor.LastName} is requesting to mark a case note for Resident #{residentNumber} as complete in {facilityName}. Please review.");

            var success = await SendEmail(employee, sendGridApiKey, plainText.ToString(), plainText.ToString(), "Request to Complete Case Note");

            return success;
        }

        private async Task<bool> SendEmail(Employee employee, string sendGridApiKey, string plainText, string bodyText, string emailSubject = "")
        {
            var client = new SendGridClient(sendGridApiKey);

            var from = new EmailAddress("donotreply@revsuitesolutions.com", "RevSuite Solutions");
            var to = new EmailAddress(employee.Email);
            var subject = string.IsNullOrWhiteSpace(emailSubject) ? "Welcome to Insight!" : emailSubject;

            var plainTextContent = plainText.ToString();
            var htmlContent = bodyText.ToString();
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);

            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<Employee> GetEmployeeByFacility(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var employee = context.Employee
                .Include(x => x.Facility.Region)
                .Include(x => x.EmployeeAccessLevel)
                .Where(x => x.IsActive
                            && x.EmployeeAccessLevel.Where(x=>x.LevelTypeId == (int)AccessLevelType.Facility).Select(x=> x.EntityId).Contains(facilityId));

                return employee.ToList();
            }
        }

        public List<Employee> GetEmployeeByFacility(Facility facility)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var employees = context.Employee
                .Include(x => x.Facility.Region)
                .Include(x => x.EmployeeAccessLevel)
                .Where(x => x.IsActive);

                var result = new List<Employee>();

                foreach (var employee in employees)
                {
                    foreach (var accessLevel in employee.EmployeeAccessLevel)
                    {
                        if (accessLevel.LevelTypeId == (int)AccessLevelType.Tenant)
                        {
                            result.Add(employee);
                            continue;
                        }

                        if (accessLevel.LevelTypeId == (int)AccessLevelType.Region && facility.Region != null && accessLevel.EntityId == facility.Region.Id)
                        {
                            result.Add(employee);
                            continue;
                        }

                        if (accessLevel.LevelTypeId == (int)AccessLevelType.Facility && accessLevel.EntityId == facility.Id)
                        {
                            result.Add(employee);
                            continue;
                        }
                    }
                }

                return result;
            }
        }
    }
}
