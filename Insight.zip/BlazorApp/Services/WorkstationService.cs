﻿using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using BlazorApp.Models;
using HelloWorld.Common.Enumerations;
using Microsoft.Extensions.Configuration;

namespace BlazorApp.Services
{
    public class WorkstationService
    {
        private readonly DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public WorkstationService(IConfiguration configuration)
        {
        }

        public WorkstationService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<Workstation> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Workstation.ToList();
            }
        }

        public Workstation Get(int Id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Workstation.Find(Id);
            }
        }

        public Workstation GetByName(string name)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Workstation.FirstOrDefault(x => x.Name == name);
            }
        }

        public List<Workstation> GetWorkstationsForFacility(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Workstation.Where(w => w.FacilityId == facilityId && w.TypeId == (int)WorkStationTypes.Desktop && w.IsActive).ToList();
            }
        }

        public Workstation GetByFacilityId(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Workstation.FirstOrDefault(w => w.FacilityId == facilityId && w.TypeId == (int)WorkStationTypes.Desktop);
            }
        }

        public bool HasDuplicateName(string name, int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Workstation.Any(x => x.Id != id && x.Name == name && x.IsActive);
            }
        }

        public Workstation Add(Workstation workstation)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Workstation.Add(workstation);
                context.SaveChanges();
                return workstation;
            }
        }

        public Workstation Update(Workstation workstation)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(workstation).State = EntityState.Modified;
                context.SaveChanges();
                return workstation;
            }
        }
    }
}
