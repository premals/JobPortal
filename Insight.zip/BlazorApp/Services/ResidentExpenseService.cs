﻿using BlazorApp.Services.Interfaces;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp.Services
{
    public class ResidentExpenseService : IResidentExpenseService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public ResidentExpenseService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public ResidentExpenseService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public ResidentExpense Add(ResidentExpense expense)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.ResidentExpense.Add(expense);
                context.SaveChanges();
                return expense;
            }
        }

        public List<ResidentExpense> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentExpense.ToList();
            }
        }

        public ResidentExpense Get(int id)
        {
            var expense = new ResidentExpense();

            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                expense = context.ResidentExpense.FirstOrDefault(x => x.Id == id);
            }

            return expense;
        }

        public ResidentExpense Update(ResidentExpense expense)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(expense).State = EntityState.Modified;
                context.SaveChanges();
                return Get(expense.Id);
            }
        }
    }
}
