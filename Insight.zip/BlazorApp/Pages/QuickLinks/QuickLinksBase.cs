﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorApp.Services.Interfaces;
using HelloWorld.Model.DataTables;
using Microsoft.AspNetCore.Components;

namespace BlazorApp.Pages.QuickLinks
{
    public class QuickLinksBase : ComponentBase
    {
        //public IEnumerable<QuickLink> QuickLinks;

        //protected override void OnInitialized()
        //{
        //    QuickLinks = ConfigRepository.GetQuickLinks();
        //}
    }
}
