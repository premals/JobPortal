﻿using HelloWorld.Model.DataTables;
using HelloWorld.EntityFramework.Context;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace Insight.Common.Services
{
    public class FacilityService
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;


        public FacilityService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<Facility> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Facility.Include(x => x.Region).ToList();
            }
        }

        public List<Facility> GetAll(bool includeRegion)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                if (includeRegion)
                {
                    return context.Facility.Include(x => x.Region).ToList();
                }
                else
                {
                    return context.Facility.ToList();
                }
            }
        }

        public List<Facility> GetAllActive()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Facility.Where(x => x.IsActive).ToList();
            }
        }

        public Facility Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Facility.Find(id);
            }
        }

        public Facility GetFacilityWithRegion(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Facility.Include(x => x.Region).FirstOrDefault(x => x.Id == id);
            }
        }

        public bool HasDuplicateFacilityName(string name, int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Facility.Any(x => x.Id != id && x.Name == name);
            }
        }


        public Facility Add(Facility facility)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Facility.Add(facility);
                context.SaveChanges();
                return facility;
            }
        }

        public Facility Update(Facility facility)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(facility).State = EntityState.Modified;
                context.SaveChanges();
                return facility;
            }
        }

        public Facility GetByExternalFacilityId(int facId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Facility.FirstOrDefault(x => x.ExternalFacilityId == facId);
            }
        }
    }
}
