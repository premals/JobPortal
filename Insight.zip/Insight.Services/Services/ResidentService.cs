﻿using Azure;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;

namespace Insight.Common.Services
{
    public class ResidentService
    {
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public ResidentService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<Resident> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.Include(x => x.Facility).ToList();
            }
        }

        public Resident GetByPccPatientId(int pccPatientId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.FirstOrDefault(x => x.PccId == pccPatientId);
            }
        }

        public Resident GetByMatrixPatientId(string matrixPatientId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.FirstOrDefault(x => x.MatrixId == matrixPatientId);
            }
        }

        public Resident GetByResidentNumber(string residentNumber, int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.FirstOrDefault(x => x.ResidentNumber == residentNumber && x.FacilityId == facilityId);
            }
        }

        public Resident GetMatch(string firstName, string lastName, DateTime dateOfBirth, int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.FirstOrDefault(x => x.FirstName.ToUpper() == firstName.ToUpper() && x.LastName.ToUpper() == lastName.ToUpper() && x.DateOfBirth == dateOfBirth && x.FacilityId == facilityId);
            }
        }

        public List<Resident> GetAllByFacilityId(int facilityId, bool includeDeleted = false)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.FacilityId == facilityId && (includeDeleted == true ? true : !x.IsDeleted))
                    .Include(x => x.Facility)
                    .Include(x => x.Facility.Region)
                    .Include(x => x.CompletedChecklistItems)
                    .Include(x => x.ResidentPayers)
                    .ToList();
            }
        }

        public Resident Get(int id)
        {
            var resident = new Resident();
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                resident = context.Resident
                    .Include(x => x.Facility)
                    .Include(x => x.ResidentDocuments)
                    .Include(x => x.ResidentIncomes.Where(i => !i.IsDeleted))
                    .Include(x => x.ResidentAssetAccounts.Where(i => !i.IsDeleted))
                    .Include(x => x.ResidentBurialAccounts)
                    .Include(x => x.ResidentExpenses.Where(i => !i.IsDeleted))
                    .Include(x => x.CompletedChecklistItems)
                    .Include(x => x.ResidentPayers)
                    .FirstOrDefault(x => x.Id == id);
            }
            return resident;
        }

        public List<Resident> GetResidentsWithTemporaryLevelOfCare(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.IsLevelOfCareTemporary == true
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetResidentsWithTemporaryLevelOfCare(List<int> facilityIds)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.IsLevelOfCareTemporary == true
                                && facilityIds.Contains(x.FacilityId)
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetResidentsWithLevelOfCareNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => !x.LevelOfCareDate.HasValue
                                && x.AdmissionDate.HasValue
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetFollowUpUmedApplications(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.IsUmedNeeded == true
                                && x.UmedApplicationDate != null
                                && x.UmedDecisionDate == null
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetMedicaidApplicationsNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.AdmissionDate != null
                                && x.MedicaidApplicationDate == null
                                && x.ResidentStatusId == (int)ResidentStatuses.Resident
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }
        public List<Resident> GetMedicaidRecertificationNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var result = context.Resident
                    .Where(x => x.DischargeDate == null
                                && x.RecertificationDate != null
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();

                return result.Where(x => (Convert.ToDateTime(x.RecertificationDate) - DateTime.Now.Date).TotalDays <= 60).ToList();
            }
        }

        public List<Resident> GetLTCPlanNameMissing(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.MedicaidApprovedDate != null
                                && x.LTCEffectiveDate == null
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetLTCPlanNameMissing(List<int> facilityIds)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.MedicaidApprovedDate != null
                                && x.LTCEffectiveDate == null
                                && facilityIds.Contains(x.FacilityId)
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetMMAAuthorizationNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.MMAEffectiveDate != null
                                && string.IsNullOrWhiteSpace(x.MMAAuthorizationNumber)
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetLTCAuthorizationNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.LTCEffectiveDate != null
                                && (string.IsNullOrWhiteSpace(x.LTCAuthorizationNumber) || (x.LTCAuthorizationEndDate == null ? false : x.LTCAuthorizationEndDate < DateTime.UtcNow))
                                && x.FacilityId == facilityId
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<ResidentDocument> GetResidentDocuments(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentDocument.Where(x => x.ResidentId == residentId).ToList();
            }
        }

        public List<ResidentCompletedChecklistItem> GetResidentCompletedItems(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentCompletedChecklistItems.Where(x => x.ResidentId == residentId).ToList();
            }
        }

        public void SaveChecklistItems(List<ResidentCompletedChecklistItem> originalItemList, List<ResidentCompletedChecklistItem> newItemsList)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                foreach (var item in originalItemList)
                {
                    if (!newItemsList.Any(x => x.ChecklistItemId == item.ChecklistItemId))
                    {
                        context.Entry(item).State = EntityState.Deleted;
                    }
                }

                foreach (var item in newItemsList)
                {
                    if (!originalItemList.Any(x => x.ChecklistItemId == item.ChecklistItemId))
                    {
                        context.Entry(item).State = EntityState.Added;
                    }
                }

                context.SaveChanges();
            }
        }

        public void AddCompletedChecklistItem(ResidentCompletedChecklistItem item)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(item).State = EntityState.Added;

                context.SaveChanges();
            }
        }

        public void RemoveCompletedChecklistItem(ResidentCompletedChecklistItem item)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(item).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        public void AddResidentPayer(ResidentPayer payer)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(payer).State = EntityState.Added;

                context.SaveChanges();
            }
        }

        public List<ResidentPayer> GetResidentPayers(int residentId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.ResidentPayers.Where(x => x.ResidentId == residentId).OrderBy(x => x.PayerRank).ToList();
            }
        }

        public void UpdateResidentPayer(ResidentPayer payer)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(payer).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void DeleteResidentPayer(ResidentPayer payer)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(payer).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }

        public Resident Add(Resident resident)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Resident.Add(resident);
                context.SaveChanges();
                return resident;
            }
        }

        public Resident Update(Resident resident)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(resident).State = EntityState.Modified;
                context.SaveChanges();
                return Get(resident.Id);
            }
        }

        public List<Resident> GetPccResidentsToSync(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.Where(x => x.IsDeleted == false && x.PccId == null && x.FacilityId == facilityId &&
                (!string.IsNullOrWhiteSpace(x.ResidentNumber)
                || !string.IsNullOrWhiteSpace(x.FirstName) && !string.IsNullOrWhiteSpace(x.LastName) && x.DateOfBirth != null)).ToList();
            }
        }

        public List<Resident> GetAllPccResidents()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.Where(x => !x.IsDeleted && x.PccId != null)
                    .Include(x => x.ResidentPayers)
                    .ToList();
            }
        }

        public ApplicationStatusInfo GetResidentApplicationStatusInfo(Resident resident, List<string> approvedPayerCodes)
        {
            var statusInfo = new ApplicationStatusInfo();

            if (IsMedicaidApproved(resident, approvedPayerCodes))
            {
                if (resident.RecertificationDate.HasValue && resident.ShowAsMedicaidPending)
                {
                    statusInfo.StatusColor = "color: white; background: #FFC107;";
                    statusInfo.StatusText = $"Pending Recert";
                    statusInfo.ImagePath = "images/PendingRecert.png";
                }
                else
                {
                    statusInfo.StatusColor = "color: white; background: rgba(0,200,83,1);";
                    statusInfo.StatusText = "Approved";
                    statusInfo.ImagePath = "images/Approved.png";
                }
            }
            else
            {
                if (!resident.MedicaidApplicationDate.HasValue)
                {
                    statusInfo.StatusColor = "color: white; background: #bdbdbd;";
                    statusInfo.StatusText = "Application Needed";
                    statusInfo.ImagePath = "images/AppPending.png";
                }
                else
                {
                    if (resident.MedicaidDeniedDate.HasValue)
                    {
                        if (resident.IsAppealNeeded.HasValue)
                        {
                            if (resident.IsAppealNeeded == true)
                            {
                                if (!resident.IsAppealApproved.HasValue)
                                {
                                    statusInfo.StatusColor = "color: white; background: #FFC107;";
                                    statusInfo.StatusText = $"Pending Appeal";
                                    statusInfo.ImagePath = "images/Appeal.png";
                                }
                                else
                                {
                                    if (resident.IsAppealApproved == true)
                                    {
                                        statusInfo.StatusColor = "color: white; background: rgba(0,200,83,1);";
                                        statusInfo.StatusText = "Approved";
                                        statusInfo.ImagePath = "images/Approved.png";
                                    }
                                    else
                                    {
                                        if (resident.IsHearingNeeded.HasValue)
                                        {
                                            if (resident.IsHearingNeeded == true)
                                            {
                                                if (resident.IsHearingApproved.HasValue)
                                                {
                                                    if (resident.IsHearingApproved == true)
                                                    {
                                                        statusInfo.StatusColor = "color: white; background: rgba(0,200,83,1);";
                                                        statusInfo.StatusText = "Approved";
                                                        statusInfo.ImagePath = "images/Approved.png";
                                                    }
                                                    else
                                                    {
                                                        statusInfo.StatusColor = "color: white; background: #F44336;";
                                                        statusInfo.StatusText = "Denied";
                                                        statusInfo.ImagePath = "images/Denied.png";
                                                    }
                                                }
                                                else
                                                {
                                                    statusInfo.StatusColor = "color: white; background: #FF9800;";
                                                    statusInfo.StatusText = $"Pending Hearing";
                                                    statusInfo.ImagePath = "images/Hearing.png";
                                                }
                                            }
                                            else
                                            {
                                                statusInfo.StatusColor = "color: white; background: #F44336;";
                                                statusInfo.StatusText = "Denied - No Hearing";
                                                statusInfo.ImagePath = "images/Denied.png";
                                            }
                                        }
                                        else
                                        {
                                            statusInfo.StatusColor = "color: white; background: #FF9800;";
                                            statusInfo.StatusText = "Hearing - TBD";
                                            statusInfo.ImagePath = "images/Hearing.png";
                                        }
                                    }
                                }
                            }
                            else
                            {
                                statusInfo.StatusColor = "color: white; background: #F44336;";
                                statusInfo.StatusText = "Denied - No Appeal";
                                statusInfo.ImagePath = "images/Denied.png";
                            }
                        }
                        else
                        {
                            statusInfo.StatusColor = "color: white; background: #FFC107;";
                            statusInfo.StatusText = "Appeal - TBD";
                            statusInfo.ImagePath = "images/Appeal.png";
                        }
                    }
                    else
                    {
                        statusInfo.StatusColor = "color: white; background: #4FC3F7;";
                        statusInfo.StatusText = "Pending Approval";
                        statusInfo.ImagePath = "images/PendingApproval.png";
                    }
                }
            }

            return statusInfo;
        }

        private bool IsMedicaidApproved(Resident resident, List<string> approvedPayerCodes)
        {
            if (resident.MedicaidApprovedDate.HasValue)
            {
                return true;
            }

            if (!resident.ResidentPayers.Any())
            {
                return false;
            }

            if (approvedPayerCodes.Any())
            {
                if (resident.ResidentPayers.Any(p => p.PayerRank == 1 && approvedPayerCodes.Contains(p.PayerCode)))
                {
                    return true;
                }

                if (resident.Facility.IncludeSecondaryPayer && resident.ResidentPayers.Any(p => p.PayerRank == 2 && approvedPayerCodes.Contains(p.PayerCode)))
                {
                    return true;
                }

                if (resident.Facility.IncludeTertiaryPayer && resident.ResidentPayers.Any(p => p.PayerRank == 3 && approvedPayerCodes.Contains(p.PayerCode)))
                {
                    return true;
                }

                if (resident.Facility.IncludeFourthPayer && resident.ResidentPayers.Any(p => p.PayerRank == 4 && approvedPayerCodes.Contains(p.PayerCode)))
                {
                    return true;
                }

                if (resident.Facility.IncludeFifthPayer && resident.ResidentPayers.Any(p => p.PayerRank == 5 && approvedPayerCodes.Contains(p.PayerCode)))
                {
                    return true;
                }
            }

            return false;
        }

        public List<Resident> GetWaystarMedicaidApprovals(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var result = context.Resident
                    .Where(x => x.MedicaidEligibilityResult != null 
                            && x.MedicaidEligibilityResult.IsCleared != true
                            && x.FacilityId == facilityId)
                    .Include(x => x.MedicaidEligibilityResult)
                    .ToList();

                return result;
            }
        }

        public void SaveMedicaidEligibilityResult(MedicaidEligibilityResult medicaidEligibilityResult)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                if (medicaidEligibilityResult.Id > 0)
                {
                    context.Entry(medicaidEligibilityResult).State = EntityState.Modified;
                }
                else
                {
                    context.Add(medicaidEligibilityResult);
                }

                context.SaveChanges();
            }
        }

        #region Reports
        public List<Resident> GetMedicaidApprovalReportData(DateTime? startDate, DateTime? endDate, List<int> facilityIds, List<string> approvedPayerCodes)
        {
            var residents = new List<Resident>();
            var residentsToReturn = new List<Resident>();
            var approvedResidents = new List<Resident>();

            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            
            {
                var allResidents = context.Resident
                        .Include(x => x.Facility)
                        .Include(x => x.ResidentPayers)
                        .Where(x => facilityIds.Contains(x.FacilityId)
                                    && !x.IsDeleted)
                        .ToList();

                foreach (var id in facilityIds)
                {
                    residents = allResidents.Where(x => x.FacilityId == id).ToList();

                    foreach (var resident in residents)
                    {
                        if (resident.MedicaidApprovedDate.HasValue)
                        {
                            approvedResidents.Add(resident);
                            continue;
                        }

                        if (resident.ResidentPayers.Any(p => p.PayerRank == 1 && approvedPayerCodes.Contains(p.PayerCode)))
                        {
                            approvedResidents.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeSecondaryPayer && resident.ResidentPayers.Any(p => p.PayerRank == 2 && approvedPayerCodes.Contains(p.PayerCode)))
                        {
                            approvedResidents.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeTertiaryPayer && resident.ResidentPayers.Any(p => p.PayerRank == 3 && approvedPayerCodes.Contains(p.PayerCode)))
                        {
                            approvedResidents.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeFourthPayer && resident.ResidentPayers.Any(p => p.PayerRank == 4 && approvedPayerCodes.Contains(p.PayerCode)))
                        {
                            approvedResidents.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeFifthPayer && resident.ResidentPayers.Any(p => p.PayerRank == 5 && approvedPayerCodes.Contains(p.PayerCode)))
                        {
                            approvedResidents.Add(resident);
                            continue;
                        }
                    }
                }

                if (startDate == null)
                {
                    if (endDate == null)
                    {
                        residentsToReturn = approvedResidents;
                    }
                    else
                    {
                        residentsToReturn = approvedResidents
                                .Where(x => x.MedicaidApprovedDate <= endDate)
                                .ToList();
                    }
                }
                else
                {
                    if (endDate == null)
                    {
                        residentsToReturn = approvedResidents
                                .Where(x => x.MedicaidApprovedDate >= startDate)
                                .ToList();
                    }
                    else
                    {
                        residentsToReturn = approvedResidents
                                .Where(x => x.MedicaidApprovedDate >= startDate
                                            && x.MedicaidApprovedDate <= endDate)
                                .ToList();
                    }
                }
            }

            return residentsToReturn
                    .Distinct()
                    .OrderBy(x => x.LastName)
                    .ThenBy(x => x.FirstName)
                    .ToList();
        }

        public List<Resident> GetMedicaidPendingReport(List<int> facilityIds, List<string> medicaidPendingCodes)
        {
            var residents = new List<Resident>();
            var residentsToReturn = new List<Resident>();


            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                var allResidents = context.Resident
                        .Include(x => x.ResidentNotes.OrderByDescending(x => x.CreatedDate))
                        .Include(x => x.ResidentIncomes)
                        .Include(x => x.ResidentExpenses)
                        .Include(x => x.Facility)
                        .Include(x => x.CompletedChecklistItems)
                        .Include(x => x.ResidentPayers)
                        .Where(x => facilityIds.Contains(x.FacilityId)
                                    && !x.IsDeleted
                                    && !x.MedicaidApprovedDate.HasValue)
                        .ToList();

                foreach (var id in facilityIds)
                {
                    residents = allResidents.Where(x => x.FacilityId == id).ToList();

                    foreach (var resident in residents)
                    {
                        if (resident.ResidentPayers.Any(p => p.PayerRank == 1 && medicaidPendingCodes.Contains(p.PayerCode)))
                        {
                            residentsToReturn.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeSecondaryPayer && resident.ResidentPayers.Any(p => p.PayerRank == 2 && medicaidPendingCodes.Contains(p.PayerCode)))
                        {
                            residentsToReturn.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeTertiaryPayer && resident.ResidentPayers.Any(p => p.PayerRank == 3 && medicaidPendingCodes.Contains(p.PayerCode)))
                        {
                            residentsToReturn.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeFourthPayer && resident.ResidentPayers.Any(p => p.PayerRank == 4 && medicaidPendingCodes.Contains(p.PayerCode)))
                        {
                            residentsToReturn.Add(resident);
                            continue;
                        }

                        if (resident.Facility.IncludeFifthPayer && resident.ResidentPayers.Any(p => p.PayerRank == 5 && medicaidPendingCodes.Contains(p.PayerCode)))
                        {
                            residentsToReturn.Add(resident);
                            continue;
                        }

                        if (resident.ShowAsMedicaidPending)
                        {
                            residentsToReturn.Add(resident);
                            continue;
                        }

                        if (!resident.ResidentPayers.Any() && !resident.PccId.HasValue && string.IsNullOrEmpty(resident.MatrixId))
                        {
                            residentsToReturn.Add(resident);
                            continue;
                        }
                    }
                }
            }

            return residentsToReturn
                .Distinct()
                .OrderBy(x => x.LastName)
                .ThenBy(x => x.FirstName)
                .ToList();
        }

        public List<Resident> GetLTCPlanNeededReport(List<int> facilityIds)
        {
            return GetLTCPlanNameMissing(facilityIds);
        }

        public List<Resident> GetMedicaidRecertificationReportData(DateTime? startDate, DateTime? endDate, List<int> facilityIds)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                if (startDate == null && endDate == null)
                {
                    return context.Resident
                        .Where(x => facilityIds.Contains(x.FacilityId)
                                    && !x.IsDeleted)
                        .Include(x => x.Facility)
                        .ToList();
                }

                if (startDate != null && endDate == null)
                {
                    return context.Resident
                        .Where(x => facilityIds.Contains(x.FacilityId)
                                    && x.RecertificationDate >= startDate
                                    && !x.IsDeleted)
                        .Include(x => x.Facility)
                        .ToList();
                }

                if (startDate == null)
                {

                    return context.Resident
                        .Where(x => facilityIds.Contains(x.FacilityId)
                                    && x.RecertificationDate <= endDate
                                    && !x.IsDeleted)
                        .Include(x => x.Facility)
                        .ToList();
                }

                return context.Resident
                    .Where(x => facilityIds.Contains(x.FacilityId)
                                && x.RecertificationDate >= startDate
                                && x.RecertificationDate <= endDate
                                && !x.IsDeleted)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }

        public List<Resident> GetPatientResourceLiabilityReportData(int selectStatusFilter, List<int> facilityIds)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                if (selectStatusFilter == 0)
                {
                    return context.Resident
                        .Include(x => x.Facility)
                        .Include(x => x.ResidentIncomes)
                        .Include(x => x.ResidentExpenses)
                        .Where(x => facilityIds.Contains(x.FacilityId)
                                    && x.AdmissionDate != null
                                    && x.DischargeDate == null
                                    && !x.IsDeleted)
                        .OrderBy(x => x.LastName)
                        .ThenBy(x => x.FirstName)
                        .ToList();
                }

                return context.Resident
                    .Include(x => x.Facility)
                    .Include(x => x.ResidentIncomes)
                    .Include(x => x.ResidentExpenses)
                    .Where(x => facilityIds.Contains(x.FacilityId)
                                && x.ResidentStatusId == (int)ResidentStatuses.Resident
                                && x.AdmissionDate != null
                                && x.DischargeDate == null
                                && !x.IsDeleted)
                    .OrderBy(x => x.LastName)
                    .ThenBy(x => x.FirstName)
                    .ToList();
            }
        }

        public List<Resident> GetMmaDsnpDaysUsedReport(List<int> facilityIds)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Include(x => x.Facility)
                    .Where(x => facilityIds.Contains(x.FacilityId)
                                && x.AdmissionDate != null
                                && x.MMAEffectiveDate != null
                                && x.LTCEffectiveDate == null
                                && x.DischargeDate == null
                                && !x.IsDeleted)
                    .ToList();
            }
        }

        #endregion
    }

    public class ApplicationStatusInfo
    {
        public string StatusColor { get; set; }
        public string ImagePath { get; set; }
        public string StatusText { get; set; }
    }

}
