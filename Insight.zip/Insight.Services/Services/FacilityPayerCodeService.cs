﻿using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Insight.Common.Services
{
    public class FacilityPayerCodeService 
    {
        private IConfiguration _configuration;
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public FacilityPayerCodeService(IConfiguration configuration)
        {
            _configuration = configuration;
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("HelloWorldTenantContext"));
        }

        public FacilityPayerCodeService(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<FacilityPayerCode> Get()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPayerCode.ToList();
            }
        }

        public FacilityPayerCode Get(int id)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPayerCode.Find(id);
            }
        }

        public List<FacilityPayerCode> GetByFacilityId(int facilityId, int payerTypeId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPayerCode.Where(x => x.FacilityId == facilityId && x.PayerTypeId == payerTypeId).ToList();
            }
        }

        public List<FacilityPayerCode> GetByFacilityId(int facilityId, List<int> payerTypeIds)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPayerCode.Where(x => x.FacilityId == facilityId && payerTypeIds.Contains(x.PayerTypeId)).ToList();
            }
        }

        public List<FacilityPayerCode> GetByFacilityId(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityPayerCode.Where(x => x.FacilityId == facilityId).ToList();
            }
        }

        public FacilityPayerCode Add(FacilityPayerCode payerCode)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(payerCode).State = EntityState.Added;
                context.FacilityPayerCode.Add(payerCode);
                context.SaveChanges();
                return payerCode;
            }
        }

        public FacilityPayerCode Update(FacilityPayerCode payerCode)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(payerCode).State = EntityState.Modified;
                context.SaveChanges();
                return payerCode;
            }
        }

        public void Delete(FacilityPayerCode payerCode)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                context.Entry(payerCode).State = EntityState.Deleted;
                context.SaveChanges();
            }
        }
    }
}
