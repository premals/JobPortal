﻿using HelloWorld.Common.Enumerations;
using HelloWorld.Common.Helpers;
using HelloWorld.EntityFramework.Interfaces;
using HelloWorld.Model.DataTables;
using Insight.Common.Services;
using NHapi.Base.Model;
using NHapi.Model.V25.Datatype;
using NHapi.Model.V25.Segment;

namespace Integration.Matrix
{
    public class MatrixWebhookService : V25BaseModel
    {
        public FacilityPayerCodeService _facilityPayerCodeService;
        public ResidentService _residentService;
        public string _connectionString;

        public MatrixWebhookService(string connectionString, IConfigRepository configRepository)
        {
            _connectionString = connectionString;
            _facilityPayerCodeService = new FacilityPayerCodeService(connectionString);
            _residentService = new ResidentService(_connectionString);
        }

        private string? GetEventType(IMessage message)
        {
            //Directly grab event type from the message structure
            var msh = (message.GetStructure("MSH") as NHapi.Model.V25.Segment.MSH);

            string? eventType = msh?.MessageType?.TriggerEvent?.Value;
            return eventType;
        }


        public void ProcessEvent(IMessage message, int facilityId)
        {
            // Directly grab event type from the message structure
            var eventType = GetEventType(message);
            if (string.IsNullOrWhiteSpace(eventType))
            {
                throw new Exception("Event type is missing.");
            }

            switch (eventType)
            {
                case "A01"://Admission
                case "A08"://Update
                    {
                        AddUpdateMedicaidResident(message, facilityId, eventType, true);
                        break;
                    }
                case "A03"://Discharge
                case "A11"://Cancel Admission
                case "A13"://Cancel Discharge
                    {
                        AddUpdateMedicaidResident(message, facilityId, eventType, false);
                        break;
                    }
                default:
                    return;
            }
        }
        /// <summary>
        /// Check if Matrix Patient has Medicaid payer type
        ///     If yes, add to Insight if they do not exist already
        /// </summary>
        /// <param name="patientId"></param>
        /// <param name="addResidentIfMissing"></param>
        /// <returns></returns>
        public void AddUpdateMedicaidResident(IMessage message, int facilityId, string? eventType, bool addResidentIfMissing = true)
        {
            var pid = (PID)message.GetStructure("PID");

            var internalPatientId = GetInternalPatientId(pid);

            if (string.IsNullOrEmpty(internalPatientId))
            {
                throw new Exception($"Internal PatientId not found.");
            }

            var existingResident = _residentService.GetByMatrixPatientId(internalPatientId);

            if (existingResident == null)
            {
                existingResident = FindResidentMatch(pid, facilityId);

                if (existingResident != null)
                {
                    UpdateResident(pid, message, existingResident, facilityId, eventType);
                }
                else
                {
                    if (addResidentIfMissing == true)
                    {
                        SaveNewResident(message, facilityId, internalPatientId, eventType);
                    }
                }
            }
            else
            {
                UpdateResident(pid, message, existingResident, facilityId, eventType);
            }
        }

        private string GetInternalPatientId(PID pid)
        {
            var identifiers = pid.GetPatientIdentifierList();
            string fiId = identifiers
                .FirstOrDefault(x => x.IdentifierTypeCode.Value == "FI")
            ?.IDNumber.Value ?? "";
            return fiId;
        }


        private void UpdateResident(PID pid, IMessage message, Resident resident, int facilityId, string? eventType)
        {
            var pv1 = (PV1)message.GetStructure("PV1");

            SetResidentInfo(pid, pv1, message, resident);
            SetDemographics(pid, message, resident);
            UpdateResidentPayers(resident, message);
            SetCloseCase(resident, message, pv1, eventType);
            SetWebhookModification(resident);
            _residentService.Update(resident);
        }

        public void SaveNewResident(IMessage message, int facilityId, string internalPatientId, string? eventType)
        {
            var residentService = new ResidentService(_connectionString);

            var patientFound = residentService.GetByMatrixPatientId(internalPatientId);

            if (patientFound != null)
            {
                throw new Exception($"Patient {internalPatientId} already exists: {patientFound.FirstName} {patientFound.LastName}.");
            }

            var facilityService = new FacilityService(_connectionString);
            var facility = facilityService.Get(facilityId);

            List<int> payerLevelsToInclude =
            [
                1
            ];

            if (facility.IncludeSecondaryPayer)
            {
                payerLevelsToInclude.Add(2);
            }

            if (facility.IncludeTertiaryPayer)
            {
                payerLevelsToInclude.Add(3);
            }

            if (facility.IncludeFourthPayer)
            {
                payerLevelsToInclude.Add(4);
            }

            if (facility.IncludeFifthPayer)
            {
                payerLevelsToInclude.Add(5);
            }


            if (HasMatchingPayerCode(facilityId, message, payerLevelsToInclude))
            {
                var resident = new Resident
                {
                    FacilityId = facilityId
                };

                var pid = (PID)message.GetStructure("PID");
                var pv1 = (PV1)message.GetStructure("PV1");

                SetResidentInfo(pid, pv1, message, resident);
                SetDemographics(pid, message, resident);
                SetCloseCase(resident, message, pv1, eventType);
                SetWebhookModification(resident);
                resident.CreatedBy = 0;
                resident.CreatedDate = DateTime.UtcNow;
                var newResident = residentService.Add(resident);

                AddResidentPayerCodes(newResident, message);
            }
        }

        private void SetWebhookModification(Resident resident)
        {
            resident.UpdatedBy = 0;
            resident.UpdatedDate = DateTime.UtcNow;
        }

        private Resident? FindResidentMatch(PID pid, int facilityId)
        {
            Resident? existingResident = null;
            var residentService = new ResidentService(_connectionString);
            var facilityService = new FacilityService(_connectionString);

            string residentNumber = GetResidentNumber(pid);
            existingResident = residentService.GetByResidentNumber(residentNumber, facilityId);
            if (existingResident == null)
            {
                var patientName = pid.GetPatientName().FirstOrDefault();

                var firstName = patientName?.GivenName?.Value ?? "";
                var lastName = patientName?.FamilyName?.Surname?.Value ?? "";
                DateTime? dob = null;

                if (pid.DateTimeOfBirth != null && pid.DateTimeOfBirth.Time != null && !string.IsNullOrEmpty(pid.DateTimeOfBirth.Time.Value))
                {
                    dob = ConvertToDateTime(pid.DateTimeOfBirth.Time.Value);
                }

                existingResident = residentService.GetMatch(firstName, lastName, Convert.ToDateTime(dob), facilityId);
            }
            return existingResident;
        }

        public void SetDemographics(PID pid, IMessage message, Resident resident)
        {
            var patientName = pid.GetPatientName().FirstOrDefault();

            resident.FirstName = patientName?.GivenName?.Value ?? "";
            resident.LastName = patientName?.FamilyName?.Surname?.Value ?? "";
            resident.MiddleInitial = string.IsNullOrEmpty(patientName?.SecondAndFurtherGivenNamesOrInitialsThereof?.Value)
                                        ? null
                                        : patientName.SecondAndFurtherGivenNamesOrInitialsThereof.Value.Substring(0, 1);

            DateTime? dob = null;
            if (pid.DateTimeOfBirth != null && pid.DateTimeOfBirth.Time != null && !string.IsNullOrEmpty(pid.DateTimeOfBirth.Time.Value))
            {
                dob = ConvertToDateTime(pid.DateTimeOfBirth.Time.Value);
            }
            resident.DateOfBirth = dob;

            string? ssn = pid.SSNNumberPatient?.Value;
            resident.SocialSecurityNumber = !string.IsNullOrEmpty(ssn) ? CryptographyHelper.Encrypt(ssn) : "";

            XAD address = pid.GetPatientAddress(0);

            resident.AddressLine1 = address?.StreetAddress?.StreetOrMailingAddress?.Value ?? "";
            resident.AddressLine2 = address?.OtherDesignation?.Value ?? "";
            resident.StateCode = address?.StateOrProvince?.Value ?? "";

            var zipCode = address?.ZipOrPostalCode?.Value;
            resident.Zip = !string.IsNullOrWhiteSpace(zipCode)
                ? zipCode.Length < 5
                    ? zipCode
                    : zipCode.Substring(0, 5)
                : string.Empty;

            resident.City = address?.City?.Value ?? "";

            if (message.Names.Contains("NK1"))
            {
                var contacts = message.GetAll("NK1");
                foreach (var contact in contacts)
                {
                    var nk1 = (NK1)contact;
                    if (string.Equals(nk1.Relationship.Text.Value, "Resident", StringComparison.OrdinalIgnoreCase))
                    {
                        var xtns = nk1.GetPhoneNumber();  // XTN[] from NK1-5

                        XTN ph = xtns.FirstOrDefault(x => x.TelecommunicationEquipmentType?.Value == "PH");
                        if (ph != null)
                        {
                            string phone = ph?.AreaCityCode.Value + ph?.LocalNumber?.Value;
                            string email = ph?.EmailAddress?.Value;
                            var phoneNumber = phone?.Replace("-", "").Replace("(", "").Replace(")", "").Replace(" ", "").Trim();
                            resident.Phone = phoneNumber?.Length == 10 ? phoneNumber : null;
                            resident.PhoneExt = (string.IsNullOrEmpty(ph?.Extension?.Value) || ph?.Extension?.Value?.Length > 25) ? null : ph?.Extension?.Value;
                            resident.Email = email ?? "";
                        }
                        break;
                    }
                }
            }

            resident.GenderId = 0;
            resident.GenderDescription = pid.AdministrativeSex?.Value;
            resident.ResidentNumber = GetResidentNumber(pid);

            resident.MaritalStatusId = 0;
            resident.MaritalStatusDescription = pid.MaritalStatus?.Text?.Value;
            resident.PrimaryLanguageId = 0;
            resident.LanguageDescription = pid.PrimaryLanguage?.Text?.Value;
            resident.PlanType = (int)MmaType.MMA;

        }

        private string GetResidentNumber(PID pid)
        {
            var patientIds = pid.GetPatientIdentifierList();

            foreach (var cx in patientIds)
            {
                // IdentifierTypeCode is usually component 5 in CX data type
                if (cx.IdentifierTypeCode != null && cx.IdentifierTypeCode.Value == "MR")
                {
                    string mrn = cx.IDNumber.Value;
                    return mrn;
                }
            }
            return null;
        }

        private void SetResidentInfo(PID pid, PV1 pv1, IMessage message, Resident resident)
        {
            var internalPatientId = pid.PatientID.IDNumber.Value;
            resident.MatrixId = internalPatientId;

            if (pv1.AdmitDateTime != null && pv1.AdmitDateTime.Time != null && !string.IsNullOrEmpty(pv1.AdmitDateTime.Time.Value))
            {
                resident.AdmissionDate = pv1.AdmitDateTime != null ? ConvertToDateTime(pv1.AdmitDateTime.Time.Value) : null;
            }

            var ts = (TS)pv1.GetField(45, 0);
            var dischargeDate = ConvertToDateTime(ts?.Time?.Value);
            if (dischargeDate != null)
            {
                resident.ResidentStatusId = (int)ResidentStatuses.Discharged;

                var field36 = pv1.GetField(36, 0);
                var disposition = (IS)field36;
                string code = disposition?.Value ?? "";
                resident.DischargeLocation = GetDischargeLocation(code);
                resident.DischargeDate = dischargeDate;
            }
            else
            {
                resident.ResidentStatusId = (int)ResidentStatuses.Resident;
                resident.DischargeDate = null;
                resident.DischargeLocation = null;
            }

            SetMedicaidNumber(resident, message);
        }

        private string? GetDischargeLocation(string code)
        {
            return code switch
            {
                "01" => "Home",
                "02" or "43" => "Hospital",
                "03" => "Nursing Home",
                "04" => "ICF",
                "06" => "Home Health",
                "07" => "Unknown AMA",
                "20" => "Funeral Home",
                "21" => "Law Enforcement",
                "41" => "Expired/Medical Facility",
                "42" => "Expired/Unknown",
                "50" => "Hospice/Home",
                "51" => "Hospice Facility",
                "62" => "Rehab Facility",
                "63" => "LTC Hospital",
                _ => null,
            };
        }

        /// <summary>
        /// Close Case for Resident when there is no Admission type (includes Readmission)
        /// </summary>
        /// <param name="resident"></param>
        /// <param name="adtRecords"></param>
        private void SetCloseCase(Resident resident, IMessage message, PV1 pv1, string? eventType)
        {
            var medicaidPayerCodes = _facilityPayerCodeService.GetByFacilityId(resident.FacilityId, (int)PayerCodeTypeEnum.Medicaid).OrderBy(x => x.Code).ToList();
            var mostRecentCensus = FindPayer(message, 1);
            var dischargeDateTime = pv1.GetDischargeDateTime();
            var expiredCodes = new List<int> { 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 40, 41, 42 };
            string dispositionCode = null;
            var field36 = pv1.GetField(36);
            // Usually it's a single value, so access the first element
            if (field36.Length > 0)
            {
                dispositionCode = field36[0].ToString();
            }

            if (mostRecentCensus != null)
            {
                string payerName = GetPayerName(mostRecentCensus);
                int dashIndex = payerName.IndexOf(" - ");
                string firstHalf = dashIndex >= 0
                    ? payerName.Substring(0, dashIndex)
                    : payerName;

                if (resident.IsDeleted && !medicaidPayerCodes.Any(x => string.Equals(x.Code, firstHalf, StringComparison.OrdinalIgnoreCase)))
                {
                    return;
                }               

                if (mostRecentCensus != null && dischargeDateTime != null && !string.IsNullOrEmpty(dispositionCode)
                    && expiredCodes.Contains(Convert.ToInt32(dispositionCode))
                      && medicaidPayerCodes.Any(x => string.Equals(x.Code, firstHalf, StringComparison.OrdinalIgnoreCase)))
                {
                    resident.IsDeleted = true;
                    return;
                }
                resident.IsDeleted = false;
            }
            else if (eventType == "A03" || eventType == "A11" || eventType == "A13")
            {
                if (mostRecentCensus != null && dischargeDateTime != null && !string.IsNullOrEmpty(dispositionCode)
                    && expiredCodes.Contains(Convert.ToInt32(dispositionCode)))
                {
                    resident.IsDeleted = true;
                    return;
                }
                resident.IsDeleted = false;
            }
            else
            {
                resident.IsDeleted = true;
            }
        }

        private string GetPayerName(IN1 in1)
        {
            XON xon = in1.GetInsuranceCompanyName(0);
            return xon.OrganizationName?.Value ?? "";
        }

        private void AddResidentPayerCodes(Resident resident, IMessage message)
        {
            if (message.Names.Contains("INSURANCE"))
            {
                var insuranceGroups = message.GetAll("INSURANCE");

                foreach (IGroup g in insuranceGroups)
                {
                    var in1 = (IN1)g.GetStructure("IN1");
                    XON xon = in1.GetInsuranceCompanyName(0);
                    string payerName = xon.OrganizationName?.Value ?? "";

                    // component 4 = CheckDigit in XON
                    string priority = xon.CheckDigit?.Value;

                    if (priority != null)
                    {
                        int dashIndex = payerName.IndexOf(" - ");

                        string firstHalf = dashIndex >= 0
                            ? payerName.Substring(0, dashIndex)
                            : payerName;

                        _residentService.AddResidentPayer(new ResidentPayer()
                        {
                            ResidentId = resident.Id,
                            PayerRank = Convert.ToInt32(priority),
                            PayerCode = firstHalf,
                            PayerName = firstHalf
                        });
                    }
                }
            }
        }

        private void UpdateResidentPayers(Resident resident, IMessage message)
        {
            List<ResidentPayer> messagePayers = new List<ResidentPayer>();

            if (message.Names.Contains("INSURANCE"))
            {
                var insuranceGroups = message.GetAll("INSURANCE");

                foreach (IGroup g in insuranceGroups)
                {
                    var in1 = (IN1)g.GetStructure("IN1");
                    XON xon = in1.GetInsuranceCompanyName(0);
                    string payerName = xon.OrganizationName?.Value ?? "";

                    // component 4 = CheckDigit in XON
                    string priority = xon.CheckDigit?.Value;

                    if (priority != null)
                    {
                        int dashIndex = payerName.IndexOf(" - ");

                        string firstHalf = dashIndex >= 0
                            ? payerName.Substring(0, dashIndex)
                            : payerName;

                        messagePayers.Add(new ResidentPayer()
                        {
                            ResidentId = resident.Id,
                            PayerRank = Convert.ToInt32(priority),
                            PayerCode = firstHalf,
                            PayerName = firstHalf
                        });
                    }
                }
            }

            var currentPayers = _residentService.GetResidentPayers(resident.Id);

            foreach (var currentPayer in currentPayers)
            {
                var payer = messagePayers.FirstOrDefault(x => x.PayerRank == currentPayer.PayerRank);
                if (payer != null)
                {
                    currentPayer.PayerName = payer.PayerName;
                    currentPayer.PayerCode = payer.PayerCode;
                    _residentService.UpdateResidentPayer(currentPayer);
                }
                else
                {
                    _residentService.DeleteResidentPayer(currentPayer);
                }
            }

            //Need to see if we need to add any. 
            currentPayers = _residentService.GetResidentPayers(resident.Id);

            foreach (var payer in messagePayers)
            {
                if (!currentPayers.Any(x => x.PayerRank == payer.PayerRank))
                {
                    _residentService.AddResidentPayer(payer);
                }
            }
        }

        private bool HasMatchingPayerCode(int facilityId, IMessage message, List<int> payerLevelsToInclude)
        {
            var facilityPayerCodes = _facilityPayerCodeService.GetByFacilityId(facilityId).OrderBy(x => x.Code).ToList();

            foreach (var payerLevel in payerLevelsToInclude)
            {
                var payer = FindPayer(message, payerLevel);

                if (payer != null)
                {
                    XON xon = payer.GetInsuranceCompanyName(0);
                    string payerName = xon.OrganizationName?.Value ?? "";
                    if (!string.IsNullOrEmpty(payerName))
                    {
                        int dashIndex = payerName.IndexOf(" - ");
                        string firstHalf = dashIndex >= 0
                            ? payerName.Substring(0, dashIndex)
                            : payerName;

                        if (facilityPayerCodes.Any(x => string.Equals(x.Code, firstHalf, StringComparison.OrdinalIgnoreCase)))
                        {
                            return true;
                        }
                    }
                    break;

                }
            }
            return false;
        }

        private IN1 FindPayer(IMessage msg, int priorityId)
        {
            if (msg.Names.Contains("INSURANCE"))
            {
                var insuranceGroups = msg.GetAll("INSURANCE");

                foreach (IGroup g in insuranceGroups)
                {
                    var in1 = (IN1)g.GetStructure("IN1");
                    XON xon = in1.GetInsuranceCompanyName(0);

                    // component 4 = CheckDigit in XON
                    string priority = xon.CheckDigit?.Value;

                    if (priority == priorityId.ToString())
                    {
                        return in1;
                    }
                }
            }

            return null;
        }

        private DateTime? ConvertToDateTime(string date)
        {
            if (DateTime.TryParseExact(
                    date,
                    new[] { "yyyyMMdd", "yyyyMMddHHmmss" },
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None,
                    out DateTime parsedDob))
            {
                return parsedDob;
            }

            return null;
        }

        private void SetMedicaidNumber(Resident resident, IMessage message)
        {
            if (message.Names.Contains("INSURANCE"))
            {
                var insuranceGroups = message.GetAll("INSURANCE");

                foreach (IGroup g in insuranceGroups)
                {
                    var in1 = (IN1)g.GetStructure("IN1");
                    XON xon = in1.GetInsuranceCompanyName(0);
                    string payerName = xon.OrganizationName?.Value ?? "";

                    string priority = xon.CheckDigit?.Value;

                    if (priority != null)
                    {
                        int dashIndex = payerName.IndexOf(" - ");

                        string firstHalf = dashIndex >= 0
                            ? payerName.Substring(0, dashIndex)
                            : payerName;

                        resident.MedicaidNumber = in1.GetField(36, 0).ToString();

                    }
                }
            }
        }
    }
}
