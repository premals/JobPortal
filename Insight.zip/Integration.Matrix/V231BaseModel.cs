﻿using NHapi.Model.V231.Segment;

namespace Integration.Matrix
{
    public class V231BaseModel
    {
        public PID PID { get; set; }
        public PV1 PV1 { get; set; }
        public IN1 IN1 { get; set; }
    }

}
