﻿using System;
using System.Collections.Generic;
using System.Linq;
using EmailNotificationService.FunctionApp.Repository;
using HelloWorld.Common.Enumerations;
using HelloWorld.Model.DataTables;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using SendGrid;
using SendGrid.Helpers.Mail;
using HelloWorld.Common.Helpers;

namespace EmailNotificationService.FunctionApp.Helper
{
    public class EmailNotificationHelper
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _log;

        private string _sendGridApiKey;

        public EmailNotificationHelper(IConfiguration configuration, ILogger log)
        {
            _configuration = configuration;
            _log = log;
        }

        public void Run()
        {
            var configRepository = new HelloWorld.EntityFramework.ConfigRepository(_configuration);

            var emailNotifications = configRepository.GetEmailNotifications();

            _log.LogInformation($"Getting Send Grid Data");
            var kvUri = _configuration.GetSection("AzureKeyVaultUri").Value;
            var secretClient = new SecretClient(new Uri(kvUri), new DefaultAzureCredential());
            var secret = secretClient.GetSecret("rs-sendgrid-api-key");
            _sendGridApiKey = secret.Value.Value;
            _log.LogInformation($"Successfully Retrieved Send Grid Data");

            _log.LogInformation($"Retrieved {emailNotifications} Email Notifications to send");

            foreach (var emailNotification in emailNotifications)
            {
                var tenantResult = configRepository.GetTenantById(emailNotification.TenantId);
                string connectionString = string.Empty;
                var currentDate = DateTime.UtcNow;

                if (tenantResult != null)
                {
                    string connectionStringToFmt = _configuration.GetConnectionString("HelloWorldTenantContext").Replace("dbName", "0");

                    connectionString = string.Format(connectionStringToFmt, emailNotification.Tenant.DatabaseName);
                }

                if (string.IsNullOrEmpty(connectionString))
                {
                    _log.LogError($"Unable to retrieve connection string for Tenant ID {emailNotification.Id}");
                    return;
                }

                var tenantRepository = new TenantRepository(connectionString);

                var emailConfigurations = tenantRepository.GetFacilityEmailConfigurations();

                if (emailConfigurations.Any())
                {
                    var facilities = emailConfigurations.Select(x => x.FacilityId).Distinct();

                    foreach (var facilityId in facilities)
                    {
                        try
                        {
                            var facilityEmailConfigurations =
                                emailConfigurations.Where(x => x.FacilityId == facilityId).ToList();

                            var facility = tenantRepository.GetFacility(facilityId);

                            var employees = GetEmployees(facilityId, tenantRepository);

                            var emailNotificationTypes = configRepository.GetEmailNotificationTypes();
                            var executeTime = emailNotification.TimeToExecute ?? currentDate;

                            string bodyText = string.Empty;
                            string plainText = string.Empty;

                            if (executeTime <= currentDate)
                            {
                                foreach (var emailConfiguration in facilityEmailConfigurations)
                                {
                                    var emailType = emailNotificationTypes.FirstOrDefault(x =>
                                        x.Id == emailConfiguration.EmailNotificationTypeId);

                                    try
                                    {
                                        var template = emailType?.Template;

                                        if (emailType != null)
                                        {
                                            int count = 0;

                                            if (emailType.Id == (int)EmailNotificationTypeEnum.MedicaidApplicationsNeeded)
                                            {
                                                count =
                                                    tenantRepository.GetMedicaidApplicationsNeeded(facility.Id)
                                                        ?.Count ?? 0;
                                            }
                                            else if (emailType.Id == (int)EmailNotificationTypeEnum.TemporaryLevelofCare)
                                            {
                                                count = tenantRepository
                                                    .GetResidentsWithTemporaryLevelOfCare(facility.Id)
                                                    ?.Count ?? 0;
                                            }
                                            else if (emailType.Id == (int)EmailNotificationTypeEnum.LTCManagedCarePlansNeeded)
                                            {
                                                count = tenantRepository
                                                    .GetltcplanneededReport(
                                                        facility.Id)?.Count ?? 0;
                                            }
                                            else if (emailType.Id == (int)EmailNotificationTypeEnum.LTCAuthorizationNeeded)
                                            {
                                                count = tenantRepository.GetLTCAuthorizationNeeded(facility.Id)
                                                    ?.Count ?? 0;
                                            }
                                            else if (emailType.Id == (int)EmailNotificationTypeEnum.MMAAuthorizationsNeeded)
                                            {
                                                count = tenantRepository.GetMMAAuthorizationNeeded(facility.Id)
                                                    ?.Count ?? 0;
                                            }
                                            else if (emailType.Id == (int)EmailNotificationTypeEnum.UmedApplicationsFollowUpsNeeded)
                                            {
                                                count = tenantRepository.GetFollowUpUmedApplications(facility.Id)
                                                            ?.Count ??
                                                        0;
                                            }
                                            else if (emailType.Id == (int)EmailNotificationTypeEnum.CaseNotesFollowUpsNeeded)
                                            {
                                                count = tenantRepository.GetCaseNotesFollowUp(facility.Id)?.Count ??
                                                        0;
                                            }

                                            plainText += String.Format(template, count);

                                            bodyText += !string.IsNullOrEmpty(bodyText)
                                                ? "<br />" + String.Format(template, count)
                                                : String.Format(template, count);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        _log.LogError($"Tenant {emailNotification.TenantId} - Facility {facilityId} - EmailType {emailType.Id}. Error: {ex.InnerException?.Message ?? ex.Message}");
                                    }
                                }

                                _log.LogInformation($"Sending Emails to {employees.Count} Employees for Tenant {emailNotification.TenantId} Facility {facilityId}");

                                foreach (var employee in employees)
                                {
                                    try
                                    {
                                        var client = new SendGridClient(_sendGridApiKey);

                                        var from = new EmailAddress("donotreply@revsuitesolutions.com", "RevSuite Solutions");
                                        var to = new EmailAddress(employee.Email);
                                        var subject = $"Task Board Summary for {facility.Name}";

                                        var msg = MailHelper.CreateSingleEmail(from, to, subject, plainText, bodyText);
                                        var response = client.SendEmailAsync(msg);
                                    }
                                    catch (Exception ex)
                                    {
                                        _log.LogError($"Tenant {emailNotification.TenantId} - Facility {facilityId} - Employee {employee.Id}. Error: {ex.InnerException?.Message ?? ex.Message}");
                                    }
                                }

                                emailNotification.TimeToExecute = executeTime.AddDays(7);
                                configRepository.SaveEmailNotification(emailNotification);
                            }
                        }
                        catch (Exception ex)
                        {
                            _log.LogError($"Tenant {emailNotification.TenantId} - Facility {facilityId}. Error: {ex.InnerException?.Message ?? ex.Message}");
                        }

                    }
                }

                _log.LogInformation($"Successfully sent emails for Tenant {emailNotification.TenantId}");
            }
        }

        private static List<Employee> GetEmployees(int facilityId, TenantRepository tenantRepository)
        {
            List<Employee> employees = new List<Employee>();

            foreach (var employee in tenantRepository.GetEmployeesForNotifications(facilityId))
            {
                var employeeAccessLevels = employee.EmployeeAccessLevel.FirstOrDefault(y => y.LevelTypeId == (int)AccessLevelType.Facility && y.EntityId == facilityId);

                if (employeeAccessLevels != null)
                {
                    employees.Add(employee);
                }
            }

            return employees;
        }
    }
}
