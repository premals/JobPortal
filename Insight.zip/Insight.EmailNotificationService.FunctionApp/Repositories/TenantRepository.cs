﻿using System.Collections.Generic;
using System.Linq;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;

namespace EmailNotificationService.FunctionApp.Repository
{
    public class TenantRepository
    {
        private DbContextOptionsBuilder<HelloWorldTenantContext> _optionsBuilder;

        public TenantRepository(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldTenantContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<FacilityEmailConfiguration> GetFacilityEmailConfigurations()
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.FacilityEmailConfiguration.ToList();
            }
        }

        public List<Employee> GetEmployeesForNotifications(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Employee
                    .Include(x => x.EmployeeAccessLevel)
                    .Where(x => x.OptIntoEmail && !string.IsNullOrEmpty(x.Email)).ToList();
            }
        }

        public Facility GetFacility(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Facility.FirstOrDefault(x => x.Id == facilityId);
            }
        }

        public List<Resident> GetResidentsWithTemporaryLevelOfCare(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.IsLevelOfCareTemporary == true
                                && x.FacilityId == facilityId)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }
        public List<Resident> GetFollowUpUmedApplications(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                .Where(x => x.IsUmedNeeded == true
                            && x.UmedApplicationDate != null
                            && x.UmedDecisionDate == null
                            && x.FacilityId == facilityId)
                .Include(x => x.Facility)
                .ToList();
            }
        }

        public List<Resident> GetMedicaidApplicationsNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                .Where(x => x.AdmissionDate != null
                    && x.MedicaidApplicationDate == null
                    && x.ResidentStatusId == (int)ResidentStatuses.Resident
                    && x.FacilityId == facilityId)
                .Include(x => x.Facility)
                .ToList();
            }
        }

        public List<Resident> GetMMAAuthorizationNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                .Where(x => x.MedicaidApprovedDate != null
                    && x.MMAAuthorizationNumber == null
                    && x.LTCPlanName == null
                    && x.FacilityId == facilityId)
                .Include(x => x.Facility)
                .ToList();
            }
        }

        public List<Resident> GetLTCAuthorizationNeeded(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident
                    .Where(x => x.LTCPlanName != null
                                && x.LTCAuthorizationNumber == null
                                && x.FacilityId == facilityId)
                    .Include(x => x.Facility)
                    .ToList();
            }
        }
        public List<Resident> GetltcplanneededReport(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.Resident.Include(x => x.ResidentNotes).Where(x =>
                    x.MedicaidEffectiveDate != null
                    && !string.IsNullOrEmpty(x.MMAPlanName)
                    && x.FacilityId == facilityId).ToList();
            }
        }
        public List<CaseNote> GetCaseNotesFollowUp(int facilityId)
        {
            using (var context = new HelloWorldTenantContext(_optionsBuilder.Options))
            {
                return context.CaseNote.Include(x => x.Resident)
                    .Where(x => x.Status != (int)CaseNoteStatus.Complete && x.FollowUpDate != null && x.Resident.FacilityId == facilityId)
                    .OrderBy(x => x.FollowUpDate)
                    .ToList();
            }
        }
    }

}
