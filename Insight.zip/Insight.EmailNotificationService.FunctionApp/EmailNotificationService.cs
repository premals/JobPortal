using System;
using System.Reflection;
using EmailNotificationService.FunctionApp.Helper;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Insight.EmailNotificationService.FunctionApp
{
    public class EmailNotificationService
    {
        private readonly ILogger<EmailNotificationService> _logger;

        public EmailNotificationService(ILogger<EmailNotificationService> logger)
        {
            _logger = logger;
        }

        [Function("EmailNotificationService")]
        public void Run([TimerTrigger("*/60 * * * * *")] TimerInfo myTimer, ExecutionContext context)
        {
            _logger.LogInformation($"Starting EmailNotificationService Function app");

            try
            {
                var config = new ConfigurationBuilder()
                    .SetBasePath(Path.GetFullPath(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)))
                    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables()
                    .Build();

                var emailNotificationHelper = new EmailNotificationHelper(config, _logger);
                emailNotificationHelper.Run();

            }
            catch (Exception ex)
            {
                _logger.LogError($"Error: {ex.InnerException?.Message ?? ex.Message}");
                return;
            }

            _logger.LogInformation($"Completed EmailNotificationService Function app");

            return;
        }
    }
}
