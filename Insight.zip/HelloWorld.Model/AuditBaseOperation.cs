﻿using System;

namespace HelloWorld.Model
{
    public class AuditBaseOperation
    {
        public int CreatedBy { get; set; }

        public DateTimeOffset CreatedDate { get; set; }

        public int? UpdatedBy { get; set; }

        public DateTimeOffset? UpdatedDate { get; set; }
    }
}
