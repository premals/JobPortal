﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentAssetAccount")]
    public class ResidentAssetAccount : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }
        public int ResidentId { get; set; }
        public int AssetTypeId { get; set; }
        public decimal Amount { get; set; }
        
        [MaxLength(100)]
        public string Name { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsSpouseAccount { get; set; }
        public virtual AssetType AssetType { get; set; }
    }
}
