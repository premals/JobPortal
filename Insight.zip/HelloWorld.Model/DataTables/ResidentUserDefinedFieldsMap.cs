﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentUserDefinedFieldsMap")]
    public class ResidentUserDefinedFieldsMap
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }
        public int FacilityId { get; set; }
        public string RecertificationDate { get; set; }
        public string MedicaidApprovedDate {  get; set; }
    }
}
