﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using HelloWorld.Common.Helpers;
using HelloWorld.Common.Enumerations;
using HelloWorld.Common.DataAnnotations;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentExpense")]
    public class ResidentExpense : AuditBaseOperation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public int ResidentId { get; set; }

        [Required]
        public int ExpenseType { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [MaxLength(100)]
        public string Description { get; set; }

        [Required]
        public bool IsSpouseExpense { get; set; }

        [Required]
        public bool IsDeleted { get; set; }
    }
}
