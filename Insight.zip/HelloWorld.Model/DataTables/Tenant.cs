﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("Tenant")]
    public class Tenant : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [Required]
        public string TenantName { get; set; }

        public string LegalName { get; set; }

        [Required]
        public string TenantCode { get; set; }

        [Required]
        public string Domain { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string City { get; set; }

        public string StateCode { get; set; }

        public string Zip { get; set; }

        public int CountryId { get; set; }

        public string DatabaseName { get; set; }

        public bool IsUsingRegion { get; set; }

        public bool IsSandbox { get; set; }

        public bool IsActive { get; set; }

        public DateTimeOffset? InActiveDate { get; set; }

        public bool ShowPcc { get; set; }
        public string PccOrgUUID { get; set; }
        public bool WaystarActive { get; set; }
        public int FacilityLimit { get; set; }
    }
}
