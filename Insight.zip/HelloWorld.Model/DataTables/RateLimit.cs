﻿using System;

namespace HelloWorld.Model.DataTables
{
    public class RateLimit
    {
        public int Id { get; set; }
        public int Entity { get; set; }
        public DateTime? TimeToReset { get; set; }
    }
}
