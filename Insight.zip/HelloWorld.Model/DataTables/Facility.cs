﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("Facility")]
    public class Facility : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [ForeignKey("Region")]
        public int? RegionId { get; set; }

        [Required(ErrorMessage = "Facility Name is required!")]
        [Display(Name = "Facility Name")]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Address is required!")]
        [Display(Name = "Address Line 1")]
        [MaxLength(50)]
        public string AddressLine1 { get; set; }

        [Display(Name = "Address Line 2")]
        [MaxLength(50)]
        public string AddressLine2 { get; set; }

        [Required(ErrorMessage = "City is required!")]
        [Display(Name = "City")]
        [MaxLength(50)]
        public string City { get; set; }

        [Required(ErrorMessage = "State is required!")]
        [Display(Name = "State")]
        public string StateCode { get; set; }


        [Required(ErrorMessage = "Zip is required!")]
        [Display(Name = "Zip")]
        [MaxLength(5)]
        public string Zip { get; set; }


        [Display(Name = "Primary Phone")]
        public string PrimaryPhone { get; set; }

        [Display(Name = "Primary Phone Ext")]
        [MaxLength(25)]
        public string PrimaryPhoneExt { get; set; }

        [Display(Name = "Secondary Phone")]
        public string SecondaryPhone { get; set; }

        [Display(Name = "Second Phone Ext")]
        [MaxLength(25)]
        public string SecondaryPhoneExt { get; set; }

        [Display(Name = "Fax")]
        public string Fax { get; set; }

        [Display(Name = "Email")]
        [RegularExpression("^[A-Za-z0-9_\\+-]+(\\.[A-Za-z0-9_\\+-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*\\.([A-Za-z]{2,4})$", ErrorMessage = "Invalid email address")]
        [MaxLength(50)]
        public string Email { get; set; }

        [Display(Name = "Is Active?")]
        public bool IsActive { get; set; }

        [Display(Name = "Time Zone Id")]
        public string TimeZoneId { get; set; }

        [NotMapped]
        [Display(Name = "Time Zone")]
        public string TimeZoneName { 
            get
            {
                if (string.IsNullOrEmpty(TimeZoneId))
                {
                    return string.Empty;
                }

                return TimeZoneInfo.FindSystemTimeZoneById(TimeZoneId)?.DisplayName ?? string.Empty;
            }
        }

        [Display(Name = "Observes Daylight Savings?")]
        public bool IsDstObserved { get; set; }

        [Required(ErrorMessage = "Patient Liability Allowance is required!")]
        [Display(Name = "Patient Liability Allowance")]
        public decimal PatientLiabilityAllowance { get; set; }

        [Required(ErrorMessage = "Daily Rate is required!")]
        public decimal DailyRate { get; set; }

        [Required(ErrorMessage = "QIT Required Threshold is required!")]
        public decimal QitRequiredThreshold { get; set; }

        [Required(ErrorMessage = "Resident Asset Maximum is required!")]
        public decimal ResidentAssetMaximum { get; set; }

        [Required(ErrorMessage = "Resident with Spouse Maximum Asset Amount is required!")]
        public decimal ResidentWithSpouseAssetMaximum { get; set; }

        public bool DefaultFacilityAddress { get; set; }
        public int? ExternalFacilityId { get; set; }
        public DateTime? PccActiveDate { get; set; }
        public DateTime? PccEndDate { get; set; }
        public bool IncludeSecondaryPayer { get; set; }
        public bool IncludeTertiaryPayer { get; set; }
        public bool IncludeFourthPayer { get; set; }
        public bool IncludeFifthPayer { get; set; }
        public virtual Region Region { get; set; }
        public bool IsEqualTo(Facility other)
        {
            foreach (var prop in typeof(Facility).GetProperties())
            {
                var value1 = prop.GetValue(this);
                var value2 = prop.GetValue(other);
                if (value1 is null)
                {
                    if (value2 is not null)
                    {
                        return false;
                    }
                }
                else
                {
                    if (!value1.Equals(value2))
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
