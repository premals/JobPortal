﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("MedicaidEligibilityResult")]
    public class MedicaidEligibilityResult
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [ForeignKey("Resident")]
        public int ResidentId { get; set; }

        [Display(Name = "Medicaid Eligible")]
        public bool IsMedicaidEligible { get; set; }

        [Display(Name = "Pending Recheck")]
        public bool IsPendingRecheck { get; set; }

        [Display(Name = "Missing Info")]
        public bool IsMissingInfo { get; set; }

        [Display(Name = "Error Description")]
        public string ErrorDescription { get; set; }

        [Display(Name = "Approval Check Date")]
        public DateTime CheckDate { get; set; }

        public DateTime CreatedDate { get; set; }

        [Display(Name = "Is Cleared")]
        public bool IsCleared { get; set; }

        public virtual Resident Resident { get; set; }
    }
}
