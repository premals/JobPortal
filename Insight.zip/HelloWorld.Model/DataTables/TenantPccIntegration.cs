﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("TenantPccIntegration")]
    public class TenantPccIntegration
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [Required]
        public string OrgUUID { get; set;}

        [Required]
        public int TenantId { get; set; }

        [Required]
        public int FacilityId { get; set; }

        [Required]
        public bool ShowPcc { get; set; }
    }
}
