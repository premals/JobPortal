﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("WorkStation")]
    public class Workstation : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Workstation Name")]
        [MaxLength(25)]
        public string Name { get; set; }

        [MaxLength(50)]
        public string Description { get; set; }

        public int FacilityId { get; set; }

        [Required]
        [Display(Name = "Workstation Type")]
        public int TypeId { get; set; }

        [Display(Name = "Active?")]
        public bool IsActive { get; set; }

        [Display(Name = "Idle URL")]
        [MaxLength(50)]
        public string IdleUrl { get; set; }

        [Display(Name = "Parent Workstation")]
        public int ParentWorkstationId { get; set; }
    }
}
