﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using HelloWorld.Common.Helpers;
using HelloWorld.Common.Enumerations;
using HelloWorld.Common.DataAnnotations;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentIncome")]
    public class ResidentIncome : AuditBaseOperation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public int ResidentId { get; set; }

        [Required]
        public int IncomeType { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [MaxLength(25)]
        public string Description { get; set; }

        public bool IsDeleted { get; set; }

        public bool IsSpouseIncome { get; set; }
    }
}
