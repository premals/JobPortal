﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("MatrixIntegration")]
    public class MatrixIntegration
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [Required]
        public string MatrixFacilityCode { get; set;}

        [Required]
        public string MatrixFacilityName { get; set; }

        [Required]
        public int FacilityId { get; set; }
        [Required]
        public int TenantId { get; set; }

        [Required]
        public bool IsEnabled { get; set; }
    }
}
