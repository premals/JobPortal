﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HelloWorld.Model.DataTables
{
    [Table("FacilityPlanName")]
    public class FacilityPlanName : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }
        public int FacilityId { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
    }
}
