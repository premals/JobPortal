﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HelloWorld.Model.DataTables
{
    [Table("EmailNotification")]
    public class EmailNotification
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }
        public int TenantId { get; set; }
        public int FacilityId { get; set; }
        public DateTime? TimeToExecute { get; set; }
        public virtual Tenant Tenant { get; set; }
    }
}
