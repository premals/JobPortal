﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HelloWorld.Model.DataTables
{
    [Table("FacilityEmailConfiguration")]
    public class FacilityEmailConfiguration
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public int FacilityId { get; set; }
        public int Day { get; set; }
        public DateTime Time { get; set; }
        public int EmailNotificationTypeId { get; set; }
        public int CreatedBy { get; set; }
        public DateTimeOffset CreatedDate { get; set; } = DateTime.UtcNow;
        public int? UpdatedBy { get; set; }
        public DateTimeOffset? UpdatedDate { get; set; } 
    }
}
