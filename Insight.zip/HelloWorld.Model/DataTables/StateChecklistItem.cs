﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("StateChecklistItem")]
    public class StateChecklistItem
    {
        [Key]
        public int Id { get; set; }
        public int StateId { get; set; }
        public string Name { get; set; }
    }
}
