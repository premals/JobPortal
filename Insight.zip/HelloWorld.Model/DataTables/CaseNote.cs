﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("CaseNote")]
    public class CaseNote : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [ForeignKey("Resident")]
        public int ResidentId { get; set; }

        [Required]
        [MaxLength(4000)]
        public string Note { get; set; }

        [Required]
        public int TypeId { get; set; }

        public DateTime? FollowUpDate { get; set; }

        public int Status { get; set; }

        [MaxLength(4000)]
        public string CompletedNote { get; set; }

        public int AssigneeId { get; set; }

        public int LinkedChecklistItem {  get; set; }

        public bool IsDeleted { get; set; }

        public bool IsPinned { get; set; }

        public virtual Resident Resident { get; set; }
    }
}
