﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("FacilityDocument")]
    public class FacilityDocument : AuditBaseOperation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [ForeignKey("Resident")]
        public int FacilityId { get; set; }

        [Display(Name = "Name")]
        [MaxLength(200)]
        public string Name { get; set; }

        [MaxLength(200)]
        public string Path { get; set; }

        public bool IsDeleted { get; set; }

        [NotMapped]
        public bool IsStateDocument { get; set; }
    }
}
