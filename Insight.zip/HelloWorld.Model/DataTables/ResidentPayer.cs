﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentPayer")]
    public class ResidentPayer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public int ResidentId { get; set; }

        [Required]
        public int PayerRank { get; set; }

        [Required]
        public string PayerName { get; set; }

        [Required]
        public string PayerCode { get; set; }
    }
}
