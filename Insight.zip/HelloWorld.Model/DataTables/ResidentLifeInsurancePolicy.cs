﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentLifeInsurancePolicy")]
    public class ResidentLifeInsurancePolicy : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }
        public int ResidentId { get; set; }
        public decimal FaceValue { get; set; }
        public decimal CashValue { get; set; }
        
        [MaxLength(100)]
        public string CompanyName { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsSpousePolicy { get; set; }
    }
}
