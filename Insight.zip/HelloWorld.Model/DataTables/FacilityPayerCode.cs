﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("FacilityPayerCode")]
    public class FacilityPayerCode : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }
        public int FacilityId { get; set; }
        public string Code { get; set; }
        public int PayerTypeId { get; set; }
    }
}
