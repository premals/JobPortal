﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace HelloWorld.Model.DataTables
{
    [Table("Region")]
    public class Region : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [Required]
        public int TenantId { get; set; }

        [Required]
        [Display(Name = "Region Name")]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Active?")]
        public bool IsActive { get; set; }

        public virtual List<Facility> Facilities { get; set; }
    }
}
