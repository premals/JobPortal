﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentCompletedChecklistItem")]
    public class ResidentCompletedChecklistItem
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }
        public int ResidentId { get; set; }
        public int ChecklistItemId { get; set; }
    }
}
