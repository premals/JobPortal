﻿using System;
using System.Collections.Generic;
using HelloWorld.Common.Enumerations;
using HelloWorld.Common.Helpers;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("Employee")]
    public class Employee : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [ForeignKey("Facility")]
        public int? DefaultFacilityId { get; set; }

        [Required(ErrorMessage = "First Name is required")]
        [Display(Name = "First Name")]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        [Display(Name = "Last Name")]
        [MaxLength(50)]
        public string LastName { get; set; }

        [NotMapped]
        public string FullName
        {
            get
            {
                return $"{FirstName} {LastName}";
            }
        }

        [Required(ErrorMessage = "Email is required")]
        [Display(Name = "Email")]
        [EmailAddress]
        [MaxLength(50)]
        public string Email { get; set; }

        [Display(Name = "Opt into email notifications")]
        public bool OptIntoEmail { get; set; }

        public int RoleId { get; set; }

        [NotMapped]
        [Display(Name = "Role")]
        public string RoleName
        {
            get
            {
                if (RoleId == 0)
                {
                    return string.Empty;
                }

                return EnumHelper.GetDescription(EnumHelper.ToEnum<Roles>(RoleId));
            }
        }

        //do we want some of the below fields in a separate table?
        [Required]
        [Display(Name = "Username")]
        [MaxLength(25)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password Question is required")]
        [Display(Name = "Password Question")]
        [MaxLength(100)]
        public string PasswordQuestion { get; set; }

        [Required(ErrorMessage = "Pasaword Answer is required")]
        [Display(Name = "Password Answer")]
        [MaxLength(100)]
        public string PasswordAnswer { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; }

        [Display(Name = "Password Permanent?")]
        public bool IsPasswordPermanent { get; set; }

        [Display(Name = "Is Account Locked?")]
        public bool IsAccountLocked { get; set; }

        [Display(Name = "Changed Password On Next Login?")]
        public bool IsChangePasswordOnNextLogin { get; set; }

        [Display(Name = "Is Report Admin?")]
        public bool IsReportAdmin { get; set; }

        [Display(Name = "Can Complete Case Note?")]
        public bool CanApproveCaseNoteComplete { get; set; }

        [Display(Name = "Receive Case Note Completed Requests")]
        public bool IsSubscribedForCaseNoteEmail { get; set; }

        [Display(Name = "Last Login Date")]
        public DateTime? LastLoginDateTime { get; set; }

        [Display(Name = "Password Last Changed")]
        public DateTime? PasswordLastChanged { get; set; }

        [Display(Name = "Unsuccessful Login Attempts")]
        public int UnsuccessfulLoginAttempts { get; set; }
        
        public virtual Facility Facility { get; set; }     
        
        public virtual List<EmployeeAccessLevel> EmployeeAccessLevel { get; set; }
    }
}
