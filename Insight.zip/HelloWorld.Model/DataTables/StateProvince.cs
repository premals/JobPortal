﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("StateProvince")]
    public class StateProvince
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [Required]
        public string StateCode { get; set; }

        [Required]
        public int FIPSCode { get; set; }
        
        [Required]
        public string StateName { get; set; }
    }
}
