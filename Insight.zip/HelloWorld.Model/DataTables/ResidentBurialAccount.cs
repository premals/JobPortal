﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("ResidentBurialAccount")]
    public class ResidentBurialAccount : AuditBaseOperation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public int ResidentId { get; set; }

        [Required]
        public int AccountType { get; set; }

        [Required]
        public decimal Amount { get; set; }

        public bool IsSpouseAccount { get; set; }
    }
}
