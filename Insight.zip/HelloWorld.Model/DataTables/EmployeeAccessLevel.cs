﻿using System;
using HelloWorld.Common.Enumerations;
using HelloWorld.Common.Helpers;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelloWorld.Model.DataTables
{
    [Table("EmployeeAccessLevel")]
    public class EmployeeAccessLevel : AuditBaseOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        public int Id { get; set; }

        [ForeignKey("Employee")]
        [Required]
        public int EmployeeId { get; set; }

        [Required]
        public int LevelTypeId { get; set; }

        [Required]
        public int EntityId { get; set; }

        [NotMapped]
        public bool DeleteEmployeeAccess { get; set; }
    }
}
