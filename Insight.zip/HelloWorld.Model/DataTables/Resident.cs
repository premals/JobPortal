﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using HelloWorld.Common.Helpers;
using HelloWorld.Common.Enumerations;
using HelloWorld.Common.DataAnnotations;
using System.Linq;

namespace HelloWorld.Model.DataTables
{
    [Table("Resident")]
    public class Resident : AuditBaseOperation
    {
        public Resident()
        {
            ResidentDocuments = new List<ResidentDocument>();
            ResidentIncomes = new List<ResidentIncome>();
            ResidentPayers = new List<ResidentPayer>();
        }

        public bool IsEqualTo(Resident other)
        {
            foreach (var prop in typeof(Resident).GetProperties())
            {
                if (prop.PropertyType == typeof(Facility))
                {
                    continue;
                }

                if (prop.PropertyType == typeof(List<ResidentDocument>))
                {
                    continue;
                }

                if (prop.PropertyType == typeof(List<CaseNote>))
                {
                    continue;
                }

                if (prop.PropertyType == typeof(List<ResidentIncome>))
                {
                    continue;
                }

                if (prop.PropertyType == typeof(List<ResidentAssetAccount>))
                {
                    continue;
                }
                if (prop.PropertyType == typeof(List<ResidentBurialAccount>))
                {
                    continue;
                }
                if (prop.PropertyType == typeof(List<ResidentExpense>))
                {
                    continue;
                }

                if (prop.PropertyType == typeof(List<ResidentCompletedChecklistItem>))
                {
                    var items1 = (List<ResidentCompletedChecklistItem>)prop.GetValue(this);
                    var items2 = (List<ResidentCompletedChecklistItem>)prop.GetValue(other);

                    if (items1.Count != items2.Count)
                    {
                        return false;
                    }

                    items1 = items1.OrderBy(x => x.ChecklistItemId).ToList();
                    items2 = items2.OrderBy(x => x.ChecklistItemId).ToList() ;

                    for (int i = 0; i < items1.Count; i++)
                    {
                        if (items1[i].ChecklistItemId != items2[i].ChecklistItemId)
                        {
                            return false;
                        }
                    }

                    continue;
                }

                var value1 = prop.GetValue(this);
                var value2 = prop.GetValue(other);
                if (value1 is null)
                {
                    if (value2 is not null)
                    {
                        return false;
                    }
                }
                else
                {
                    if (!value1.Equals(value2))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Display(Name = "Resident Number")]
        [MaxLength(25)]
        public string ResidentNumber { get; set; }

        [Required(ErrorMessage ="First Name is required")]
        [Display(Name = "First Name")]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [Display(Name = "Initial")]
        [MaxLength(1)]
        public string MiddleInitial { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        [Display(Name = "Last Name")]
        [MaxLength(50)]
        public string LastName { get; set; }

        [Display(Name = "Date of Birth")]
        [DateGreaterThanMinDate("Please enter a valid Date of Birth")]
        public DateTime? DateOfBirth { get; set; }

        [Display(Name = "SSN")]
        public string SocialSecurityNumber { get; set; }

        [Required]
        [Range(0.0, 3.0, ErrorMessage = "Please select a gender")]
        public int GenderId { get; set; }

        public string GenderDescription { get; set; }

        [Required]
        [Range(0.0, 5.0, ErrorMessage = "Please enter a valid marital status")]
        public int MaritalStatusId { get; set; }
        public string MaritalStatusDescription { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [Display(Name = "Address Line 1")]
        [MaxLength(50)]
        public string AddressLine1 { get; set; }

        [Display(Name = "Address Line 2")]
        [MaxLength(50)]
        public string AddressLine2 { get; set; }

        [Required(ErrorMessage = "City is required")]
        [Display(Name = "City")]
        [MaxLength(50)]
        public string City { get; set; }

        [Required]
        [MaxLength(2)]
        public string StateCode { get; set; }

        [Required(ErrorMessage = "Zip is required")]
        [Display(Name = "Zip")]
        [MaxLength(5)]
        [RegularExpression(@"^\d{5}(-\d{4})?$", ErrorMessage = "Invalid Zipcode")]
        public string Zip { get; set; }

        [Display(Name = "Phone Number")]
        public string Phone { get; set; }

        [Display(Name = "Phone Ext")]
        [MaxLength(25)]
        public string PhoneExt { get; set; }

        private string _email;
        [Display(Name = "Email")]
        [RegularExpression("^[A-Za-z0-9_\\+-]+(\\.[A-Za-z0-9_\\+-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*\\.([A-Za-z]{2,4})$", ErrorMessage = "Invalid email address")]
        [MaxLength(50)]
        public string Email 
        {
            get
            {
                return _email;
            }
            set
            {
                _email = string.IsNullOrWhiteSpace(value) ? null : value;
            }
        }

        [Display(Name = "Resident Status")]
        public int ResidentStatusId { get; set; }

        public int FacilityId { get; set; }

        [Display(Name = "Admission Date")]
        public DateTime? AdmissionDate { get; set; }

        [Display(Name = "Primary Language")]
        public int? PrimaryLanguageId { get; set; }

        public string LanguageDescription { get; set; }

        [Display(Name = "Name")]
        [MaxLength(50)]
        public string ContactName { get; set; }

        [Display(Name = "Phone #")]
        [RegularExpression(@"^\(?(20[0-9]|2[1-9][0-9]|[3-9][0-9]{2})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Invalid phone number")]
        public string ContactPhone { get; set; }

        [Display(Name = "Relationship")]
        [MaxLength(50)]
        public string ContactRelationship { get; set; }

        [Display(Name = "Address same as resident?")]
        public bool IsContactAddressSameAsResident { get; set; }

        [Display(Name = "Address Line 1")]
        [MaxLength(50)]
        public string ContactAddressLine1 { get; set; }

        [Display(Name = "Address Line 2")]
        [MaxLength(50)]
        public string ContactAddressLine2 { get; set; }

        [Display(Name = "City")]
        [MaxLength(50)]
        public string ContactCity { get; set; }

        [MaxLength(2)]
        public string ContactStateCode { get; set; }

        private string _contactEmail;
        [Display(Name = "Email")]
        [RegularExpression("^[A-Za-z0-9_\\+-]+(\\.[A-Za-z0-9_\\+-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*\\.([A-Za-z]{2,4})$", ErrorMessage = "Invalid email address")]
        [MaxLength(50)]
        public string ContactEmail
        {
            get
            {
                return _contactEmail;
            }
            set
            {
                _contactEmail = string.IsNullOrWhiteSpace(value) ? null : value;
            }
        }

        [Display(Name = "Zip")]
        [MaxLength(5)]
        [RegularExpression(@"^\d{5}(-\d{4})?$", ErrorMessage = "Invalid Zipcode")]
        public string ContactZip { get; set; }

        [Display(Name = "Discharge Date")]
        public DateTime? DischargeDate { get; set; }

        [Display(Name = "Discharge Location")]
        [MaxLength(50)]
        public string DischargeLocation { get; set; }

        [Display(Name = "Medicaid Application Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0: yyyy-MM-dd}")]
        public DateTime? MedicaidApplicationDate { get; set; }

        [Display(Name = "Medicaid Number")]
        public string MedicaidNumber { get; set; }

        [Display(Name = "Medicaid Case Number")]
        public string MedicaidCaseNumber { get; set; }
        /// <summary>
        /// What month they actually start to get coverage for
        /// </summary>
        [Display(Name = "Medicaid Effective Date")]
        public DateTime? MedicaidEffectiveDate { get; set; }

        public DateTime? MedicaidApprovedDate { get; set; }

        public decimal? MedicaidApprovedAmount { get; set; }

        public DateTime? MedicaidDeniedDate { get; set; }

        public DateTime? MedicaidRequestedEffectiveDate { get; set; }

        public bool? IsAppealNeeded { get; set; }
        
        public DateTime? RequestedAppealDate { get; set; }

        public bool? IsAppealApproved { get; set; }

        public bool? IsHearingNeeded { get; set; }

        public DateTime? HearingDate { get; set; }

        public bool? IsHearingApproved { get; set; }

        [Display(Name = "Medicaid Application Login ID")]
        public string MedicaidApplicationLoginId { get; set; }

        [Display(Name = "Medicaid Application Login Password")]
        public string MedicaidApplicationLoginPassword { get; set; }

        public int PlanType { get; set; }

        [Display(Name = "MMA Effective Date")]
        public DateTime? MMAEffectiveDate { get; set; }

        [Display(Name = "MMA Plan Name")]
        public string MMAPlanName { get; set; }

        [Display(Name = "MMA PolicyId")]
        public string MMAPolicyId { get; set; }

        [Display(Name = "MMA Authorization Request Date")]
        public DateTime? MMAAuthorizationRequestDate { get; set; }

        [Display(Name = "MMA Authorization Start Date")]
        public DateTime? MMAAuthorizationStartDate { get; set; }

        [Display(Name = "MMA Authorization End Date")]
        public DateTime? MMAAuthorizationEndDate { get; set; }

        [Display(Name = "MMA Authorization Number")]
        public string MMAAuthorizationNumber { get; set; }

        [Display(Name = "LTC Effective Date")]
        public DateTime? LTCEffectiveDate { get; set; }

        [Display(Name = "LTC Plan Name")]
        public string LTCPlanName { get; set; }

        [Display(Name = "LTC Policy Id")]
        public string LTCPolicyId { get; set; }

        [Display(Name = "LTC Authorization Request Date")]
        public DateTime? LTCAuthorizationRequestDate { get; set; }

        [Display(Name = "LTC Authorization Start Date")]
        public DateTime? LTCAuthorizationStartDate { get; set; }

        [Display(Name = "LTC Authorization End Date")]
        public DateTime? LTCAuthorizationEndDate { get; set; }

        [Display(Name = "LTC Authorization Number")]
        public string LTCAuthorizationNumber { get; set; }


        [Display(Name = "Is Level Of Care Temporary?")]
        public bool? IsLevelOfCareTemporary { get; set; }

        [Display(Name = "Level Of Care Date")]
        public DateTime? LevelOfCareDate { get; set; }

        [Display(Name = "Is Umed Needed?")]
        public bool? IsUmedNeeded { get; set; }

        [Display(Name = "Umed Application Date")]
        public DateTime? UmedApplicationDate { get; set; }

        public bool? IsUmedApproved { get; set; }

        [Display(Name = "Umed Approved Date")]
        public DateTime? UmedDecisionDate { get; set; }

        [Display(Name = "Umed Requested Amount")]
        public decimal? UmedRequestedAmount { get; set; }

        [Display(Name = "Recertification Date")]
        public DateTime? RecertificationDate { get; set; }

        public bool HasCommunitySpouse { get; set; }

        [Display(Name = "Qualified Income Trust Fund Date")]
        public DateTime? QITFundingDate { get; set; }

        public bool IsMedicarePartBApplied { get; set; }

        public bool IsDeleted { get; set; }

        public bool IsHotCase {  get; set; }

        public int? PccId { get; set; }
      
        public string MatrixId { get; set; }

        public string PrimaryPayerTypeCode { get; set; }
       
        public DateTime? PrimaryPayerTypeEndDate { get; set; }

        public bool ShowAsMedicaidPending { get; set; }
        public bool IsGuardianshipNeeded { get; set; }
        public DateTime? CourtDate { get; set; }
        public DateTime? GuardianAssignedDate { get; set; }

        public virtual Facility Facility { get; set; }

        public virtual List<ResidentDocument> ResidentDocuments { get; set; }

        public virtual List<CaseNote> ResidentNotes { get; set; }

        public virtual List<ResidentIncome> ResidentIncomes { get; set; }

        public virtual List<ResidentAssetAccount> ResidentAssetAccounts { get; set; }

        public virtual List<ResidentBurialAccount> ResidentBurialAccounts { get; set; }

        public virtual List<ResidentExpense> ResidentExpenses { get; set; }

        public virtual List<ResidentCompletedChecklistItem> CompletedChecklistItems { get; set; }

        public virtual List<ResidentPayer> ResidentPayers { get; set; }

        public virtual MedicaidEligibilityResult MedicaidEligibilityResult { get; set; }

        [NotMapped]
        public bool IsPccPatient { 
            get
                {
                    return PccId != null;
                } 
        }

        [NotMapped]
        public bool IsMatrixPatient
        {
            get
            {
                return !String.IsNullOrEmpty(MatrixId);
            }
        }

        public string GetFormattedName()
        {
            return string.IsNullOrWhiteSpace(ResidentNumber)
                    ? $"{LastName}, {FirstName}"
                    : $"{LastName}, {FirstName} - {ResidentNumber}";
        }
    }
}
