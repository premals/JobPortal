using System;
using System.Linq;
using System.Net.Mail;
using EmailNotificationService.FunctionApp.Helper;
using EmailNotificationService.FunctionApp.Repository;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Extensions;
using System.IO;
using System.Reflection;

namespace EmailNotificationService.FunctionApp
{
    public static class EmailNotificationService
    {
        [Function("EmailNotificationService")]
        public static void Run([TimerTrigger("*/60 * * * * *")]TimerInfo myTimer, ExecutionContext context, ILogger log)
        {
            log.LogInformation($"Starting EmailNotificationService Function app");

            try
            {
                var config = new ConfigurationBuilder()
                    .SetBasePath(Path.GetFullPath(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)))
                    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables()
                    .Build();

                var emailNotificationHelper = new EmailNotificationHelper(config, log);
                emailNotificationHelper.Run();

            }
            catch (Exception ex)
            {
                log.LogError($"Error: {ex.InnerException?.Message ?? ex.Message}");
                return;
            }

            log.LogInformation($"Completed EmailNotificationService Function app");

            return;
        }
    }
}
