﻿using System.Collections.Generic;
using System.Linq;
using HelloWorld.Common.Enumerations;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.EntityFrameworkCore;

namespace EmailNotificationService.FunctionApp.Repository
{
    public class ConfigRepository
    {
        private readonly DbContextOptionsBuilder<HelloWorldConfigContext> _optionsBuilder;

        public ConfigRepository(string connectionString)
        {
            _optionsBuilder = new DbContextOptionsBuilder<HelloWorldConfigContext>();
            _optionsBuilder.UseSqlServer(connectionString);
        }

        public List<Tenant> GetAllTenants()
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                return context.Tenant.ToList();
            }
        }

        public List<EmailNotification> GetEmailNotifications()
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                var emailNotifications = context.EmailNotification.Include(x=>x.Tenant).ToList();

                return emailNotifications;
            }
        }

        public void SaveEmailNotification(EmailNotification emailNotification)
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                context.Entry(emailNotification).State = EntityState.Modified;
                context.SaveChanges();
            }
        }

        public Tenant GetTenant(int tenantId)
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                var tenant = context.Tenant.FirstOrDefault(x => x.Id == tenantId);

                return tenant;
            }
        }
     
        public List<EmailNotificationType> GetEmailNotificationTypes()
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                return context.EmailNotificationType.ToList();
            }
        }
    }
}
