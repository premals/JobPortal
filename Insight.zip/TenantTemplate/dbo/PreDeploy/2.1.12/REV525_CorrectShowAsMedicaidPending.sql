﻿UPDATE r
SET showasmedicaidpending = 0
FROM resident r
JOIN [dbo].[FacilityPayerCode] f on f.code = r.primarypayertypecode
WHERE f.payertypeid = 1 and r.showasmedicaidpending = 1