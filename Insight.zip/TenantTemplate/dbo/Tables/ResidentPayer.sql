﻿CREATE TABLE [dbo].[ResidentPayer] (
    [Id]         INT          IDENTITY (1, 1) NOT NULL,
    [ResidentId] INT          NOT NULL,
    [PayerRank]  INT          NOT NULL,
    [PayerName]  VARCHAR (50) NOT NULL,
    [PayerCode]  VARCHAR (30) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO