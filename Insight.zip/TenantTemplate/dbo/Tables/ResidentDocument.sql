﻿CREATE TABLE [dbo].[ResidentDocument]
(
	[Id] INT IDENTITY(1,1) NOT NULL, 
    [ResidentId] INT NOT NULL,
	[Name] VARCHAR(200) NOT NULL, 
    [Path] VARCHAR(200) NULL, 
    [IsDeleted] BIT NULL DEFAULT 0, 
    [CreatedBy] INT NULL DEFAULT 1, 
    [CreatedDate] DATETIMEOFFSET NULL,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	[UpdatedBy] INT NULL,
	CONSTRAINT [PK_ResidentDocument] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_ResidentDocument_Resident] FOREIGN KEY ([ResidentId]) REFERENCES [dbo].[Resident] ([Id]),
)
