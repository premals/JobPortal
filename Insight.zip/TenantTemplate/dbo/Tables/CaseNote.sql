﻿CREATE TABLE [dbo].[CaseNote]
(
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ResidentId] [int] NOT NULL,
	[Note] [varchar](4000) NOT NULL,
	[TypeId] [int] NOT NULL,
	[FollowUpDate] [datetime] NULL,
	[Status] INT NOT NULL DEFAULT 0,
	[CompletedNote] [varchar](4000) NULL,
	[AssigneeId] INT NOT NULL DEFAULT 0,
	[LinkedChecklistItem] INT NOT NULL DEFAULT 0,
	[IsDeleted] [bit] NOT NULL,
	[IsPinned] [bit] NOT NULL DEFAULT 0,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetimeoffset](7) NOT NULL,
	[UpdatedBy] [int] NULL,
	[UpdatedDate] [datetimeoffset](7) NULL
    CONSTRAINT [PK_CaseNote] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_CaseNote_Resident] FOREIGN KEY ([ResidentId]) REFERENCES [dbo].[Resident] ([Id]),

)
