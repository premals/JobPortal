﻿CREATE TABLE [dbo].[PayerRank] (
    [Id]          INT          IDENTITY (1, 1) NOT NULL,
    [Description] VARCHAR (25) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO
