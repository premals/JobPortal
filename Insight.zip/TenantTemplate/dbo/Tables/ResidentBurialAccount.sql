﻿CREATE TABLE [dbo].[ResidentBurialAccount]
(
	[Id] INT IDENTITY(1,1) NOT NULL,
	[ResidentId] INT NULL,
	[AccountType] INT NULL,
	[Amount] DECIMAL(8, 2) NULL DEFAULT 0.00,
	[IsSpouseAccount] BIT NOT NULL DEFAULT 0,
	[IsDeleted] BIT NOT NULL DEFAULT 0,
	[CreatedBy] INT NOT NULL,
	[CreatedDate] DATETIMEOFFSET(7) NOT NULL,
	[UpdatedBy] INT NULL,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	CONSTRAINT [PK_ResidentBurialAccount] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_ResidentBurialAccount_Resident] FOREIGN KEY ([ResidentId]) REFERENCES [dbo].[Resident] ([Id]),
)
