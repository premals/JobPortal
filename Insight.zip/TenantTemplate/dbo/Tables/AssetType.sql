﻿CREATE TABLE [dbo].[AssetType]
(
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](100) NULL, 
    CONSTRAINT [PK_AssetType] PRIMARY KEY ([Id]),
)
