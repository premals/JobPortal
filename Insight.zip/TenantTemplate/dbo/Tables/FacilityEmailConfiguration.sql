﻿CREATE TABLE [dbo].FacilityEmailConfiguration(
	[Id] int IDENTITY(1,1) NOT NULL,
	[FacilityId] int NOT NULL,
	[Day] int NOT NULL,
	[Time] DATETIME NOT NULL,
	[EmailNotificationTypeId] int NOT NULL,
	[TimeToExecute] DATETIMEOFFSET NULL,
	[CreatedBy] int NOT NULL,
	[CreatedDate] datetimeoffset(7) NOT NULL,
	[UpdatedBy] int NULL,
	[UpdatedDate] datetimeoffset(7) NULL
	CONSTRAINT [PK_FacilityEmailConfiguration] PRIMARY KEY CLUSTERED ([Id] ASC),  
	CONSTRAINT [FK_FacilityEmailConfiguration_EmailNotificationType] FOREIGN KEY ([EmailNotificationTypeId]) REFERENCES [dbo].[EmailNotificationType] ([Id]),
    CONSTRAINT [FK_FacilityEmailConfiguration_Facility] FOREIGN KEY ([FacilityId]) REFERENCES [dbo].[Facility] ([Id])
	)