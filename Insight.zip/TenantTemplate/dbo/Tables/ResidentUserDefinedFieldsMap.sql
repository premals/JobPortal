﻿CREATE TABLE [dbo].[ResidentUserDefinedFieldsMap]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, 
    [FacilityId] INT NOT NULL, 
    [RecertificationDate] VARCHAR(255) NULL, 
    [MedicaidApprovedDate] VARCHAR(255) NULL,
    CONSTRAINT AK_FacilityId UNIQUE(FacilityId)
)
