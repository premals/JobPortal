﻿CREATE TABLE [dbo].[ResidentExpense]
(
	[Id] INT IDENTITY(1,1) NOT NULL, 
    [ResidentId] INT NOT NULL, 
    [ExpenseType] INT NOT NULL, 
    [Amount] DECIMAL(18, 2) NOT NULL, 
    [IsSpouseExpense] BIT NOT NULL DEFAULT 0, 
    [IsDeleted] BIT NOT NULL DEFAULT 0,
	[CreatedDate] DATETIMEOFFSET(7) NOT NULL DEFAULT GETUTCDATE(),
	[CreatedBy] INT NOT NULL DEFAULT 1,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	[UpdatedBy] INT NULL,
	[Description] VARCHAR(100) NULL, 
    CONSTRAINT [PK_ResidentExpense] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_ResidentExpense_Resident] FOREIGN KEY ([ResidentId]) REFERENCES [dbo].[Resident] ([Id]),
)
