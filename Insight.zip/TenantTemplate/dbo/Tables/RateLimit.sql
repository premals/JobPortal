﻿CREATE TABLE [dbo].[RateLimit]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Entity] INT NOT NULL, 
    [TimeToReset] DATETIME NULL
)
