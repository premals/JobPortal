﻿CREATE TABLE [dbo].[ResidentCompletedChecklistitem]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [ResidentId] INT NOT NULL, 
    [ChecklistItemId] INT NOT NULL
)
