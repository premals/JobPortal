﻿
CREATE TABLE [dbo].[FacilityPayerCode](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FacilityId] [int] NOT NULL,
	[Code] [varchar](30) NOT NULL,
	[PayerTypeId] [int] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetimeoffset](7) NOT NULL,
	[UpdatedBy] [int] NULL,
	[UpdatedDate] [datetimeoffset](7) NULL,
	CONSTRAINT [PK_FacilityPayerCode] PRIMARY KEY ([Id])
)
GO