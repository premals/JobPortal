﻿CREATE TABLE [dbo].[ResidentIncome]
(
	[Id] INT IDENTITY(1,1) NOT NULL, 
    [ResidentId] INT NOT NULL, 
    [IncomeType] INT NOT NULL, 
    [Amount] DECIMAL(18, 2) NOT NULL,
	[Description] VARCHAR(25) NULL,
    [IsSpouseIncome] BIT NOT NULL DEFAULT 0, 
    [IsDeleted] BIT NOT NULL DEFAULT 0,
	[CreatedDate] DATETIMEOFFSET(7) NOT NULL DEFAULT GETUTCDATE(),
	[CreatedBy] INT NOT NULL DEFAULT 1,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	[UpdatedBy] INT NULL,
	CONSTRAINT [PK_ResidentIncome] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_ResidentIncome_Resident] FOREIGN KEY ([ResidentId]) REFERENCES [dbo].[Resident] ([Id]),
)
