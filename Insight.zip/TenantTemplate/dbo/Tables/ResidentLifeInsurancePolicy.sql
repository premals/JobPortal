﻿CREATE TABLE [dbo].[ResidentLifeInsurancePolicy]
(
	[Id] INT IDENTITY(1,1) NOT NULL, 
    [ResidentId] INT NOT NULL, 
    [FaceValue] DECIMAL(12, 2) NOT NULL DEFAULT 0.00, 
    [CashValue] DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    [CompanyName] varchar(100) NOT NULL,
    [IsDeleted] BIT NOT NULL DEFAULT 0,
	[IsSpousePolicy] BIT NOT NULL DEFAULT 0,
	[CreatedBy] INT NOT NULL DEFAULT 1,
	[CreatedDate] DATETIMEOFFSET(7) NOT NULL DEFAULT GETUTCDATE(),
	[UpdatedBy] INT NULL,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	CONSTRAINT [PK_ResidentLifeInsurancePolicy] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_ResidentLifeInsurancePolicy_Resident] FOREIGN KEY ([ResidentId]) REFERENCES [dbo].[Resident] ([Id]),
)
