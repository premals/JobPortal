﻿CREATE TABLE [dbo].[EmailNotificationType]
(
	[Id] INT NOT NULL  IDENTITY, 
    [Name] VARCHAR(50) NULL, 
    CONSTRAINT [PK_EmailNotificationType] PRIMARY KEY ([Id])
)
