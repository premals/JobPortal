﻿CREATE TABLE [dbo].[ResidentAssetAccount]
(
	[Id] INT IDENTITY(1,1) NOT NULL,
	[ResidentId] INT NULL,
	[AssetTypeId] INT NULL,
	[Amount] DECIMAL(12, 2) NULL,
	[Name] VARCHAR(100) NULL,
	[IsSpouseAccount] BIT NOT NULL,
	[IsDeleted] BIT NOT NULL,
	[CreatedBy] INT NOT NULL,
	[CreatedDate] DATETIMEOFFSET(7) NOT NULL,
	[UpdatedBy] INT NULL,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	CONSTRAINT [PK_ResidentAssetAccount] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_ResidentAssetAccount_Resident] FOREIGN KEY ([ResidentId]) REFERENCES [dbo].[Resident] ([Id]),
	CONSTRAINT [FK_AssetType_TypeID] FOREIGN KEY ([AssetTypeId]) REFERENCES [dbo].[AssetType] ([Id]),
)
