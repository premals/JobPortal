﻿CREATE TABLE [dbo].[FacilityDocument]
(
	[Id] INT IDENTITY(1,1) NOT NULL, 
    [FacilityId] INT NOT NULL, 
    [Name] VARCHAR(200) NOT NULL, 
    [Path] VARCHAR(200) NULL, 
    [IsDeleted] BIT NOT NULL DEFAULT 0, 
    [CreatedBy] INT NOT NULL DEFAULT 1, 
    [CreatedDate] DATETIMEOFFSET NOT NULL,
	[UpdatedBy] INT NULL,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	CONSTRAINT [PK_FacilityDocument] PRIMARY KEY CLUSTERED ([Id] ASC)  
)
