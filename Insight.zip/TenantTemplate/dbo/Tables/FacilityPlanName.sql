﻿CREATE TABLE [dbo].[FacilityPlanName]
(
	[Id] INT NOT NULL IDENTITY , 
    [FacilityId] INT NOT NULL, 
    [Name] VARCHAR(50) NOT NULL, 
    [IsActive] BIT NOT NULL DEFAULT 1, 
    [CreatedBy] INT NOT NULL, 
    [CreatedDate] DATETIMEOFFSET NOT NULL, 
    [UpdatedBy] INT NULL, 
    [UpdatedDate] DATETIMEOFFSET NULL, 
    CONSTRAINT [PK_FacilityPlanName] PRIMARY KEY ([Id])
)
