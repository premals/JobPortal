﻿CREATE TABLE [dbo].[EmployeeAccessLevel]
(
	[Id] INT IDENTITY(1,1) NOT NULL,
	[EmployeeId] INT NOT NULL,
	[LevelTypeId] INT NOT NULL,
	[EntityId] INT NOT NULL,
	[CreatedDate] DATETIMEOFFSET(7) NOT NULL DEFAULT GETUTCDATE(),
	[CreatedBy] INT NOT NULL DEFAULT 1,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	[UpdatedBy] INT NULL,
	CONSTRAINT [PK_EmployeeAccessLevel] PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_EmployeeAccessLevel_Employee] FOREIGN KEY ([EmployeeId]) REFERENCES [dbo].[Employee] ([Id]),
)
