﻿CREATE TABLE [dbo].[MedicaidEligibilityResult] (
    [Id]                  INT            IDENTITY (1, 1) NOT NULL,
    [ResidentId]          INT            NOT NULL,
    [IsMedicaidEligible] BIT            NOT NULL,
    [IsPendingRecheck]    BIT            NOT NULL,
    [IsMissingInfo]       BIT            NOT NULL,
    [ErrorDescription]    NVARCHAR (MAX) NULL,
    [CheckDate]           DATETIME2 (7)  NOT NULL,
    [CreatedDate]         DATETIME2 (7)  NOT NULL,
    [IsCleared] BIT NOT NULL DEFAULT 0, 
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO

