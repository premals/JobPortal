﻿CREATE TABLE [dbo].[Workstation]
(
	[Id] INT IDENTITY(1,1) NOT NULL, 
    [Name] VARCHAR(25) NULL, 
    [Description] VARCHAR(50) NULL, 
    [FacilityId] INT NOT NULL, 
    [TypeId] INT NOT NULL, 
    [IsActive] BIT NOT NULL DEFAULT 1, 
    [IdleUrl] VARCHAR(50) NULL,
    [ParentWorkstationId] INT NULL,
	[CreatedBy] INT NOT NULL DEFAULT 1,
    [CreatedDate] DATETIMEOFFSET(7) NOT NULL DEFAULT GETUTCDATE(),
	[UpdatedBy] INT NULL,
	[UpdatedDate] DATETIMEOFFSET(7) NULL,
	CONSTRAINT [PK_Workstation] PRIMARY KEY CLUSTERED ([Id] ASC),
)
