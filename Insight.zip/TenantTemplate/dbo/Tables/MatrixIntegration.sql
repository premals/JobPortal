﻿CREATE TABLE [dbo].[MatrixIntegration] (
    [Id]                 INT           IDENTITY (1, 1) NOT NULL,
    [MatrixFacilityCode] VARCHAR (50)  NOT NULL,
    [MatrixFacilityName] VARCHAR (100) NOT NULL,
    [TenantId]           INT           NOT NULL,
    [FacilityId]         INT           NOT NULL,
    [ShowMatrix]         BIT           DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_dbo.MatrixIntegration] PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO

CREATE NONCLUSTERED INDEX [IX_MatrixIntegration_MatrixFacilityCode]
    ON [dbo].[MatrixIntegration]([MatrixFacilityCode] ASC);
GO

