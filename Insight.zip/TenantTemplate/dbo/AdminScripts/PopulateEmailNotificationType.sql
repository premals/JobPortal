IF NOT EXISTS (SELECT * FROM EmailNotificationType WHERE NAME = 'MedicaidApplicationsNeeded')
BEGIN
INSERT INTO EmailNotificationType
VALUES ('MedicaidApplicationsNeeded')
END
IF NOT EXISTS (SELECT * FROM EmailNotificationType WHERE NAME = 'TemporaryLevelofCare')
BEGIN
INSERT INTO EmailNotificationType
VALUES ('TemporaryLevelofCare')
END
IF NOT EXISTS (SELECT * FROM EmailNotificationType WHERE NAME = 'LTCManagedCarePlansNeeded')
BEGIN
INSERT INTO EmailNotificationType
VALUES ('LTCManagedCarePlansNeeded')
END
IF NOT EXISTS (SELECT * FROM EmailNotificationType WHERE NAME = 'LTCAuthorizationNeeded')
BEGIN
INSERT INTO EmailNotificationType
VALUES ('LTCAuthorizationNeeded')
END
IF NOT EXISTS (SELECT * FROM EmailNotificationType WHERE NAME = 'MMAAuthorizationsNeeded')
BEGIN
INSERT INTO EmailNotificationType
VALUES ('MMAAuthorizationsNeeded')
END
IF NOT EXISTS (SELECT * FROM EmailNotificationType WHERE NAME = 'UmedApplicationsFollowUpsNeeded')
BEGIN
INSERT INTO EmailNotificationType
VALUES ('UmedApplicationsFollowUpsNeeded')
END
IF NOT EXISTS (SELECT * FROM EmailNotificationType WHERE NAME = 'CaseNotesFollowUpsNeeded')
BEGIN
INSERT INTO EmailNotificationType
VALUES ('CaseNotesFollowUpsNeeded')
END