﻿using System.Text.Json.Serialization;

namespace Integration.PCC.Response
{
    public class PatientLite
    {
        [JsonPropertyName("patientId")]
        public int PatientId { get; set; }

        [JsonPropertyName("patientExternalId")]
        public string PatientExternalId { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("birthDate")]
        public string BirthDate { get; set; }
    }
}
