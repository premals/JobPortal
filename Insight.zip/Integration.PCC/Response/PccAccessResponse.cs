﻿namespace Integration.PCC.Response
{
    public class PccAccessResponse
    {
        public string access_token { get; set; }
        public string expires_in { get; set; }
    }
}
