﻿namespace Integration.PCC.Response
{
    /// <summary>
    /// Used in GET Patient Endpoint
    /// </summary>
    public class PccPatientResponse
    {
        public PccPatientResponse()
        {
            legalMailingAddress = new LegalMailingAddress();
        }

        public int patientId { get; set; }
        public string patientExternalId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string middleName { get; set; }
        public string birthDate { get; set; }
        public string socialBeneficiaryIdentifier { get; set; }
        public string gender { get; set; }
        public string maritalStatus { get; set; }
        public string homePhone { get; set; }
        public string email { get; set; }
        public string patientStatus { get; set; }
        public int facId { get; set; }
        public string admissionDate { get; set; }
        public string languageCode { get; set; }
        public string languageDesc { get; set; }
        public string dischargeDate { get; set; }
        public string medicaidNumber { get; set; }
        public LegalMailingAddress legalMailingAddress { get; set; }
        public List<UserDefinedField> userDefinedFields { get; set; } = new List<UserDefinedField>();
    }

    public class LegalMailingAddress
    {
        public string addressLine1 { get; set; }
        public string addressLine2 { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string postalCode { get; set; }
        public string country { get; set; }
    }

    public class UserDefinedField
    {
        public string name { get; set; }
        public string description { get; set; }
    }
}
