﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Integration.PCC.Response
{
    public class PccCoveragesResponse
    {
        [JsonPropertyName("coverageId")]
        public int CoverageId { get; set; }

        [JsonPropertyName("effectiveFromDateTime")]
        public string EffectiveFromDateTime { get; set; }

        [JsonPropertyName("effectiveToDateTime")]
        public string EffectiveToDateTime { get; set; }

        [JsonPropertyName("patientId")]
        public int PatientId { get; set; }

        [JsonPropertyName("payers")]
        public List<PccPayer> Payers { get; set; }

        public PccCoveragesResponse() 
        {
            Payers = new List<PccPayer>();
        }
    }
}
