﻿using System.Text.Json.Serialization;

namespace Integration.PCC.Response
{
    public class PccAdtRecordsResponse
    {
        [JsonPropertyName("data")]
        public List<AdtRecords> Data { get; set; }
        
    }

    public class AdtRecords
    {
        [JsonPropertyName("patientId")]
        public int PatientId { get; set; }

        [JsonPropertyName("standardActionType")]
        public string StandardActionType { get; set; }

        [JsonPropertyName("admissionType")]
        public string AdmissionType { get; set; }

        [JsonPropertyName("dischargeStatusCode")]
        public string DischargeStatusCode { get; set; }

        [JsonPropertyName("enteredDate")]
        public string EnteredDate { get; set; }

        [JsonPropertyName("modifiedDateTime")]
        public string ModifiedDateTime { get; set; }

        [JsonPropertyName("effectiveDateTime")]
        public string EffectiveDateTime { get; set; }

        [JsonPropertyName("destinationType")]
        public string DestinationType { get; set; }

        [JsonPropertyName("payerName")]
        public string PayerName { get; set; }

        [JsonPropertyName("payerType")]
        public string PayerType { get; set; }

        [JsonPropertyName("payerCode")]
        public string PayerCode { get; set; }
    }

}
