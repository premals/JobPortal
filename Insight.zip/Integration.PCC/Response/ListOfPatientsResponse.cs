﻿using System.Text.Json.Serialization;

namespace Integration.PCC.Response
{
    public class Pagination
    {
        [JsonPropertyName("hasMore")]
        public bool? HasMore { get; set; }

        [JsonPropertyName("page")]
        public int Page { get; set; }

        [JsonPropertyName("pageSize")]
        public int PageSize { get; set; }
    }

    public class ListOfPatientsResponse
    {
        [JsonPropertyName("data")]
        public List<PatientLite> Data { get; set; }

        [JsonPropertyName("paging")]
        public Pagination Paging { get; set; }
    }
}
