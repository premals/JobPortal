﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Integration.PCC.Response
{
    public class PccPayer
    {
        [JsonPropertyName("accountDescription")]
        public string AccountDescription { get; set; }

        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonPropertyName("insuredParty")]
        public PccInsuredParty InsuredParty { get; set; }

        [JsonPropertyName("issuer")]
        public PccIssuer Issuer { get; set; }

        [JsonPropertyName("payPlanType")]
        public string PayPlanType { get; set; }

        [JsonPropertyName("payPlanTypeCode")]
        public string PayPlanTypeCode { get; set; }

        [JsonPropertyName("payerCode")]
        public string PayerCode { get; set; }

        [JsonPropertyName("payerCode2")]
        public string PayerCode2 { get; set; }

        [JsonPropertyName("payerId")]
        public int PayerId { get; set; }

        [JsonPropertyName("payerName")]
        public string PayerName { get; set; }

        [JsonPropertyName("payerRank")]
        public string PayerRank { get; set; }

        [JsonPropertyName("payerType")]
        public string PayerType { get; set; }

        [JsonPropertyName("payerTypeCode")]
        public string PayerTypeCode { get; set; }

        [JsonPropertyName("pps")]
        public bool Pps { get; set; }
    }

    public class PccInsuredParty
    {
        [JsonPropertyName("address")]
        public PccAddress Address { get; set; }

        [JsonPropertyName("birthDate")]
        public string BirthDate { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("gender")]
        public string Gender { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("middleName")]
        public string MiddleName { get; set; }

        [JsonPropertyName("relationship")]
        public string Relationship { get; set; }

        [JsonPropertyName("socialBeneficiaryIdentifier")]
        public string SocialBeneficiaryIdentifier { get; set; }
    }

    public class PccIssuer
    {
        [JsonPropertyName("contactName")]
        public string ContactName { get; set; }

        [JsonPropertyName("group")]
        public string Group { get; set; }

        [JsonPropertyName("groupName")]
        public string GroupName { get; set; }

        [JsonPropertyName("issuerAddress")]
        public PccAddress IssuerAddress { get; set; }

        [JsonPropertyName("issuerId")]
        public int IssuerId { get; set; }

        [JsonPropertyName("issuerName")]
        public string IssuerName { get; set; }

        [JsonPropertyName("phone")]
        public string Phone { get; set; }

        [JsonPropertyName("planEffectiveDate")]
        public string PlanEffectiveDate { get; set; }

        [JsonPropertyName("planNumber")]
        public string PlanNumber { get; set; }

        [JsonPropertyName("providerNumber")]
        public string ProviderNumber { get; set; }
    }

    public class PccAddress
    {
        [JsonPropertyName("addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonPropertyName("addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonPropertyName("addressLine3")]
        public string AddressLine3 { get; set; }

        [JsonPropertyName("city")]
        public string City { get; set; }

        [JsonPropertyName("country")]
        public string Country { get; set; }

        [JsonPropertyName("county")]
        public string County { get; set; }

        [JsonPropertyName("postalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("state")]
        public string State { get; set; }

    }
}
