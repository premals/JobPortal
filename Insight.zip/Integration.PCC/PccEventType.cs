﻿namespace Integration.PCC
{
    public class PccEventType
    {
        /// <summary>
        /// A new patient is admitted using Quick ADT or New Census Entry (patientStatus is Current). This does not get triggered if the patient Status is already 'NEW'.
        /// </summary>
        public const string AdmitPatient = "patient.admit";
        /// <summary>
        /// A patient who was previously discharged is now being readmitted using Quick ADT or New Census Entry. A new effective Date, Bed Location and other required Census fields are added.
        /// </summary>
        public const string ReadmitPatient = "patient.readmit";
        /// <summary>
        /// A patient's admission or readmission is deleted in PointClickCare by deleting the Census entry.
        /// </summary>
        public const string CancelAdmit = "patient.cancelAdmit";
        /// A patient's demographic info, prior address info, location/bed info, allergies or diagnoses are updated.
        /// </summary>
        public const string UpdateResidentInfo = "patient.updateResidentInfo";
        /// <summary>
        /// A patient's payer is updated or there is a change in the daily rate for the active payer.
        /// </summary>
        public const string UpdateAccount = "patient.updateAccount";
        /// <summary>
        /// A patient's payer is updated when they return from a Leave of Absence.
        /// </summary>
        public const string UpdateAccountOnReturnFromLeave = "patient.updateAccountOnReturnFromLeave";
        /// <summary>
        /// A patient is discharged using Quick ADT or New Census Entry (patientStatus is Discharged).
        /// </summary>
        public const string Discharge = "patient.discharge";
        /// <summary>
        /// A patient's discharge event is deleted in PointClickCare by deleting the Census entry.
        /// </summary>
        public const string cancelDischarge = "patient.cancelDischarge";
    }
}
