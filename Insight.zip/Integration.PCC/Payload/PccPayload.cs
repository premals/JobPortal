using System.Text.Json.Serialization;

namespace Integration.PCC.Payload
{
    public class PccPayload
    {
        [JsonPropertyName("messageId")]
        public string MessageId { get; set; }

        [JsonPropertyName("eventType")]
        public string EventType { get; set; }

        [JsonPropertyName("facId")]
        public int FacId { get; set; }

        [JsonPropertyName("orgId")]
        public int OrgId { get; set; }

        [JsonPropertyName("orgUuid")]
        public string OrgUuid { get; set; }

        [JsonPropertyName("patientId")]
        public int PatientId { get; set; }

        [JsonPropertyName("eventDate")]
        public string EventDate { get; set; }

        [JsonPropertyName("messageDate")]
        public string MessageDate { get; set; }
    }
}
