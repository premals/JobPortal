﻿using Integration.PCC.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using HelloWorld.EntityFramework.Interfaces;
using System.Web;

namespace Integration.PCC
{
    public class EndpointService
    {
        public readonly HttpClient _client;
        public string _accessToken;
        public string _orgUuid;
        public IConfigRepository _configRepository;

        public EndpointService(string orgUuid, string accessToken, HttpClient client, IConfigRepository configRepository) 
        {
            _client = client;
            _accessToken = accessToken;
            _orgUuid = orgUuid;
            _configRepository = configRepository;
        }

        private async Task<HttpResponseMessage> GetClientResponse(HttpRequestMessage request)
        {
            request.Headers.Add("Authorization", $"Bearer {_accessToken}");
            var response = await _client.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                return response;
            } 
            else
            {
                if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                {
                    var xQuotaTimeToReset = Convert.ToInt64(response.Headers.GetValues("X-Quota-Time-To-Reset").FirstOrDefault());
                    var dateTimeOffset = DateTimeOffset.FromUnixTimeMilliseconds(xQuotaTimeToReset);
                    var rateLimit = _configRepository.GetRateLimit(HelloWorld.Common.Enumerations.RateLimitEntity.PointClickCare);
                    rateLimit.TimeToReset = dateTimeOffset.DateTime;
                    _configRepository.UpdateRateLimit(rateLimit);
                    throw new Exception($"Too many requests. Reset Time is: {dateTimeOffset.DateTime}");
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    throw new Exception($"Resource not found.");
                }
                else
                {
                    throw new Exception($"Error trying endpoint {request.RequestUri}. Status Code: {response.StatusCode}");
                }
            }
        }

        public async Task<ListOfPatientsResponse> GetPatientsList(int? facilityId, string url, int page, bool getCurrent = false)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"{url}/orgs/{_orgUuid}/patients?facId={facilityId}&page={page}&pageSize=200&fields=firstName,lastName,patientExternalId,patientId,birthDate" + (getCurrent ? "&patientStatus=Current" : ""));
            var response = await GetClientResponse(request);
            using var responseStream = await response.Content.ReadAsStreamAsync();
            var patients = await JsonSerializer.DeserializeAsync<ListOfPatientsResponse>(responseStream);
            return patients ?? new ListOfPatientsResponse();
        }

        public async Task<PccPatientResponse> GetPatient(int patientId, string baseUrl, List<string> userDefinedFields)
        {
            var url = $"{baseUrl}/orgs/{_orgUuid}/patients/{patientId}";
            var builder = new UriBuilder(url);

            var query = HttpUtility.ParseQueryString(builder.Query);

            if (userDefinedFields != null && userDefinedFields.Count > 0)
            {
                StringBuilder fields = new StringBuilder();

                for (int i = 0; i < userDefinedFields.Count; i++)
                {
                    fields.Append(userDefinedFields[i]);
                    if (i+1 < userDefinedFields.Count)
                    {
                        fields.Append(',');
                    }
                }

                query["includeOptionalFields"] = "patientLegalMailingAddress,userDefinedFields";
                query["userDefinedFields"] = fields.ToString();
                builder.Query = query.ToString();
                url = builder.ToString();
            }
            else
            {
                query["includeOptionalFields"] = "patientLegalMailingAddress";
                builder.Query = query.ToString();
                url = builder.ToString();
            }

            var request = new HttpRequestMessage(HttpMethod.Get, url);
            var response = await GetClientResponse(request);

            using var responseStream = await response.Content.ReadAsStreamAsync();
            var patient = await JsonSerializer.DeserializeAsync<PccPatientResponse>(responseStream);

            return patient ?? new PccPatientResponse();
        }

        public async Task<List<AdtRecords>> GetAdtRecords(int pccPatientId, string url)
        {
            var getAdtRecordsRequest = new HttpRequestMessage(HttpMethod.Get, string.Format(url, _orgUuid) + $"?patientId={pccPatientId}");
            var response = await GetClientResponse(getAdtRecordsRequest);
            using var responseStream = await response.Content.ReadAsStreamAsync();
            var adtRecords = await JsonSerializer.DeserializeAsync<PccAdtRecordsResponse>(responseStream);
            return adtRecords?.Data ?? new List<AdtRecords>();
        }

        public async Task<PccCoveragesResponse> GetCoverages(int patientId, string url)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, string.Format(url, _orgUuid, patientId));
            var response = await GetClientResponse(request);
            using var responseStream = await response.Content.ReadAsStreamAsync();
            var coverages = await JsonSerializer.DeserializeAsync<PccCoveragesResponse>(responseStream);
            return coverages ?? new PccCoveragesResponse();
        }

    }
}
