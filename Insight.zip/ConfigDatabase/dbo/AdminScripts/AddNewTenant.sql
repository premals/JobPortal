﻿INSERT INTO TENANT
VALUES ('Health Care Corp LLC', 'Health Care Corp LLC', 'dev', 'HHC', '7604 Pool Compass Loop', NULL, 'Wesley Chapel', 'FL', '33545', 1, 'Tenant_FamilyLakeLiving', 1, 0, 1, null, 1,GETUTCDATE(),  NULL, NULL),
