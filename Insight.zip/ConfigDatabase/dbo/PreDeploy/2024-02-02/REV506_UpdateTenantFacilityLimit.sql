﻿USING [HelloWorldConfig]

ALTER TABLE tenant
ADD FacilityLimit INT NOT NULL DEFAULT 0

UPDATE tenant
SET FACILITYLIMIT = 100 
WHERE ID = 1 -- Revsuite Solutions

UPDATE tenant
SET FACILITYLIMIT = 10 
WHERE ID = 2 -- Avante Group

UPDATE tenant
SET FACILITYLIMIT = 32 
WHERE ID = 3 -- Aspire Health Group

UPDATE tenant
SET FACILITYLIMIT = 22 
WHERE ID = 4 -- Summit Care

UPDATE tenant
SET FACILITYLIMIT = 1 
WHERE ID = 5 -- Long Term Care Solutions