﻿CREATE TABLE [dbo].[StateChecklistItem]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [StateId] INT NOT NULL, 
    [Name] VARCHAR(50) NOT NULL
)
