﻿
CREATE TABLE [dbo].[MatrixIntegration]
(
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[MatrixFacilityCode] VARCHAR(50) NOT NULL,
	[MatrixFacilityName] VARCHAR(100) NOT NULL,
	[TenantId] [int] NOT NULL,
	[FacilityId] [int] NOT NULL,
	[Enabled] [bit] NOT NULL DEFAULT 0,
	CONSTRAINT [PK_dbo.MatrixIntegration] PRIMARY KEY CLUSTERED ( [Id] ASC)
);
GO
CREATE NONCLUSTERED INDEX [IX_MatrixIntegration_MatrixFacilityCode] ON [dbo].[MatrixIntegration]
([MatrixFacilityCode]) 
GO

ALTER TABLE [dbo].[MatrixIntegration] ADD CONSTRAINT [FK_dbo.MatrixIntegration_dbo.Tenant_Id] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenant] ([Id])
GO