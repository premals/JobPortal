﻿
CREATE TABLE [dbo].[TenantPccIntegration]
(
	[Id] [varchar](128) NOT NULL,
	[OrgUUID] [varchar](50) NOT NULL,
	[TenantId] [int] NOT NULL,
	[FacilityId] [int] NOT NULL,
	[ShowPcc] [bit] NOT NULL DEFAULT 0,
	CONSTRAINT [PK_dbo.TenantIntegration] PRIMARY KEY CLUSTERED ( [Id] ASC)
);
GO
CREATE NONCLUSTERED INDEX [IX_TenantPccIntegration_OrgUUID] ON [dbo].[TenantPccIntegration]
([OrgUUID]) 
GO

ALTER TABLE [dbo].[TenantPccIntegration] ADD CONSTRAINT [FK_dbo.TenantPccIntegration_dbo.Tenant_Id] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenant] ([Id])
GO