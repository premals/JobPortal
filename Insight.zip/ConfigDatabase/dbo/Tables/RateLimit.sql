﻿CREATE TABLE [dbo].[RateLimit]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [Entity] INT NOT NULL,
    [TimeToReset] DATETIME NULL
)
