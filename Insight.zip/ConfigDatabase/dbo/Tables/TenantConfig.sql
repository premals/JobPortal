﻿CREATE TABLE [dbo].[TenantConfig]
(
    [Id] INT NOT NULL IDENTITY (1, 1) PRIMARY KEY, 
    [MedicarePartBAmount] DECIMAL(18, 2) NOT NULL DEFAULT 0.00
)
