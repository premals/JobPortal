﻿CREATE TABLE [dbo].[Gender]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [LookupId] INT NOT NULL, 
    [Name] VARCHAR(20) NOT NULL, 
    [CreatedDate] DATETIMEOFFSET NOT NULL, 
    CONSTRAINT [UC_Gender_LookupId] UNIQUE (Id, LookupId)
)
