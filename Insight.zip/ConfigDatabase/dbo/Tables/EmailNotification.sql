﻿CREATE TABLE [dbo].[EmailNotification]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [TenantId] INT NOT NULL, 
    [FacilityId] INT NOT NULL, 
    [TimeToExecute] DATETIME NULL
)
