﻿using Microsoft.EntityFrameworkCore;
using HelloWorld.Model.DataTables;

namespace HelloWorld.EntityFramework.Context
{
    public class HelloWorldConfigContext : DbContext
    {
        public HelloWorldConfigContext(DbContextOptions<HelloWorldConfigContext> options) : base(options)
        { }

        public DbSet<Tenant> Tenant { get; set; }
        public DbSet<QuickLink> QuickLink { get; set; }
        public DbSet<Gender> Gender { get; set; }
        public DbSet<MaritalStatus> MaritalStatus { get; set; }
        public DbSet<ResidentStatus> ResidentStatus { get; set; }
        public DbSet<Language> Language { get; set; }
        public DbSet<StateProvince> StateProvince { get; set; }
        public DbSet<EmailNotificationType> EmailNotificationType { get; set; }
        public DbSet<EmailNotification> EmailNotification { get; set; }
        public DbSet<StateChecklistItem> StateChecklistItem { get; set; }
        public DbSet<RateLimit> RateLimit { get; set; }
        public DbSet<TenantPccIntegration> TenantPccIntegration { get; set; }
        public DbSet<MatrixIntegration> MatrixIntegration { get; set; }
        public DbSet<TenantConfig> TenantConfig { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
