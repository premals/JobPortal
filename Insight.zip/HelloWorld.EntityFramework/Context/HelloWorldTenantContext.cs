﻿using System;
using Microsoft.EntityFrameworkCore;
using HelloWorld.Model.DataTables;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using HelloWorld.Model;

namespace HelloWorld.EntityFramework.Context
{
    public class HelloWorldTenantContext : DbContext
    {
        public HelloWorldTenantContext(DbContextOptions<HelloWorldTenantContext> options) : base(options)
        { }

        public DbSet<Tenant> Tenant { get; set; }
        public DbSet<Region> Region { get; set; }
        public DbSet<Facility> Facility { get; set; }
        public DbSet<Workstation> Workstation { get; set; }
        public DbSet<Employee> Employee { get; set; }
        public DbSet<EmployeeAccessLevel> EmployeeAccessLevel { get; set; }
        public DbSet<Resident> Resident { get; set; }
        public DbSet<CaseNote> CaseNote { get; set; }
        public DbSet<ResidentDocument> ResidentDocument { get; set; }
        public DbSet<ResidentIncome> ResidentIncome { get; set; }
        public DbSet<ResidentAssetAccount> ResidentAssetAccount { get; set; }
        public DbSet<ResidentLifeInsurancePolicy> ResidentLifeInsurancePolicy { get; set; }
        public DbSet<ResidentBurialAccount> ResidentBurialAccount { get; set; }
        public DbSet<ResidentExpense> ResidentExpense { get; set; }
        public DbSet<AssetType> AssetType { get; set; }
        public DbSet<FacilityDocument> FacilityDocument { get; set; }
        public DbSet<FacilityEmailConfiguration> FacilityEmailConfiguration { get; set; }
        public DbSet<FacilityPlanName> FacilityPlanName { get; set; }
        public DbSet<ResidentCompletedChecklistItem> ResidentCompletedChecklistItems { get; set; }
        public DbSet<FacilityPayerCode> FacilityPayerCode { get; set; }
        public DbSet<ResidentUserDefinedFieldsMap> ResidentUserDefinedFieldsMap { get; set; }
        public DbSet<ResidentPayer> ResidentPayers { get; set; }
        public DbSet<MedicaidEligibilityResult> MedicaidEligibilityResults { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        }
    }
}
