﻿using System;
using System.Collections.Generic;
using System.Linq;
using HelloWorld.EntityFramework.Context;
using HelloWorld.Model.DataTables;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using HelloWorld.EntityFramework.Interfaces;
using HelloWorld.Common.Enumerations;

namespace HelloWorld.EntityFramework
{
	public class ConfigRepository : IConfigRepository
	{
		private DbContextOptionsBuilder<HelloWorldConfigContext> _optionsBuilder;

		public ConfigRepository(IConfiguration configuration)
		{
			_optionsBuilder = new DbContextOptionsBuilder<HelloWorldConfigContext>();
			_optionsBuilder.UseSqlServer(configuration.GetConnectionString("HelloWorldConfigContext"));
		}

		public List<Tenant> GetTenants()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.Tenant.Where(x => x.DatabaseName.StartsWith("Tenant_") && x.DatabaseName != "Tenant_Template").ToList();
			}
		}
		public Tenant GetTenantById(int tenantId)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.Tenant.FirstOrDefault(x => x.Id == tenantId);
			}
		}

		public List<EmailNotification> GetEmailNotifications()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				var emailNotifications = context.EmailNotification.Include(x => x.Tenant).ToList();

				return emailNotifications;
			}
		}

		public void SaveEmailNotification(EmailNotification emailNotification)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.Entry(emailNotification).State = EntityState.Modified;
				context.SaveChanges();
			}
		}

		public List<EmailNotificationType> GetEmailNotificationTypes()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.EmailNotificationType.ToList();
			}
		}

		public TenantPccIntegration GetPccIntegration(int tenantId, int facilityId)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.TenantPccIntegration.FirstOrDefault(x => x.TenantId == tenantId && x.FacilityId == facilityId);
			}
		}

		public TenantPccIntegration GetPccIntegration(string orgUuid)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.TenantPccIntegration.FirstOrDefault(x => x.OrgUUID == orgUuid);
			}
		}

		public TenantPccIntegration SavePccIntegration(TenantPccIntegration tenantPccIntegration)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.Entry(tenantPccIntegration).State = EntityState.Modified;
				context.SaveChanges();
				return GetPccIntegration(tenantPccIntegration.TenantId, tenantPccIntegration.FacilityId);
			}
		}

		public TenantPccIntegration AddPccIntegration(TenantPccIntegration tenantPccIntegration)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.TenantPccIntegration.Add(tenantPccIntegration);
				context.SaveChanges();
				return tenantPccIntegration;
			}
		}

		public Tenant GetTenantByCode(string tenantCode)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.Tenant.FirstOrDefault(x => x.TenantCode == tenantCode);
			}
		}

		public IEnumerable<QuickLink> GetQuickLinks(string stateCode)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.QuickLink
						.Where(x => x.StateCode == stateCode || x.StateCode == null)
						.OrderBy(x => x.OrderId).ToList();
			}
		}

		public IEnumerable<Gender> GetGenders()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.Gender.OrderBy(x => x.Id).ToList();
			}
		}

		public IEnumerable<MaritalStatus> GetMaritalStatuses()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.MaritalStatus.OrderBy(x => x.Id).ToList();
			}
		}

		public IEnumerable<ResidentStatus> GetResidentStatuses()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.ResidentStatus.OrderBy(x => x.Id).ToList();
			}
		}

		public IEnumerable<Language> GetLanguages()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.Language.OrderBy(x => x.Id).ToList();
			}
		}

		public IEnumerable<StateProvince> GetStates()
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.StateProvince.OrderBy(x => x.StateCode).ToList();
			}
		}

		public EmailNotification GetEmailNotification(int tenantId, int facilityId)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.EmailNotification.FirstOrDefault(x => x.FacilityId == facilityId && x.TenantId == tenantId);
			}
		}

		public void DeleteEmailNotification(EmailNotification emailNotification)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.Entry(emailNotification).State = EntityState.Deleted;
				context.SaveChanges();
			}
		}

		public void AddEmailNotification(EmailNotification emailNotification)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.Entry(emailNotification).State = EntityState.Added;
				context.SaveChanges();
			}
		}

		public void UpdateEmailNotification(EmailNotification emailNotification)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.Entry(emailNotification).State = EntityState.Modified;
				context.SaveChanges();
			}
		}

		public List<HelloWorld.Model.DataTables.StateChecklistItem> GetStateChecklistItems(string stateCode)
		{
			List<HelloWorld.Model.DataTables.StateChecklistItem> list = new List<HelloWorld.Model.DataTables.StateChecklistItem>();

			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				list = (from sci in context.StateChecklistItem
						join sp in context.StateProvince
						on sci.StateId equals sp.Id
						where sp.StateCode == stateCode
						select new HelloWorld.Model.DataTables.StateChecklistItem()
						{
							Id = sci.Id,
							StateId = sci.StateId,
							Name = sci.Name
						}).ToList();
			}

			return list;
		}

		public RateLimit GetRateLimit(RateLimitEntity entity)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.RateLimit.Where(x => x.Entity == (int)entity).FirstOrDefault();
			}
		}

		public void UpdateRateLimit(RateLimit rateLimit)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.Entry(rateLimit).State = EntityState.Modified;
				context.SaveChanges();
			}
		}

		public MatrixIntegration GetMatrixIntegration(string facilityCode, string facilityName)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.MatrixIntegration.FirstOrDefault(x => x.MatrixFacilityCode == facilityCode && x.MatrixFacilityName == facilityName);
			}
		}

		public MatrixIntegration GetMatrixIntegration(int tenantId, int facilityId)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				return context.MatrixIntegration.FirstOrDefault(x => x.TenantId == tenantId && x.FacilityId == facilityId);
			}
		}

		public MatrixIntegration SaveMatrixIntegration(MatrixIntegration matrixIntegration)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.Entry(matrixIntegration).State = EntityState.Modified;
				context.SaveChanges();

				return GetMatrixIntegration(matrixIntegration.TenantId, matrixIntegration.FacilityId);
			}
		}

		public MatrixIntegration AddMatrixIntegration(MatrixIntegration matrixIntegration)
		{
			using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
			{
				context.MatrixIntegration.Add(matrixIntegration);
				context.SaveChanges();

				return matrixIntegration;
			}
		}

        public MatrixIntegration GetMatrixIntegrationByMatrixFacilityCode(int tenantId, string matrixFacilityCode)
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                return context.MatrixIntegration.FirstOrDefault(x => x.TenantId == tenantId && x.MatrixFacilityCode == matrixFacilityCode);
            }
        }

        public TenantConfig GetTenantConfig()
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                return context.TenantConfig.FirstOrDefault();
            }
        }

        public void SaveTenantConfig(TenantConfig tenantConfig)
        {
            using (var context = new HelloWorldConfigContext(_optionsBuilder.Options))
            {
                if (tenantConfig.Id <= 0)
                {
                    context.Entry(tenantConfig).State = EntityState.Added;
                }
                else
                {
                    context.Entry(tenantConfig).State = EntityState.Modified;
                }

                context.SaveChanges();
            }
        }
	}
}
