﻿using System.Collections.Generic;
using HelloWorld.Model.DataTables;
using HelloWorld.Common.Enumerations;

namespace HelloWorld.EntityFramework.Interfaces
{
	public interface IConfigRepository
	{
		List<Tenant> GetTenants();
		Tenant GetTenantById(int tenantId);
		Tenant GetTenantByCode(string tenantCode);
		IEnumerable<QuickLink> GetQuickLinks(string stateCode);
		IEnumerable<Gender> GetGenders();
		IEnumerable<MaritalStatus> GetMaritalStatuses();
		IEnumerable<ResidentStatus> GetResidentStatuses();
		IEnumerable<Language> GetLanguages();
		IEnumerable<StateProvince> GetStates();
		EmailNotification GetEmailNotification(int tenantId, int facilityId);
		void DeleteEmailNotification(EmailNotification emailNotification);
		void AddEmailNotification(EmailNotification emailNotification);
		void UpdateEmailNotification(EmailNotification emailNotification);
		List<HelloWorld.Model.DataTables.StateChecklistItem> GetStateChecklistItems(string stateCode);
		RateLimit GetRateLimit(RateLimitEntity entity);
		void UpdateRateLimit(RateLimit rateLimit);
		TenantPccIntegration GetPccIntegration(int tenantId, int facilityId);
		TenantPccIntegration GetPccIntegration(string orgUuid);
		TenantPccIntegration SavePccIntegration(TenantPccIntegration tenantPccIntegration);
		TenantPccIntegration AddPccIntegration(TenantPccIntegration tenantPccIntegration);
		MatrixIntegration GetMatrixIntegration(string facilityCode, string facilityName);
		MatrixIntegration GetMatrixIntegration(int tenantId, int facilityId);
		MatrixIntegration SaveMatrixIntegration(MatrixIntegration matrixIntegration);
		MatrixIntegration AddMatrixIntegration(MatrixIntegration matrixIntegration);
        MatrixIntegration GetMatrixIntegrationByMatrixFacilityCode(int tenantId, string matrixFacilityCode);
        TenantConfig GetTenantConfig();
        void SaveTenantConfig(TenantConfig tenantConfig);
    }
}
