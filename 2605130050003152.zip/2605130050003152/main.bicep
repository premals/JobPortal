// =============================================================================
// MSP Ops AI — Bicep Orchestrator
// =============================================================================
// Wires all infrastructure modules with parameter threading.
// Deploy (production): az deployment group create -g mspopsai-rg -f infra/main.bicep \
//     -p infra/parameters.json -p infra/parameters.production.json
// Non-production deploys must supply alertEmail explicitly (no default), e.g.
//     -p infra/parameters.json -p alertEmail='staging-alerts@example.com'
// =============================================================================

targetScope = 'resourceGroup'

// --- Parameters ---

@description('Azure region for all resources')
param location string = 'uksouth'

@description('Environment name')
@allowed(['production', 'staging'])
param environment string = 'production'

@description('Tags applied to all resources')
param tags object = {
  project: 'mspopsai'
  environment: environment
  managedBy: 'bicep'
}

// Resource names (match existing Azure resources)
@description('Container Registry name')
param acrName string = 'mspopsaiacr'

@description('PostgreSQL server name')
param postgresName string = 'mspopsai-pg'

@description('Key Vault name')
param keyVaultName string = 'mspopsai-kv2'

@description('App Service name')
param appServiceName string = 'mspopsai-app'

@description('App Service Plan name')
param appServicePlanName string = 'mspopsai-plan'

@description('Log Analytics workspace name')
param logAnalyticsName string = 'mspopsai-logs'

@description('Application Insights component name (#513)')
param appInsightsName string = 'mspopsai-appinsights'

@description('AI Services account name')
param aiServicesName string = 'mspopsai-ai2'

@description('Name of the Azure AI Services resource hosting Anthropic Claude deployments (eastus2 — Anthropic MaaS is not available in uksouth). Auto-created by Azure AI Foundry during the Copilot prod unblock; adopted into Bicep under #268.')
param aiServicesAnthropicName string = 'chris-mo29ccif-eastus2'

@description('Location for the Anthropic-hosting AI Services resource. Must be a region where Azure hosts Anthropic MaaS (eastus2 today).')
param aiServicesAnthropicLocation string = 'eastus2'

// Secrets
@secure()
@description('PostgreSQL administrator password')
param dbPassword string

@secure()
@description('Application secret key')
param appSecretKey string

@secure()
@description('Fernet encryption key')
param encryptionKey string

@secure()
@description('Netmo Entra client secret')
param netmoEntraClientSecret string = ''

@secure()
@description('SMTP2Go API key')
param smtp2goApiKey string = ''

@secure()
@description('Stripe secret key')
param stripeSecretKey string = ''

@secure()
@description('Stripe webhook signing secret')
param stripeWebhookSecret string = ''

@secure()
@description('Cloudflare Turnstile secret key for public signup form verification (#578)')
param turnstileSecretKey string = ''

@secure()
@description('HS256 signing secret for self-serve signup verification tokens (#578)')
param signupVerificationSecret string = ''

@description('CSP/GDAP bootstrap multi-tenant Entra app ID (#912 / #973). Surfaced as `CSP_BOOTSTRAP_APP_ID` on App Service. Production value is `8b205387-134b-416e-a4c6-9d2c3eedd6e6` (admin-consented in Netmo tenant 2026-05-08). Not secret — just an app ID — but parameterised so DR rebuilds + non-prod environments can override.')
param cspBootstrapAppId string = ''

@description('Azure Key Vault URL surfaced to App Service as `AZURE_KEYVAULT_URL` (#1015). Read at runtime by `src/mspopsai/services/csp_bootstrap/kv_secret.py` to address the deployment vault. Default is constructed from `keyVaultName` so prod (`mspopsai-kv2`) and non-prod environments resolve to the right vault without per-env overrides; explicitly settable for cross-vault scenarios (DR cutover, soft-delete suffix renames). Constraint `@minLength(1)` enforces fail-loud at template validation time when an explicit override supplies an empty value — empty here is a hard runtime failure (post-#1011 `kv_secret.py` raises in non-dev), not graceful degradation. Was missing from Bicep entirely pre-#1015 — see issue #1015 for the silent-fallback incident this closes.')
@minLength(1)
param azureKeyVaultUrl string = 'https://${keyVaultName}.vault.azure.net/'

@secure()
@description('CSP/GDAP bootstrap Entra app client secret (#912 / #973). Stored in KV as `csp-bootstrap-client-secret` and surfaced via KV reference. Initial value supplied at provisioning time via `az ad app credential reset --id <bootstrap-app>` then written to KV using the locked-down tempfile pattern from `docs/runbooks/key-vault-rotation.md` (`--file "$SECRET_FILE"`, NOT `--value` — the latter leaks the secret to shell history/process list). The `if (!empty(...))` gate on the KV resource preserves existing values across deploys.')
param cspBootstrapClientSecret string = ''

@secure()
@description('VAPID public key for Web Push (#509 Phase 2). Base64-url encoded uncompressed P-256.')
param vapidPublicKey string = ''

@secure()
@description('VAPID private key (PEM-encoded EC) for Web Push (#509 Phase 2). Server-side only.')
param vapidPrivateKey string = ''

@description('VAPID subject identifier (mailto: or https://) — surfaced to push gateways for contact (#509 Phase 2).')
param vapidSubject string = 'mailto:admin@msp-ops.ai'

@description('Stripe price ID for Starter plan')
param stripePriceStarter string = ''

@description('Stripe price ID for Professional plan')
param stripePriceProfessional string = ''

@description('Multi-tenant Entra app client ID for MSP consent flow')
param mspEntraClientId string = '5c2589c2-12c6-45bc-b1d7-380bbc65a57e'

@description('Azure AI Services endpoint URL')
param azureAiEndpoint string = ''

@secure()
@description('Azure AI Services API key')
param azureAiApiKey string = ''

@description('Azure AI Services endpoint URL for embeddings (#407 — uksouth mspopsai-ai2 hosts text-embedding-3-small; separate from the eastus2 Anthropic chat resource)')
param azureAiEmbeddingsEndpoint string = ''

@secure()
@description('Azure AI Services API key for embeddings (#407 — paired with azureAiEmbeddingsEndpoint)')
param azureAiEmbeddingsApiKey string = ''

// Config
@description('Azure AD tenant ID')
param tenantId string = '4f61999e-b56b-40cb-92eb-f602138ebda9'

@description('Email recipient for alert notifications. MUST be overridden per environment (no default — supply via parameters.production.json or --parameters alertEmail=...).')
param alertEmail string

// =============================================================================
// Per-MSP App Insights alerts (#675)
// =============================================================================
// Default empty — module is a no-op until populated. Each entry produces 4
// alerts (error-rate warn/page + p95-latency warn/page) in
// `infra/modules/per-msp-alerts.bicep`. Override per-deploy via parameters
// file. Operators wire `perMspWarnActionGroupId` / `perMspPageActionGroupId`
// to Pushover proxies later — defaults reuse the platform-wide email-only
// action group.
@description('Per-MSP alert targets (#675). Each element: `{ slug: "<dns-friendly slug, used in alert names>", mspId: "<UUID stamped on mspopsai.msp_id span attribute>" }`. Default empty — module is a no-op until populated.')
param mspAlertTargets array = []

@description('Per-MSP failed-request rate warn threshold (percent). Default 5%.')
param perMspErrorRateWarnPct int = 5

@description('Per-MSP failed-request rate page threshold (percent). Default 10%.')
param perMspErrorRatePagePct int = 10

@description('Per-MSP p95 latency warn threshold (ms). Default 2000.')
param perMspP95LatencyWarnMs int = 2000

@description('Per-MSP p95 latency page threshold (ms). Default 5000.')
param perMspP95LatencyPageMs int = 5000

@description('Per-MSP alert window size (ISO 8601 duration). Default PT15M (15 minutes).')
param perMspWindowSize string = 'PT15M'

@description('Per-MSP alert evaluation frequency (ISO 8601 duration). Default PT5M (5 minutes).')
param perMspEvaluationFrequency string = 'PT5M'

@description('Action group ID for warn-tier per-MSP alerts. Empty = use the platform-wide `mspopsai-alerts` group from monitoring.bicep (email-only). Override to a Pushover-priority-0 webhook receiver group when standing up per-MSP Pushover routing.')
param perMspWarnActionGroupId string = ''

@description('Action group ID for page-tier per-MSP alerts. Empty = use the platform-wide `mspopsai-alerts` group. Override to a Pushover-priority-1 webhook receiver group when standing up Pushover paging.')
param perMspPageActionGroupId string = ''

@description('PostgreSQL admin login')
param dbAdminLogin string = 'mspopsai_admin'

@description('CORS allowed origins')
param corsOrigins array = [
  'https://${appServiceName}.azurewebsites.net'
]

@description('Public URL of the app (custom domain or default hostname)')
param appPublicUrl string = 'https://${appServiceName}.azurewebsites.net'

@description('Redis cache name')
param redisName string = 'mspopsai-redis'

@description('Virtual Network name')
param vnetName string = 'mspopsai-vnet'

@description('Blob Storage account name for the file-attachments primitive (#512). 3-24 chars, lowercase + digits, globally unique. Default `mspopsaiblob` matches the contract D1 convention.')
param blobStorageName string = 'mspopsaiblob'

@description('Blob Storage SKU. Standard_GRS for production (geo-redundant), Standard_LRS for non-prod / DR.')
@allowed(['Standard_GRS', 'Standard_LRS', 'Standard_RAGRS', 'Standard_ZRS', 'Standard_GZRS'])
param blobStorageSku string = 'Standard_GRS'

// Feature gates — most default false so `az deployment group create` succeeds
// against the current live state without triggering unplanned infrastructure
// changes. Flip to true when scheduling the corresponding change-window deploy.
// See #214-#218 for the drift reconciliation plan. Post-resolution gates may
// flip to true as their default — e.g. deployAiPrivateEndpoint below post-#216.

@description('Deploy Redis Cache + private endpoint + KV secret. Set true for #217.')
param deployRedis bool = false

@description('Deploy the #512 Phase 1 attachments Storage Account + container + private endpoint + lifecycle. Defaults to false so existing reconciles stay green; flip true via parameters.production.json when running the change-window deploy that stands up the storage primitive.')
param deployBlobStorage bool = false

@description('Enable Microsoft Defender for Storage on the attachments SA (#512 D14). Adds ~$10/SA/month + $0.30/GB scanned. Should stay true in production; non-prod can flip false to land scan_status=skipped via the DEFENDER_SCAN_ENABLED app-side flag.')
param defenderForStorageEnabled bool = true

@description('Deploy the 2 Redis metric alerts (redis-evictions, redis-memory-high) from #553/#626. Defaults to false so fresh deploys / DR bootstraps to RGs without a Redis cache stay green; flip true via parameters.production.json once the cache is provisioned. Independent of `deployRedis` because in live the cache is managed out-of-band but the alerts are managed by Bicep (#777).')
param deployRedisAlerts bool = false

@description('Deploy AI Services private endpoint (flips publicNetworkAccess to Disabled). Defaults to true post-#216. The only reason to flip back to false is to temporarily keep AI Services public-access while the VNet exists — e.g. a partial / staged rebuild where AI traffic must remain routable from outside the VNet during the window.')
param deployAiPrivateEndpoint bool = true

// PostgreSQL parameters — defaults reflect post-#214 hardened state
// (D2s_v3 / ZoneRedundant / 30d). Override to the legacy live state
// (B1ms / Disabled / 7d) only for non-production / DR scenarios where
// the cost / single-zone trade-off is acceptable.
@description('PostgreSQL SKU name. D2s_v3=GeneralPurpose (post-#214 default); B1ms=Burstable for non-production / DR.')
param postgresSkuName string = 'Standard_D2s_v3'

@description('PostgreSQL SKU tier. GeneralPurpose (post-#214 default); Burstable for non-production / DR.')
param postgresSkuTier string = 'GeneralPurpose'

@description('PostgreSQL HA mode. ZoneRedundant (post-#214 default — provisions a standby replica in another availability zone); Disabled for single-zone non-production deployments.')
param postgresHaMode string = 'ZoneRedundant'

@description('PostgreSQL backup retention days. 30 (post-#214 default); 7 for non-production / DR.')
param postgresBackupRetentionDays int = 30

@description('PostgreSQL storage tier. Derived from storageSizeGB per Azure tier table (P4=32 GiB, P6=64, P10=128, …). Default P4 matches current 32 GiB live.')
param postgresStorageTier string = 'P4'

@description('PostgreSQL storage IOPS cap. Must match the Azure-default cap for the selected storageTier (P4=120, P6=240, P10=500, …). Default 120 matches P4.')
param postgresStorageIops int = 120

// =============================================================================
// Module deployments
// =============================================================================

// 1. Networking (VNet, subnets, private DNS zone — must deploy first)
module networking 'modules/networking.bicep' = {
  name: 'networking'
  params: {
    name: vnetName
    location: location
    tags: tags
  }
}

// 2. Log Analytics (needed by other modules for diagnostics)
module logAnalytics 'modules/log-analytics.bicep' = {
  name: 'log-analytics'
  params: {
    name: logAnalyticsName
    location: location
    tags: tags
  }
}

// 3. Application Insights (#513) — workspace-based mode, linked to logAnalytics.
// Connection string is captured into Key Vault below so the App Service can
// reference it via @Microsoft.KeyVault(...) at runtime.
module appInsights 'modules/app-insights.bicep' = {
  name: 'app-insights'
  params: {
    name: appInsightsName
    location: location
    tags: tags
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
  }
}

// 4. Container Registry
module acr 'modules/acr.bicep' = {
  name: 'acr'
  params: {
    name: acrName
    location: location
    tags: tags
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
  }
}

// 5. PostgreSQL (private access via VNet delegated subnet)
// SKU/HA/backup params default to the post-#214 hardened state
// (D2s_v3 / ZoneRedundant / 30d). Override down to legacy
// (B1ms / Disabled / 7d) only for non-production / DR scenarios.
module postgresql 'modules/postgresql.bicep' = {
  name: 'postgresql'
  params: {
    name: postgresName
    location: location
    tags: tags
    skuName: postgresSkuName
    skuTier: postgresSkuTier
    haMode: postgresHaMode
    backupRetentionDays: postgresBackupRetentionDays
    storageTier: postgresStorageTier
    storageIops: postgresStorageIops
    adminLogin: dbAdminLogin
    adminPassword: dbPassword
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
    pgSubnetId: networking.outputs.pgSubnetId
    pgDnsZoneId: networking.outputs.pgDnsZoneId
  }
}

// 6. Key Vault (stores secrets, grants access to SPs)
module keyVault 'modules/keyvault.bicep' = {
  name: 'keyvault'
  params: {
    name: keyVaultName
    location: location
    tags: tags
    tenantId: tenantId
    dbPassword: dbPassword
    dbConnectionString: 'postgresql+asyncpg://${dbAdminLogin}:${dbPassword}@${postgresql.outputs.fqdn}:5432/mspopsai?sslmode=require'
    appSecretKey: appSecretKey
    encryptionKey: encryptionKey
    netmoEntraClientSecret: netmoEntraClientSecret
    smtp2goApiKey: smtp2goApiKey
    stripeSecretKey: stripeSecretKey
    stripeWebhookSecret: stripeWebhookSecret
    turnstileSecretKey: turnstileSecretKey
    signupVerificationSecret: signupVerificationSecret
    cspBootstrapClientSecret: cspBootstrapClientSecret
    vapidPublicKey: vapidPublicKey
    vapidPrivateKey: vapidPrivateKey
    stripePriceStarter: stripePriceStarter
    stripePriceProfessional: stripePriceProfessional
    mspEntraClientId: mspEntraClientId
    azureAiEndpoint: azureAiEndpoint
    azureAiApiKey: azureAiApiKey
    azureAiEmbeddingsEndpoint: azureAiEmbeddingsEndpoint
    azureAiEmbeddingsApiKey: azureAiEmbeddingsApiKey
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
  }
}

// Store the Application Insights connection string in Key Vault (#513).
// The connection string carries an instrumentation key embedded in its
// `InstrumentationKey=...` segment, so it's treated as sensitive and gated
// through KV — App Service references it via @Microsoft.KeyVault(...) below.
resource kvForAppInsights 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: keyVaultName
}

resource secretAppInsightsConnectionString 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kvForAppInsights
  name: 'appinsights-connection-string'
  properties: {
    value: appInsights.outputs.connectionString
  }
  dependsOn: [
    keyVault
  ]
}

// Store Redis connection string in Key Vault (uses listKeys on the existing
// resource — cannot be done inside a module without outputting the secret).
// Gated on deployRedis because the `existing` reference + listKeys() fail
// with ResourceNotFound when Redis hasn't been provisioned yet. See #217.
resource redisCache 'Microsoft.Cache/redis@2023-08-01' existing = if (deployRedis) {
  name: redisName
}

resource kvForRedis 'Microsoft.KeyVault/vaults@2023-07-01' existing = if (deployRedis) {
  name: keyVaultName
}

resource secretRedisConnectionString 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = if (deployRedis) {
  parent: kvForRedis
  name: 'redis-connection-string'
  properties: {
    value: 'rediss://:${redisCache.listKeys().primaryKey}@${redis.outputs.hostName}:${redis.outputs.sslPort}/0'
  }
  dependsOn: [
    keyVault
  ]
}

// 7. App Service (depends on ACR, Key Vault, Log Analytics, networking)
module appService 'modules/app-service.bicep' = {
  name: 'app-service'
  params: {
    planName: appServicePlanName
    appName: appServiceName
    location: location
    tags: tags
    acrLoginServer: acr.outputs.loginServer
    keyVaultName: keyVaultName
    environment: environment
    corsOrigins: corsOrigins
    appPublicUrl: appPublicUrl
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
    appSubnetId: networking.outputs.appSubnetId
    vapidSubject: vapidSubject
    cspBootstrapAppId: cspBootstrapAppId
    azureKeyVaultUrl: azureKeyVaultUrl
  }
}

// 8. Monitoring (depends on App Service)
// `deployRedisAlerts` is threaded from the top-level param (default false) so
// fresh deploys / DR bootstraps to RGs without a Redis cache stay green —
// production sets it `true` in parameters.production.json. The 2 Redis alerts
// (redis-evictions, redis-memory-high) were created via a targeted wrapper
// template in #777 because the #347 migrate-slot blocker prevents a full
// `az deployment group create` against this template. Note that this flag is
// independent of `deployRedis` (section 9): in live, the cache is managed
// out-of-band but the alerts are managed by Bicep, so the two flags diverge.
// The alert gate only does an `existing` lookup on the cache, which works
// regardless of whether main.bicep declares the cache itself.
module monitoring 'modules/monitoring.bicep' = {
  name: 'monitoring'
  params: {
    location: location
    tags: tags
    appServiceId: appService.outputs.id
    appServiceName: appServiceName
    appServicePlanId: appService.outputs.planId
    alertEmail: alertEmail
    deployRedisAlerts: deployRedisAlerts
  }
}

// 8b. Per-MSP App Insights alerts (#675) — emits 4 KQL log alerts per MSP in
// `mspAlertTargets`. No-op when the array is empty (default). Severity 1 +
// severity 2 alerts route to separate action groups so an operator can wire
// page-tier delivery (Pushover priority 1) and warn-tier delivery (priority
// 0) independently. Defaults route both tiers to `monitoring`'s shared
// email-only action group until the Pushover proxy is stood up.
module perMspAlerts 'modules/per-msp-alerts.bicep' = {
  name: 'per-msp-alerts'
  params: {
    tags: tags
    appInsightsId: appInsights.outputs.id
    warnActionGroupId: empty(perMspWarnActionGroupId) ? monitoring.outputs.actionGroupId : perMspWarnActionGroupId
    pageActionGroupId: empty(perMspPageActionGroupId) ? monitoring.outputs.actionGroupId : perMspPageActionGroupId
    mspTargets: mspAlertTargets
    errorRateWarnPct: perMspErrorRateWarnPct
    errorRatePagePct: perMspErrorRatePagePct
    p95LatencyWarnMs: perMspP95LatencyWarnMs
    p95LatencyPageMs: perMspP95LatencyPageMs
    windowSize: perMspWindowSize
    evaluationFrequency: perMspEvaluationFrequency
  }
}

// 8c. Blob Storage — file attachments primitive (#512 Phase 1)
// Single shared Storage Account hosting the ``attachments`` + ``quarantine``
// containers. Tenant isolation is enforced at the API layer (D12); the path
// scheme `{msp_id}/{entity_type}/{entity_id}/{filename}` is debuggable but
// not security-relevant. Defender-for-Storage is on by default in prod; the
// `defenderForStorageEnabled` flag lets non-prod environments cut the cost
// and rely on the app-side `DEFENDER_SCAN_ENABLED=false` fallback to land
// rows as scan_status=skipped. `deployBlobStorage` defaults false so a fresh
// reconcile against live (which doesn't have the SA yet) stays green; the
// production change-window deploy flips it true via parameters.production.json.
module blobStorage 'modules/storage.bicep' = if (deployBlobStorage) {
  name: 'blob-storage'
  params: {
    name: blobStorageName
    location: location
    tags: tags
    skuName: blobStorageSku
    appSubnetId: networking.outputs.appSubnetId
    blobDnsZoneId: networking.outputs.blobDnsZoneId
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
    defenderForStorageEnabled: defenderForStorageEnabled
  }
}

// Stash the SA connection string in Key Vault so App Service can reference
// it via @Microsoft.KeyVault(...). listKeys() must live outside the storage
// module (the module would otherwise have to output the secret in a non-
// secure way). Mirror of the redis pattern above.
resource blobStorageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' existing = if (deployBlobStorage) {
  name: blobStorageName
}

resource kvForBlobStorage 'Microsoft.KeyVault/vaults@2023-07-01' existing = if (deployBlobStorage) {
  name: keyVaultName
}

resource secretBlobStorageConnectionString 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = if (deployBlobStorage) {
  parent: kvForBlobStorage
  name: 'blob-storage-connection-string'
  properties: {
    value: 'DefaultEndpointsProtocol=https;AccountName=${blobStorageName};AccountKey=${blobStorageAccount.listKeys().keys[0].value};EndpointSuffix=core.windows.net'
  }
  dependsOn: [
    keyVault
    blobStorage
  ]
}

// 9. Redis (shared state for multi-replica, private endpoint)
// Gated on deployRedis. The Redis cache IS provisioned in live (Basic C0
// deployed 2026-04-16 per docs/multi-replica.md) but `deployRedis` stays
// false because the cache was provisioned out-of-band via direct `az`
// commands rather than this template — flipping it true is a separate
// change-window task that would require a clean reconcile against live.
// When ready, set deployRedis=true in parameters.production.json and run
// az deployment group create during a change window.
module redis 'modules/redis.bicep' = if (deployRedis) {
  name: 'redis'
  params: {
    name: redisName
    location: location
    tags: tags
    redisSubnetId: networking.outputs.redisSubnetId
    redisDnsZoneId: networking.outputs.redisDnsZoneId
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
  }
}

// 10. AI Services (private endpoint gated on deployAiPrivateEndpoint)
// Default true post-#216: publicNetworkAccess=Disabled + private endpoint
// in ai-subnet (10.0.4.0/24) + DNS zone group linking the endpoint to
// privatelink.cognitiveservices.azure.com. AI Services traffic from App
// Service stays inside the VNet end-to-end. Set false only for partial
// / staged rebuilds where AI must temporarily remain publicly reachable
// during the cutover window — module then skips the private endpoint and
// publicNetworkAccess stays Enabled (legacy posture).
module aiServices 'modules/ai-services.bicep' = {
  name: 'ai-services'
  params: {
    name: aiServicesName
    location: location
    tags: tags
    aiSubnetId: deployAiPrivateEndpoint ? networking.outputs.aiSubnetId : ''
    aiDnsZoneId: deployAiPrivateEndpoint ? networking.outputs.aiDnsZoneId : ''
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
  }
}

// 10b. AI Services — Anthropic (eastus2)
// Anthropic Claude MaaS is not available in uksouth, so production uses a
// second AI Services resource in eastus2. This resource was auto-created by
// Azure AI Foundry during the Copilot prod unblock (see #268) and is adopted
// into Bicep here without changing its live state:
//   - tags: {} (live has none; module default)
//   - subnet + DNS: empty (private endpoint is out of scope for this resource
//     — cross-region VNet peering is not worth the complexity for eastus2.
//     See the note in modules/ai-services.bicep for why the Anthropic model
//     deployment on this resource is NOT IaC-manageable.)
module aiServicesAnthropic 'modules/ai-services.bicep' = {
  name: 'ai-services-anthropic'
  params: {
    name: aiServicesAnthropicName
    location: aiServicesAnthropicLocation
    tags: {}
    aiSubnetId: ''
    aiDnsZoneId: ''
    // The Anthropic eastus2 account hosts `claude-sonnet-4-6` (chat),
    // NOT `text-embedding-3-small`. Without this `false`, the module
    // would unconditionally try to deploy the embedding model here too —
    // surfaced by drift-check #240 as a Create entry on this account.
    deployEmbeddings: false
    // diagnosticSettings (#660) — cross-region routing into the uksouth
    // Log Analytics workspace. Same security-audit rationale as the
    // uksouth invocation; the diagnostic data path crosses regions but
    // that's acceptable for low-volume audit logs.
    logAnalyticsWorkspaceId: logAnalytics.outputs.id
  }
}

// =============================================================================
// Outputs
// =============================================================================

@description('ACR login server')
output acrLoginServer string = acr.outputs.loginServer

@description('App Service default hostname')
output appHostname string = appService.outputs.defaultHostname

@description('PostgreSQL FQDN')
output pgFqdn string = postgresql.outputs.fqdn

@description('Key Vault URI')
output keyVaultUri string = keyVault.outputs.vaultUri

@description('Log Analytics workspace ID')
output logAnalyticsId string = logAnalytics.outputs.id

@description('AI Services endpoint (uksouth — general-purpose; no Anthropic deployments today)')
output aiServicesEndpoint string = aiServices.outputs.endpoint

@description('AI Services endpoint (eastus2 — hosts the Anthropic Claude deployments used in production)')
output aiServicesAnthropicEndpoint string = aiServicesAnthropic.outputs.endpoint

@description('Redis hostname (empty when deployRedis is false)')
output redisHostName string = deployRedis ? redis.outputs.hostName : ''

@description('App Service managed identity principal ID')
output appPrincipalId string = appService.outputs.principalId
