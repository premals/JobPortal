// =============================================================================
// App Service Plan (P1v3 Linux, post-#384) + Web App (Docker from ACR) + Auto-scale
// =============================================================================

@description('Name of the App Service Plan')
param planName string = 'mspopsai-plan'

@description('Name of the Web App')
param appName string

@description('Azure region')
param location string

@description('Tags for the resource')
param tags object = {}

@description('ACR login server (e.g. mspopsaiacr.azurecr.io)')
param acrLoginServer string

@description('Environment name (production/staging)')
param environment string = 'production'

@description('Key Vault name for secret references')
param keyVaultName string = ''

@description('PostgreSQL connection string (Key Vault reference or direct)')
param dbConnectionString string = ''

@description('Log Analytics workspace ID for diagnostics')
param logAnalyticsWorkspaceId string = ''

@description('Allowed CORS origins')
param corsOrigins array = []

@description('Public URL of the app (e.g. https://app.msp-ops.ai)')
param appPublicUrl string = ''

@description('App Service outbound subnet ID for regional VNet integration.')
param appSubnetId string = ''

@description('VAPID subject identifier for Web Push (#509 Phase 2). mailto: or https:// per spec.')
param vapidSubject string = 'mailto:admin@msp-ops.ai'

@description('CSP/GDAP bootstrap Entra app ID (#912 / #973). Surfaced as `CSP_BOOTSTRAP_APP_ID` on the prod slot only — the migrate slot only runs `alembic upgrade head` and never touches the wizard. Default empty leaves the appSetting at literal `""` which the orchestrator code treats as "not configured" (clean 503 toast in the wizard). Production value: `8b205387-134b-416e-a4c6-9d2c3eedd6e6` (admin-consented in Netmo tenant 2026-05-08).')
param cspBootstrapAppId string = ''

@description('Azure Key Vault URL surfaced to the app as `AZURE_KEYVAULT_URL` (#1015). Read at runtime by `src/mspopsai/services/csp_bootstrap/kv_secret.py` to address `mspopsai-kv2` for partner-side credential storage. Module input contract requires a non-empty value (`@minLength(1)`) — unlike `cspBootstrapAppId` (graceful degradation when empty), an empty value here is a hard runtime failure post-#1011 (`kv_secret.py` raises in non-dev). The orchestrator (`main.bicep`) supplies the value with a default constructed from `keyVaultName`. Pre-#1015 this appSetting was never declared in Bicep; an absent value routed `kv_secret.py` into its dev-only in-memory fallback, which silently lost a partner-side credential on 2026-05-09 (post-mortem: docs/lessons-learned.md § 2026-05-09).')
@minLength(1)
param azureKeyVaultUrl string

@description('App Service Plan SKU name (P1v3 for PremiumV3, S1 for Standard)')
param skuName string = 'P1v3'

@description('App Service Plan SKU tier')
param skuTier string = 'PremiumV3'

@description('Minimum number of instances for auto-scale')
param autoScaleMinInstances int = 2

@description('Maximum number of instances for auto-scale')
param autoScaleMaxInstances int = 5

@description('Default number of instances')
param autoScaleDefaultInstances int = 2

// -----------------------------------------------------------------------------
// Shared app settings
// -----------------------------------------------------------------------------
// Extracted into a module-level variable so the production `app` resource AND
// the `migrate` validation slot (see `migrateSlot` below, added in #246) both
// reference the same settings bundle. Without this extraction, declaring
// `appSettings` on a slot resource REPLACES the parent's settings at the slot
// scope (Azure does not merge them), which would mean duplicating every
// Key Vault reference by hand and risking drift between the two bundles.
//
// The slot applies additional `slotSpecificOverrides` on top via `concat(...)`
// below. ARM resolves duplicate app setting names using last-wins semantics,
// so the slot override wins wherever a key appears in both arrays.
// -----------------------------------------------------------------------------
var sharedAppSettings = [
  {
    name: 'WEBSITES_PORT'
    value: '8000'
  }
  {
    // Use Azure's platform DNS resolver (168.63.129.16) so the VNet-linked
    // private DNS zone resolves PostgreSQL's FQDN to its private IP.
    name: 'WEBSITE_DNS_SERVER'
    value: '168.63.129.16'
  }
  {
    name: 'WEBSITES_ENABLE_APP_SERVICE_STORAGE'
    value: 'false'
  }
  {
    // Pinned to 3 workers per instance for the post-#384 PremiumV3 / P1v3
    // plan. The S1 → P1v3 move (3.5 GB → 8 GB RAM) made multi-worker
    // viable: 3 workers × ~700 MB each = 2.1 GB, leaving 5.9 GB headroom.
    // Earlier OOM incidents tracked in #234 had pinned this to 1 on S1;
    // that ceiling no longer applies on PremiumV3. Migrate slot still
    // overrides back to 1 via slotSpecificOverrides so the slot's footprint
    // stays small during validation runs (see comment by slotSpecificOverrides).
    name: 'UVICORN_WORKERS'
    value: '3'
  }
  {
    // Cap HTTP-log retention at 3 days so logs don't accumulate indefinitely
    // on the App Service platform storage. Azure's default when unset is
    // "no retention policy" which means logs are retained indefinitely and
    // storage costs grow unbounded. 3 days is long enough to catch same-day
    // issues during an on-call rotation and investigate within a normal
    // workday the next morning, short enough to keep platform storage usage
    // bounded. Backported from live on 2026-04-21 (refs #343 — the live
    // value was set manually outside IaC at some earlier point; Bicep needs
    // to own it going forward so `az deployment group create` doesn't strip
    // it via the wholesale appSettings replacement).
    name: 'WEBSITE_HTTPLOGGING_RETENTION_DAYS'
    value: '3'
  }
  {
    name: 'DOCKER_REGISTRY_SERVER_URL'
    value: 'https://${acrLoginServer}'
  }
  {
    name: 'DATABASE_URL'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=db-connection-string)'
      : dbConnectionString
  }
  {
    name: 'APP_SECRET_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=app-secret-key)'
      : ''
  }
  {
    name: 'SETTINGS_ENCRYPTION_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=encryption-key)'
      : ''
  }
  {
    name: 'APP_ENV'
    value: environment
  }
  {
    name: 'LOG_LEVEL'
    value: environment == 'production' ? 'WARNING' : 'INFO'
  }
  {
    name: 'APP_PUBLIC_URL'
    value: appPublicUrl
  }
  {
    name: 'APP_BASE_URL'
    value: appPublicUrl
  }
  {
    name: 'CORS_ALLOWED_ORIGINS'
    value: !empty(corsOrigins) ? join(corsOrigins, ',') : ''
  }
  {
    name: 'NETMO_ENTRA_CLIENT_ID'
    value: 'e54a1815-8bea-4f34-aee1-283cf7e378af'
  }
  {
    name: 'NETMO_ENTRA_CLIENT_SECRET'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=netmo-entra-client-secret)'
      : ''
  }
  {
    name: 'MSP_ENTRA_CLIENT_ID'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=msp-entra-client-id)'
      : ''
  }
  {
    name: 'SMTP2GO_API_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=smtp2go-api-key)'
      : ''
  }
  {
    name: 'SMTP2GO_DEFAULT_SENDER'
    value: 'onboarding@msp-ops.ai'
  }
  {
    name: 'SMTP2GO_DEFAULT_SENDER_NAME'
    value: 'MSP Ops AI'
  }
  {
    name: 'STRIPE_SECRET_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=stripe-secret-key)'
      : ''
  }
  {
    name: 'STRIPE_WEBHOOK_SECRET'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=stripe-webhook-secret)'
      : ''
  }
  // #578 — signup-flow secrets. Live had these as plain App Service config
  // values from the Stripe-billing pre-launch sequence (#564); Bicep now
  // owns the appSetting declaration so a full-template reconcile no longer
  // drops them. Source values live in the deployment's Key Vault (param
  // `keyVaultName`) under `turnstile-secret-key` + `signup-verification-secret`.
  {
    name: 'TURNSTILE_SECRET_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=turnstile-secret-key)'
      : ''
  }
  {
    name: 'SIGNUP_VERIFICATION_SECRET'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=signup-verification-secret)'
      : ''
  }
  // #509 Phase 2 — Web Push (VAPID). Public + private key fetched from KV;
  // subject is plain config (not secret). All three must be set for the
  // PushChannel to fire — when any are empty the channel soft-fails (warn-log
  // only) so envs without keys keep the dispatcher healthy.
  {
    name: 'VAPID_PUBLIC_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=vapid-public-key)'
      : ''
  }
  {
    name: 'VAPID_PRIVATE_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=vapid-private-key)'
      : ''
  }
  {
    name: 'VAPID_SUBJECT'
    value: vapidSubject
  }
  {
    name: 'STRIPE_PRICE_STARTER'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=stripe-price-starter)'
      : ''
  }
  {
    name: 'STRIPE_PRICE_PROFESSIONAL'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=stripe-price-professional)'
      : ''
  }
  {
    name: 'AZURE_AI_ENDPOINT'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=azure-ai-endpoint)'
      : ''
  }
  {
    name: 'AZURE_AI_API_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=azure-ai-api-key)'
      : ''
  }
  // #407 — embeddings-specific endpoint + key for the uksouth `mspopsai-ai2`
  // resource that hosts text-embedding-3-small. Falls back to the chat
  // endpoint+key in embedder.py when these are unset (backward compat for
  // single-resource deployments).
  {
    name: 'AZURE_AI_EMBEDDINGS_ENDPOINT'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=azure-ai-embeddings-endpoint)'
      : ''
  }
  {
    name: 'AZURE_AI_EMBEDDINGS_API_KEY'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=azure-ai-embeddings-api-key)'
      : ''
  }
  {
    name: 'REDIS_URL'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=redis-connection-string)'
      : ''
  }
  // #356 MSP knowledge base — D1 pinned to pgvector + D3 pins the
  // embedding model. Per #407 the embeddings call now uses the dedicated
  // AZURE_AI_EMBEDDINGS_* settings above (uksouth `mspopsai-ai2`) and falls
  // back to the chat AZURE_AI_* settings only when those are unset. The
  // OpenAI-compatible embeddings endpoint is at
  // {endpoint}/openai/deployments/<name>/embeddings.
  {
    name: 'AZURE_AI_EMBEDDINGS_DEPLOYMENT'
    value: 'text-embedding-3-small'
  }
  {
    name: 'KNOWLEDGE_BASE_BACKEND'
    value: 'pgvector'
  }
]

// Prod-slot-only app settings (#513).
//
// `APPLICATIONINSIGHTS_CONNECTION_STRING` is the env var the
// azure-monitor-opentelemetry distro reads at startup to wire OpenTelemetry
// → App Insights. We deliberately scope it to the PROD slot only — adding
// new app settings to the migrate slot triggers the #347 full-template
// reconcile failure (`Invalid values supplied for Azure Files related app
// settings`). The migrate slot performs `alembic upgrade head` only; it
// doesn't need to emit traces. Trace volume from the slot would also dilute
// prod traces. The cloud_RoleName disambiguation idea from #513's PR body is
// deferred until we wire App Insights into the migrate slot in a later
// change-window deploy that fixes the underlying #347 root cause.
//
// `OTEL_SERVICE_NAME` + `OTEL_RESOURCE_ATTRIBUTES` are non-sensitive resource
// identifiers — declared as plain values here; the SDK reads them at
// initialisation. The `service.namespace` value matches the project tag on
// the resource group so traces filterable across both surfaces.
var prodOnlyAppSettings = [
  {
    name: 'APPLICATIONINSIGHTS_CONNECTION_STRING'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=appinsights-connection-string)'
      : ''
  }
  {
    name: 'OTEL_SERVICE_NAME'
    value: 'mspopsai-api'
  }
  {
    name: 'OTEL_RESOURCE_ATTRIBUTES'
    value: 'deployment.environment=${environment},service.namespace=mspopsai'
  }
  // #912 / #973 — CSP/GDAP onboarding wizard configuration. Same
  // prod-slot-only treatment as the App Insights settings above: adding
  // these to `sharedAppSettings` would propagate to the migrate slot via
  // `concat(sharedAppSettings, slotSpecificOverrides)` (line ~724) and
  // trigger the #347 full-template reconcile blocker. The migrate slot
  // doesn't need them — it only runs `alembic upgrade head` and never
  // touches the wizard. Pre-#973 these were patched directly onto the
  // prod slot via `az webapp config appsettings set` because Bicep was
  // never updated when the epic shipped; now declared in IaC so DR
  // rebuilds and full template reconciles preserve them.
  {
    name: 'CSP_BOOTSTRAP_APP_ID'
    value: cspBootstrapAppId
  }
  {
    name: 'CSP_BOOTSTRAP_CLIENT_SECRET'
    value: !empty(keyVaultName)
      ? '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=csp-bootstrap-client-secret)'
      : ''
  }
  // The redirect URI MUST match one of the bootstrap Entra app's
  // registered web redirect URIs (see `infra/README.md` Section 2 for
  // the canonical list). Computed from `appPublicUrl` so non-prod
  // environments automatically wire to the right host.
  //
  // Post-#978 this points at the **server-side** callback at
  // `/api/v1/csp/consent-callback` — Microsoft's `/adminconsent`
  // redirect lands on the backend, the handler validates the HMAC-
  // signed state token (recovers `msp_id` server-side), records the
  // partner tenant, and 302s back to the wizard at
  // `/app/csp-wizard?completed=true`. Sidesteps the cross-tenant
  // MSAL session loss that broke the previous SPA-route callback.
  {
    name: 'CSP_BOOTSTRAP_CONSENT_REDIRECT_URI'
    value: !empty(appPublicUrl) ? '${appPublicUrl}/api/v1/csp/consent-callback' : ''
  }
  // #1015 — Azure Key Vault URL for `kv_secret.py` runtime addressing of
  // `mspopsai-kv2`. Same prod-slot-only treatment as the App Insights and
  // CSP_BOOTSTRAP_* settings above: the migrate slot does not exercise the
  // CSP-bootstrap helper (alembic-only at boot) and adding new app settings
  // to that slot trips the #347 full-template reconcile blocker. The matching
  // app-side change in #1011 made an empty value RAISE in non-dev — this
  // declaration ensures the value is never empty in prod. Operator applies
  // the same setting to the migrate slot manually post-merge via
  // `az webapp config appsettings set --slot migrate` (parity only — the
  // slot does not need it functionally).
  {
    name: 'AZURE_KEYVAULT_URL'
    value: azureKeyVaultUrl
  }
  // I-4 — pins Azure App Service's grace-period between SIGTERM and SIGKILL
  // to its documented platform default of 30 seconds. The graceful-shutdown
  // signal handler at `src/mspopsai/lifecycle.py` flips `/health` to 503 on
  // SIGTERM and schedules uvicorn's shutdown 15 seconds later
  // (GRACEFUL_DRAIN_SECONDS); the 30s ceiling here is the safety buffer
  // that guarantees App Service doesn't truncate us mid-drain. Declared
  // here in IaC so a portal-level edit or platform-default change can't
  // silently shorten the window. Prod-slot-only because the migrate slot
  // doesn't serve customer traffic and adding new keys to it trips #347.
  {
    name: 'WEBSITES_CONTAINER_STOP_TIME_LIMIT'
    value: '30'
  }
]

// Slot-specific overrides for the `migrate` validation slot (#246).
//
// - UVICORN_WORKERS=1 keeps the slot's memory footprint small. Originally
//   needed to avoid the 2026-04-13/14 OOM pattern (#234) on the shared S1
//   plan (3.5 GB RAM). Post-#384 the plan is P1v3 (8 GB) so this is no
//   longer strictly necessary, but a single-worker slot is still the right
//   default — slot validation runs migrations + a short smoke window, not
//   sustained traffic, and one worker is sufficient for that workload.
// - LOG_LEVEL=INFO gives full migration visibility during validation (prod
//   uses WARNING in production to reduce log volume).
//
// These are appended to `sharedAppSettings` via `concat(...)`. ARM uses
// last-wins semantics on duplicate app setting names, so the LOG_LEVEL
// entry here correctly overrides the LOG_LEVEL in sharedAppSettings.
var slotSpecificOverrides = [
  {
    name: 'UVICORN_WORKERS'
    value: '1'
  }
  {
    name: 'LOG_LEVEL'
    value: 'INFO'
  }
]

// App Service Plan
resource plan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: planName
  location: location
  tags: tags
  kind: 'linux'
  sku: {
    name: skuName
    tier: skuTier
  }
  properties: {
    reserved: true // Required for Linux
  }
}

// Auto-scale rules: scale out at CPU > 70%, scale in at CPU < 30%.
//
// NOTE (#240 triage): live is currently missing the scale-DOWN rule — only the
// scale-UP rule (CPU > 70%) is present. Origin of that delta is unknown; #218's
// CLI commands are documented as creating BOTH rules, so either a later
// portal / CLI edit removed it or #218's second `az monitor autoscale rule
// create` invocation silently failed. We keep Bicep as source-of-truth
// (scale-down rule stays declared); a separate change-window deploy will
// restore it in live. What-if will continue to report this as one residual
// Modify until then — tracked in a follow-up Chore issue.
//
// The `tags: {}` override mirrors live's empty tags (live was created via
// `az monitor autoscale create` in #218 without --tags). The five additional
// properties below (name inside properties, notifications, predictiveAutoscale
// Policy, metricTrigger.dividePerInstance) are Azure defaults that the ARM API
// echoes back on GET — declared explicitly to silence phantom what-if drift.
resource autoScale 'Microsoft.Insights/autoscalesettings@2022-10-01' = {
  name: '${planName}-autoscale'
  location: location
  tags: {}
  properties: {
    name: '${planName}-autoscale'
    targetResourceUri: plan.id
    enabled: true
    predictiveAutoscalePolicy: {
      scaleMode: 'Disabled'
    }
    notifications: [
      {
        operation: 'Scale'
        email: {
          sendToSubscriptionAdministrator: false
          sendToSubscriptionCoAdministrators: false
          customEmails: []
        }
        webhooks: []
      }
    ]
    profiles: [
      {
        name: 'default'
        capacity: {
          minimum: string(autoScaleMinInstances)
          maximum: string(autoScaleMaxInstances)
          default: string(autoScaleDefaultInstances)
        }
        rules: [
          {
            metricTrigger: {
              metricName: 'CpuPercentage'
              metricResourceUri: plan.id
              timeGrain: 'PT1M'
              statistic: 'Average'
              timeWindow: 'PT10M'
              timeAggregation: 'Average'
              operator: 'GreaterThan'
              threshold: 70
              dividePerInstance: false
            }
            scaleAction: {
              direction: 'Increase'
              type: 'ChangeCount'
              value: '1'
              cooldown: 'PT5M'
            }
          }
          {
            metricTrigger: {
              metricName: 'CpuPercentage'
              metricResourceUri: plan.id
              timeGrain: 'PT1M'
              statistic: 'Average'
              timeWindow: 'PT10M'
              timeAggregation: 'Average'
              operator: 'LessThan'
              threshold: 30
              dividePerInstance: false
            }
            scaleAction: {
              direction: 'Decrease'
              type: 'ChangeCount'
              value: '1'
              cooldown: 'PT5M'
            }
          }
        ]
      }
    ]
  }
}

// Web App
//
// siteConfig is SPLIT between the parent `Microsoft.Web/sites` resource and a
// child `Microsoft.Web/sites/config@2023-12-01` name='web' resource below.
// Root cause (#240): Azure stores siteConfig in two places and the 2023-12-01
// GET on the parent returns `null` for a specific subset of keys (cors,
// ftpsState, healthCheckPath, minTlsVersion, vnetRouteAllEnabled,
// localMySqlEnabled, netFrameworkVersion) even though those values are correctly
// set — they only surface via `config/web`. Declaring them inline on the parent
// makes `what-if` perpetually report them as Create drift. Splitting fixes this.
// Keys that DO round-trip through the parent (acrUseManagedIdentityCreds,
// alwaysOn, http20Enabled, appSettings) stay here.
resource app 'Microsoft.Web/sites@2023-12-01' = {
  name: appName
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: plan.id
    // Regional VNet integration: routes App Service outbound traffic through the VNet
    // so it can reach PostgreSQL via its private IP (no public firewall rule needed).
    virtualNetworkSubnetId: !empty(appSubnetId) ? appSubnetId : null
    siteConfig: {
      // linuxFxVersion is managed by the CD pipeline (SHA-tagged images).
      // Setting it here would cause drift. CD owns the container image config.
      acrUseManagedIdentityCreds: true
      alwaysOn: true
      http20Enabled: true
      // appSettings = sharedAppSettings (used by both prod + migrate) PLUS
      // prodOnlyAppSettings (#513 — App Insights connection string + OTEL_*).
      // Migrate slot intentionally excludes prodOnlyAppSettings to avoid the
      // #347 full-template reconcile failure on slot validators.
      appSettings: concat(sharedAppSettings, prodOnlyAppSettings)
    }
    httpsOnly: true
  }
}

// Child config/web — carries the siteConfig keys that the parent site API
// returns as null. See the comment on the parent `app` resource above.
resource appConfigWeb 'Microsoft.Web/sites/config@2023-12-01' = {
  parent: app
  name: 'web'
  properties: {
    cors: {
      allowedOrigins: corsOrigins
      supportCredentials: false
    }
    ftpsState: 'Disabled'
    healthCheckPath: '/health'
    localMySqlEnabled: false
    minTlsVersion: '1.2'
    // Azure default is 'v4.6' on fresh sites; live was provisioned at 'v4.0'
    // (harmless for a Docker/Linux app) and declaring it keeps what-if quiet.
    netFrameworkVersion: 'v4.0'
    // Route all outbound traffic (including DNS) through the VNet so the
    // private DNS zone resolves PostgreSQL's FQDN to its private IP.
    vnetRouteAllEnabled: !empty(appSubnetId)
  }
}

// -----------------------------------------------------------------------------
// `migrate` validation slot (#246 — re-lands #194)
// -----------------------------------------------------------------------------
// CD pushes each new image to this slot BEFORE touching prod. The slot cold-
// starts the same container image as prod will, which runs `alembic upgrade
// head` via `scripts/start.sh` before uvicorn binds port 8000. CD then polls
// the slot's /health endpoint; a 200 proves the migration ran and the app
// booted cleanly inside the VNet. If the slot never becomes healthy within
// the retry window, CD fails at that step and the prod container swap never
// runs — prod stays on the previous image.
//
// This is the fail-loud property #194 was after: a failing migration blocks
// the prod container swap. See `.github/workflows/cd.yml` `Deploy image to
// migrate slot` + `Wait for migrate slot to become healthy` steps.
//
// Why a slot and not a Container Apps job / self-hosted runner / Kudu REST:
// the slot uses existing infrastructure (S1 Standard supports up to 5 slots
// for free), is configured with the same VNet subnet/integration pattern as
// the parent app, uses its own system-assigned managed identity with the same
// required roles, and runs the exact same container image as prod — so the
// migration environment is identical to the prod runtime. #244 tried to run
// migrations from a public GH runner and failed because (a) the PostgreSQL
// `publicNetworkAccess: Disabled` (from #144) means the DB is only reachable
// from inside the VNet, and (b) the GitHub Actions SP has `Contributor` at
// RG scope but no Key Vault data-plane role, so direct secret reads from the
// runner fail with `AuthorizationFailed`. The slot pattern sidesteps both:
// the slot runs inside the VNet (so the DB is reachable) and resolves
// `@Microsoft.KeyVault(...)` refs via its own system-assigned managed
// identity (so no runner-side secret reads).
//
// Slot managed identity role assignments — managed out-of-band.
//
// Like the parent `app` resource, the slot's system-assigned managed identity
// needs two role assignments that are NOT declared here (see the comment
// block below the `app` resource for why — #238 blanket-omits all role
// assignments from the managed Bicep set to avoid the `az deployment group
// what-if` roleAssignments/write preflight gotcha):
//
//   1. `AcrPull` (`7f951dda-4ed3-4680-a7ca-43fe172d538d`) at the ACR scope,
//      so the slot can pull container images from `mspopsaiacr`.
//   2. `Key Vault Secrets User` (`4633458b-17de-408a-b874-0445c86b69e6`) at
//      the Key Vault scope, so the slot's `@Microsoft.KeyVault(...)` app
//      setting references resolve at runtime.
//
// After this template is deployed for the first time (which creates the
// slot + its managed identity), run the following commands once to grant
// both roles. The slot's `principalId` is only available after the slot
// resource exists.
//
//   SLOT_MI=$(az webapp identity show --name mspopsai-app \
//     --resource-group mspopsai-rg --slot migrate \
//     --query principalId -o tsv)
//
//   az role assignment create \
//     --role "AcrPull" \
//     --assignee-object-id "$SLOT_MI" \
//     --assignee-principal-type ServicePrincipal \
//     --scope $(az acr show --name mspopsaiacr --query id -o tsv)
//
//   az role assignment create \
//     --role "Key Vault Secrets User" \
//     --assignee-object-id "$SLOT_MI" \
//     --assignee-principal-type ServicePrincipal \
//     --scope $(az keyvault show --name mspopsai-kv2 --query id -o tsv)
//
// Same recovery procedure applies if an assignment is ever accidentally
// deleted from Azure.
// The slot's siteConfig stays INLINE (not split like the parent `app`) because
// the `Microsoft.Web/sites/slots` + `Microsoft.Web/sites/slots/config` resource
// pair triggers a different what-if comparison path than the site equivalent:
// splitting into a child config/web resource for the slot surfaces ~38 extra
// drift entries for Azure-default config/web properties that Bicep doesn't
// enumerate (defaultDocuments, loadBalancing, managedPipelineMode, etc.).
// Keeping siteConfig inline leaves the slot with residual drift from Azure
// runtime fields (inboundIpAddress, kind, hostNameSslStates, sku, etc.) and
// `linuxFxVersion` (CD-owned) — these are fundamentally unresolvable in Bicep
// and are documented as the slot's "baseline drift" in the PR body of #240's
// triage. See `docs/runbooks/deployment.md` § Bicep Drift Detection.
resource migrateSlot 'Microsoft.Web/sites/slots@2023-12-01' = {
  parent: app
  name: 'migrate'
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    clientAffinityEnabled: false
    // #347 fix — declare properties that Azure's App Service backend echoes on
    // the live slot but Bicep previously omitted. Without these, an incremental
    // Bicep deploy tries to null them on the slot, and Azure's slot validator
    // rejects the request with:
    //
    //   BadRequest (ExtendedCode 01019):
    //     "The data is not valid (Invalid values supplied for Azure Files
    //      related app settings.)"
    //
    // The trigger is `vnetContentShareEnabled` (formerly `WEBSITE_CONTENTOVERVNET`).
    // Per Microsoft's "Storage considerations for Azure Functions" docs, all apps
    // sharing an Azure Files storage account in a VNet-integrated plan must use
    // the same value; a mismatch routes Azure Files traffic through public
    // networks which the storage account's network rules block — hence the
    // validator rejects any write that would create such a mismatch. Both our
    // parent + slot live with `vnetContentShareEnabled: false`, so declaring it
    // explicitly on the slot preserves the live value during ARM's incremental
    // replace of `properties`. The related `vnet*Enabled` + `publicNetworkAccess`
    // + `keyVaultReferenceIdentity` settings are echoed the same way; declaring
    // them prevents similar phantom Deletes in `az deployment group what-if`
    // output for these slot-level echoed properties and keeps the rationale here
    // aligned with the fields this hunk actually declares.
    //
    // Parent `app` doesn't hit this error because its siteConfig is split into
    // the separate `appConfigWeb` child resource, and that split changes ARM's
    // incremental merging behaviour — echoed properties survive. Slots can't
    // use the same split (a slot `config/web` child adds ~38 OTHER drift
    // entries for Azure-default siteConfig keys), so we declare inline instead.
    keyVaultReferenceIdentity: 'SystemAssigned'
    publicNetworkAccess: 'Enabled'
    vnetBackupRestoreEnabled: false
    vnetContentShareEnabled: false
    vnetImagePullEnabled: false
    vnetRouteAllEnabled: !empty(appSubnetId)
    // Slots do NOT automatically inherit the parent's VNet integration on
    // S1 Standard — each slot needs its own `virtualNetworkSubnetId`. We
    // point the slot at the same `app-subnet` as the parent so it can
    // reach VNet-locked PostgreSQL + Redis + private-endpoint services.
    virtualNetworkSubnetId: !empty(appSubnetId) ? appSubnetId : null
    siteConfig: {
      // linuxFxVersion is managed by CD per-deploy via
      // `az webapp config container set --slot migrate`, same pattern as
      // the parent `app` resource. Setting it here would cause drift.
      acrUseManagedIdentityCreds: true
      // alwaysOn matches live (#240 triage). The original design intent was
      // `false` to reduce idle memory pressure, but the live slot has been
      // running with `alwaysOn=true` without the OOM pattern re-appearing
      // since the #218/#234 fixes. Keep Bicep tracking reality; if cold-slot
      // memory savings are wanted later, flip this back with a tracked
      // change-window deploy.
      alwaysOn: true
      ftpsState: 'Disabled'
      // #347 fix — siteConfig defaults that live carries but Bicep previously
      // omitted. ARM's incremental replace would null these on deploy; most
      // are harmless (the slot runs fine either way), but declaring them keeps
      // what-if quiet and matches the "declare what live has" pattern #304
      // established for the parent.
      functionAppScaleLimit: 0
      minimumElasticInstanceCount: 1
      numberOfWorkers: 1
      http20Enabled: true
      minTlsVersion: '1.2'
      // Route all outbound traffic through the VNet so the slot can
      // resolve the PostgreSQL + Key Vault + Redis private endpoints via
      // the VNet-linked private DNS zones (same rationale as the parent).
      vnetRouteAllEnabled: !empty(appSubnetId)
      healthCheckPath: '/health'
      // appSettings = production-shared settings PLUS slot-specific
      // overrides (UVICORN_WORKERS=1, LOG_LEVEL=INFO). See the
      // `sharedAppSettings` / `slotSpecificOverrides` variables above.
      // ARM resolves duplicates (LOG_LEVEL appears in both) using
      // last-wins semantics so the override wins.
      appSettings: concat(sharedAppSettings, slotSpecificOverrides)
      cors: {
        allowedOrigins: corsOrigins
        supportCredentials: false
      }
    }
  }
}

// Web App managed identity role assignments — managed out-of-band.
//
// The Web App's system-assigned managed identity holds two built-in role
// assignments that are NOT managed by this template:
//
//   1. `AcrPull` (`7f951dda-4ed3-4680-a7ca-43fe172d538d`) at the ACR scope
//      (`mspopsaiacr`), so the App Service can pull container images.
//   2. `Key Vault Secrets User` (`4633458b-17de-408a-b874-0445c86b69e6`) at
//      this deployment's Key Vault scope, so `@Microsoft.KeyVault(...)` app
//      setting references resolve at runtime.
//
// Both assignments were created by the original Phase 4A deployment running
// under the Claude Code SP (Owner). They persist in Azure across deploys.
//
// Why not declared here: the drift-check workflow runs under the GitHub
// Actions SP, which holds `Contributor` on `mspopsai-rg` — deliberately NOT
// `User Access Administrator`. `az deployment group what-if` runs a blanket
// pre-flight RBAC check on every managed resource in the template, and for
// `Microsoft.Authorization/roleAssignments` that pre-flight requires
// `/write` regardless of whether the assignment would actually change.
// Granting `roleAssignments/write` to the CI SP would let any workflow hand
// out privileged access at the RG/ACR/KV scopes — a privilege escalation
// we've explicitly rejected. Omitting the role assignments from the template
// entirely means what-if never preflights them. See #238.
//
// Recovery — if an assignment is ever accidentally deleted from Azure:
//
//   az role assignment create \
//     --role AcrPull \
//     --assignee-object-id <app-identity-principal-id> \
//     --assignee-principal-type ServicePrincipal \
//     --scope <acr-resource-id>
//
//   az role assignment create \
//     --role "Key Vault Secrets User" \
//     --assignee-object-id <app-identity-principal-id> \
//     --assignee-principal-type ServicePrincipal \
//     --scope <vault-resource-id>
//
// For fresh-environment bootstrap (staging, DR), grant the deploying SP
// `User Access Administrator` at RG scope temporarily and re-add these as
// managed declarations just for the bootstrap deploy.

// Diagnostic settings.
// Live has 9 log categories (4 enabled + 5 disabled) and each entry carries a
// `retentionPolicy: {days: 0, enabled: false}` that the ARM API echoes back
// whether or not the template declares it. Declaring all 9 categories and the
// retentionPolicy on every entry keeps what-if quiet (#240). The two
// AntivirusScan/File audit categories were added by Azure post-creation and
// surfaced in drift catch-up PR B.
resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = if (!empty(logAnalyticsWorkspaceId)) {
  name: '${appName}-diagnostics'
  scope: app
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        category: 'AppServiceHTTPLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServiceConsoleLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServiceAppLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServicePlatformLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServiceAuditLogs'
        enabled: false
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServiceIPSecAuditLogs'
        enabled: false
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServiceAuthenticationLogs'
        enabled: false
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServiceAntivirusScanAuditLogs'
        enabled: false
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AppServiceFileAuditLogs'
        enabled: false
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
    ]
  }
}

@description('Web App default hostname')
output defaultHostname string = app.properties.defaultHostName

@description('Web App resource ID')
output id string = app.id

@description('App Service Plan resource ID')
output planId string = plan.id

@description('Web App name')
output appName string = app.name

@description('Web App principal ID (managed identity)')
output principalId string = app.identity.principalId

@description('Migrate slot principal ID (managed identity) — needs AcrPull on ACR and Key Vault Secrets User on the KV, granted out-of-band (#246, #238). Run the `az role assignment create` commands documented above the `migrateSlot` resource after the first deploy.')
output migrateSlotPrincipalId string = migrateSlot.identity.principalId

@description('Migrate slot default hostname.')
output migrateSlotDefaultHostname string = migrateSlot.properties.defaultHostName
