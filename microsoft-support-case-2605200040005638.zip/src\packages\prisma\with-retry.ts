/**
 * Transient connection retry helpers for Prisma against Azure SQL.
 *
 * Background: Azure SQL aggressively closes idle TCP connections. Prisma's
 * pool reuses connections without validating them, so the first query on a
 * stale connection surfaces as one of:
 *   - P1001  Can't reach database server
 *   - P1011  Error opening a TLS connection
 *   - P1017  Server has closed the connection
 *
 * These ARE transient: a fresh pool slot opens a brand-new TCP+TLS to Azure
 * SQL and almost always succeeds. Retrying ~3 times absorbs them without the
 * client ever seeing a 503.
 *
 * P2024 (pool timeout) is intentionally NOT in this list, even though older
 * versions of this file included it. Retrying a pool timeout makes the
 * problem worse: the pool is already saturated, so a retry just queues
 * another request behind everything else that is also waiting. Under sustained
 * pressure that creates a feedback loop where every operation spends up to
 * `pool_timeout * maxAttempts` seconds blocked, holding the saturation in
 * place rather than releasing it. P2024 must surface fast so the route can
 * return 503 / Retry-After and the client can back off.
 */

const TRANSIENT_PRISMA_CODES = new Set(["P1001", "P1011", "P1017"]);

const TRANSIENT_MESSAGE_PATTERNS: RegExp[] = [
	/connection reset by peer/i,
	/error opening a tls connection/i,
	/can't reach database server/i,
	/server has closed the connection/i,
];

function getErrorCode(err: unknown): string | undefined {
	if (typeof err !== "object" || err === null) return undefined;
	const candidate = err as { code?: unknown; errorCode?: unknown };
	if (typeof candidate.code === "string") return candidate.code;
	if (typeof candidate.errorCode === "string") return candidate.errorCode;
	return undefined;
}

export function isTransientConnectionError(err: unknown): boolean {
	const code = getErrorCode(err);
	if (code && TRANSIENT_PRISMA_CODES.has(code)) return true;

	const message =
		err instanceof Error
			? err.message
			: typeof err === "string"
				? err
				: "";

	return TRANSIENT_MESSAGE_PATTERNS.some((rx) => rx.test(message));
}

export interface RetryOptions {
	maxAttempts?: number;
	baseDelayMs?: number;
	onRetry?: (info: { attempt: number; error: unknown; delayMs: number }) => void;
}

const DEFAULT_MAX_ATTEMPTS = 3;
const DEFAULT_BASE_DELAY_MS = 100;

function delay(ms: number): Promise<void> {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Run `op` and retry on transient Azure-SQL/Prisma connection errors.
 *
 * Non-transient errors (P2002 unique violations, validation errors, business
 * logic exceptions) are rethrown immediately on the first attempt.
 */
export async function withTransientConnectionRetry<T>(
	op: () => Promise<T>,
	options: RetryOptions = {},
): Promise<T> {
	const maxAttempts = options.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;
	const baseDelayMs = options.baseDelayMs ?? DEFAULT_BASE_DELAY_MS;

	let attempt = 0;
	let lastError: unknown;

	while (attempt < maxAttempts) {
		attempt += 1;
		try {
			return await op();
		} catch (err) {
			lastError = err;
			if (!isTransientConnectionError(err)) throw err;
			if (attempt >= maxAttempts) break;

			const delayMs = baseDelayMs * 2 ** (attempt - 1);
			options.onRetry?.({ attempt, error: err, delayMs });
			await delay(delayMs);
		}
	}

	throw lastError;
}
