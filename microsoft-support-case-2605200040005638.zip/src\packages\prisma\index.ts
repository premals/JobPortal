import { PrismaClient } from "@prisma/client";
import { startPrismaHeartbeat } from "./heartbeat";
import { transientRetryExtension } from "./retry-extension";

// Singleton across HMR reloads in dev so each recompile does not spawn a new
// PrismaClient + connection pool against Azure SQL. In production the module
// evaluates once per container, so this collapses to a single instance and
// `globalForPrisma.prisma` is never assigned.
//
// Pool sizing is controlled via `connection_limit`, `pool_timeout`, and
// `connect_timeout` query params on DATABASE_URL — not in code. Prisma's
// default `connection_limit` is `num_physical_cpus * 2 + 1`, which collapses
// to 3 on the 1-vCPU App Service plan.
//
// The base client is extended with `transientRetryExtension`, which retries
// model operations on Azure-SQL connection drops (P1001/P1011/P1017).
// P2024 (pool timeout) is deliberately NOT retried — retrying when the pool
// is exhausted amplifies saturation; see ./with-retry.ts for the rationale.
// $transaction / $queryRaw / $executeRaw are NOT covered by the extension —
// wrap those at the call site with `withTransientConnectionRetry`.
//
// We deliberately TYPE the singleton as `PrismaClient` (not the extended
// client type) so that callers retain the standard signatures. In particular,
// `$transaction(async (tx: Prisma.TransactionClient) => ...)` continues to
// type-check; with the extended type the callback parameter type changes to
// a wide `DynamicClientExtensionThis<...>` and breaks every existing call
// site. Runtime behaviour is the extended client's; the cast hides only the
// `$on` / `$use` removal, neither of which is used in this codebase.
function buildPrisma(): PrismaClient {
	const base = new PrismaClient({ log: ["error", "warn"] });
	return base.$extends(transientRetryExtension) as unknown as PrismaClient;
}

const globalForPrisma = globalThis as unknown as {
	prisma?: PrismaClient;
};

export const prisma: PrismaClient = globalForPrisma.prisma ?? buildPrisma();

if (process.env.NODE_ENV !== "production") {
	globalForPrisma.prisma = prisma;
}

// Keep pooled TCP flows to Azure SQL warm so the Azure App Service outbound
// load balancer (4-min default idle timeout, public endpoint) does not
// silently kill them while the container is idle overnight. See
// ./heartbeat.ts for the full rationale and safety properties. No-op
// under NODE_ENV=test; idempotent under dev HMR re-evaluation.
startPrismaHeartbeat(prisma);

// Re-export retry primitives so call sites can wrap $transaction / $queryRaw.
export {
	withTransientConnectionRetry,
	isTransientConnectionError,
} from "./with-retry";

// Export all types from types.ts
export * from "./types";
