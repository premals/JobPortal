import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * GET /api/health
 *
 * Lightweight LIVENESS probe — no DB, no external dependencies.
 * Returns 200 if the Node process is responsive enough to handle the
 * request. Use this for:
 *   - Azure App Service Health check (default config)
 *   - Docker HEALTHCHECK directive
 *   - Any LB upstream that should NOT restart/pull the instance just
 *     because the upstream database is temporarily unreachable
 *
 * If you want DB readiness coupled to LB rotation, point the probe to
 * GET /api/health/db instead — that endpoint runs SELECT 1 against the
 * Prisma pool with a 2s deadline and returns 503 on failure.
 *
 * The two-endpoint split is intentional: container restarts and DB
 * outages have different recovery profiles. Restarting a container with
 * a fine Node process because Azure SQL had a brownout makes the recovery
 * slower, not faster.
 */
export async function GET() {
	return NextResponse.json(
		{
			status: "ok",
			service: "mobile-api",
			timestamp: new Date().toISOString(),
		},
		{ status: 200 },
	);
}

/**
 * HEAD /api/health
 *
 * HEAD variant of the liveness probe for load balancers that prefer not
 * to consume a response body. Identical semantics to GET — no DB access.
 */
export async function HEAD() {
	return new NextResponse(null, { status: 200 });
}
