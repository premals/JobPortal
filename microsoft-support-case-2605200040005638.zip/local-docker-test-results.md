# Local Docker test — results

**Case:** 2605200040005638
**Test executed:** 2026-05-28
**Operator workstation:** Windows 11, Docker Desktop 28.0.1 (Linux containers)
**Workstation outbound public IP:** `12.230.2.238`
**Image:** `nuvemfleet-mobile-api:local` — built from `apps/mobile-api/Dockerfile` with BuildKit secrets, same Dockerfile that runs on `nuvemfleet-mobile-api-prod`
**Target Azure SQL:** `fleet-sql-prod.database.windows.net:1433`
**Connection params:** production `DATABASE_URL` from App Service (encrypt=true; trustServerCertificate=false)

## Summary

**No TLS handshake failures or transient connection errors reproduced from the local workstation against `fleet-sql-prod`.**

| Probe | Result |
|---|---|
| Container build (BuildKit, prod Dockerfile) | OK |
| Container start (server.js directly) | OK |
| `GET /api/health` (liveness, no DB) | 200 OK |
| `GET /api/health/db` × 5 (single-flight cache window covers some) | 5/5 = 200 OK, `db: ok` |
| First fresh probe `durationMs` | 456 ms (TLS handshake cold-start) |
| Subsequent probe `durationMs` | 0 – 80 ms (warm pool) |
| `POST /api/v1/auth/login` (deliberate bad creds) | 401 with `"No existe una cuenta..."` — proves DB lookup path executed and returned successfully |
| Prisma heartbeat start log | Present: `intervalMs=90000 initialDelayMs=30000 coldStartPings=1 steadyStatePings=15 staggerMs=60` |
| Prisma heartbeat `[PrismaHeartbeat] ping evicted stale conn` warnings | **0** during the test window |
| Any `P1001` / `P1011` / `P1017` / `P2024` errors | **0** |

## Timeline (UTC)

```
19:33:02  container started (first attempt via docker-start.sh — see notes)
19:33:53  container restarted with normalizing entrypoint + direct node start
19:35:25  container restarted bypassing docker-start.sh DB pre-check (which fails for an unrelated reason — see notes)
19:35:33  GET /api/health -> 200 (server ready)
19:35:47  probe sequence begin
19:35:48  /api/health/db #1 -> 200, durationMs=456 (cold TLS handshake)
19:35:50  /api/health/db #2 -> 200, durationMs=0 (cache window)
19:35:51  /api/health/db #3 -> 200, durationMs=43
19:35:52  /api/health/db #4 -> 200, durationMs=0 (cache window)
19:35:54  /api/health/db #5 -> 200, durationMs=42
19:35:55  POST /api/v1/auth/login -> 401 (DB lookup succeeded; account does not exist)
19:36:00  [PrismaHeartbeat] starting … (initial-delay timer armed)
19:36:30  heartbeat cold-start tick (1 ping) — no eviction warnings logged
19:36:41  final /api/health/db -> 200, durationMs=80
```

## Two findings from the local test (separate from the MS investigation)

1. **`docker-start.sh` line-endings:** the script in the local Windows checkout had CRLF line terminators, which caused `exec /app/docker-start.sh` to fail with `not found`. Resolved by overriding the entrypoint to `tr -d '\r' < /app/docker-start.sh > /tmp/start.sh && /tmp/start.sh`. This is a local workstation artifact (Windows git autocrlf), not a real bug — Linux CI checks the file out with LF.
2. **`docker-start.sh` DB pre-check uses `npx prisma`** which is not on the runtime image PATH, so the check always fails (silently — output is redirected to `/dev/null 2>&1`). Bypassed for this test by starting `node /app/apps/mobile-api/server.js` directly. The doc `docs/AZURE_APP_SERVICE_CONFIG.md` notes the migration code in `docker-start.sh` is legacy and is not executed in production; this confirms it.

Neither finding is related to the TLS handshake failures Microsoft is investigating.

## Interpretation for Microsoft

- TCP + TLS handshake from a non-Azure source (residential ISP, outbound IP `12.230.2.238`) to `fleet-sql-prod.database.windows.net:1433` completes successfully and is stable across repeated probes.
- The Prisma client + Rust `tiberius` driver inside the production Docker image successfully opens, uses, and reuses pool connections from this network path.
- The reported intermittent TLS handshake failures observed on `nuvemfleet-mobile-api-prod` therefore do not reproduce from outside Azure with the same image and configuration. This is consistent with the symptom shape being something specific to App Service Linux container egress (Azure outbound load balancer behavior, regional Azure SQL gateway routing, or App Service network stack), not to anything the application image itself does.

## Files captured for the case

- `probes-transcript.txt` — full HTTP request/response transcript of all probes
- `mobile-api-local.log` — container stdout/stderr (includes `[PrismaHeartbeat] starting …` line)
- This `local-docker-test-results.md`

No real secrets are in any of these files. The DATABASE_URL value was passed via `--env-file` only and never echoed to logs or saved to disk inside this folder.
