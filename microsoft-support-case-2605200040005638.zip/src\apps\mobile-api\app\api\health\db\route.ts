import { prisma } from "@rentals/prisma";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

// Per-probe deadline. 2s is enough headroom for a SELECT 1 against a warm
// pool socket and aggressive enough to fail fast when every socket is dead.
// The probe is single-flighted (see `pingPool`) so a burst of concurrent
// callers does NOT spawn parallel $queryRaw calls each hoarding a pool slot
// for up to socket_timeout=60s.
const HEALTH_PROBE_TIMEOUT_MS = 2000;

// Result cache window. Back-to-back probes within this window reuse the
// last result. Concurrent probes that arrive during an in-flight check
// latch onto the same promise (single-flight).
const PROBE_CACHE_WINDOW_MS = 1500;

type ProbeResult = { ok: boolean; reason?: string };

const probeState = globalThis as unknown as {
	__healthProbeInFlight?: Promise<ProbeResult>;
	__healthProbeLast?: { result: ProbeResult; at: number };
};

function freshProbe(): Promise<ProbeResult> {
	let timer: ReturnType<typeof setTimeout> | undefined;
	const timeout = new Promise<ProbeResult>((resolve) => {
		timer = setTimeout(
			() => resolve({ ok: false, reason: "probe_timeout" }),
			HEALTH_PROBE_TIMEOUT_MS,
		);
	});

	const query = prisma.$queryRaw`SELECT 1`.then<ProbeResult, ProbeResult>(
		() => ({ ok: true }),
		(err: unknown) => {
			const msg = err instanceof Error ? err.message : String(err);
			return { ok: false, reason: msg.slice(0, 200) };
		},
	);

	return Promise.race([query, timeout]).then((result) => {
		if (timer) clearTimeout(timer);
		probeState.__healthProbeLast = { result, at: Date.now() };
		probeState.__healthProbeInFlight = undefined;
		return result;
	});
}

async function pingPool(): Promise<ProbeResult> {
	// 1. Use a recent result if available — collapses tight bursts of
	//    probes (Docker every 30s + Azure every 60s + manual curls) into
	//    a single underlying query.
	const last = probeState.__healthProbeLast;
	if (last && Date.now() - last.at < PROBE_CACHE_WINDOW_MS) {
		return last.result;
	}

	// 2. If a probe is already in flight, latch onto it instead of
	//    launching a competing $queryRaw that would hold its own pool slot.
	const inFlight = probeState.__healthProbeInFlight;
	if (inFlight) return inFlight;

	// 3. Fresh probe; remember it so concurrent callers join.
	const p = freshProbe();
	probeState.__healthProbeInFlight = p;
	return p;
}

/**
 * GET /api/health/db
 *
 * READINESS probe — verifies the Prisma pool can satisfy a trivial DB
 * query within HEALTH_PROBE_TIMEOUT_MS. Returns:
 *   - 200 { status: "ok", db: "ok", durationMs }       — pool can reach DB
 *   - 503 { status: "degraded", db: "unreachable", reason } + Retry-After
 *
 * Use this endpoint (NOT /api/health) when you want Azure App Service's
 * load balancer to pull an instance out of rotation when its Prisma pool
 * is severed. Point the Health probe path in App Service Configuration
 * → Health check at `/api/health/db` to enable that behavior. The
 * default 10-minute "Load balancing threshold" means consecutive bad
 * probes will eventually mark the instance unhealthy.
 *
 * Note: Prisma's $queryRaw cannot be aborted mid-handshake — the timeout
 * here decides only what the caller observes; the underlying query keeps
 * a pool slot until socket_timeout (60s). The cache + single-flight above
 * is what prevents probe storms from starving the pool from the inside.
 */
export async function GET() {
	const startedAt = Date.now();
	const result = await pingPool();
	const durationMs = Date.now() - startedAt;

	if (result.ok) {
		return NextResponse.json(
			{
				status: "ok",
				service: "mobile-api",
				db: "ok",
				durationMs,
				timestamp: new Date().toISOString(),
			},
			{ status: 200 },
		);
	}

	return NextResponse.json(
		{
			status: "degraded",
			service: "mobile-api",
			db: "unreachable",
			reason: result.reason,
			durationMs,
			timestamp: new Date().toISOString(),
		},
		{
			status: 503,
			headers: { "Retry-After": "5" },
		},
	);
}
