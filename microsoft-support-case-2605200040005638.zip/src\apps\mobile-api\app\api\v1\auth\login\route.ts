import { rateLimiter } from "@rentals/middleware";
import { login } from "@rentals/services";
import { ApiError } from "@rentals/utils";
import { generateJWTToken } from "@rentals/utils/jwt";
import { type NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/auth/login
 * Mobile login endpoint - returns JWT token only (no session cookies)
 */
export async function POST(req: NextRequest) {
	const limited = await rateLimiter(req);
	if (limited) return limited;

	try {
		const body = await req.json().catch(() => ({}));
		const email: string | undefined = body?.email;
		const password: string | undefined = body?.password;

		if (!email || !password) {
			return NextResponse.json(
				{ success: false, message: "Email and password are required" },
				{ status: 400 },
			);
		}

		// Extract client IP for auditing
		const clientIP =
			req.headers.get("x-forwarded-for") ||
			req.headers.get("x-real-ip") ||
			"unknown";

		// Mobile API uses JWT — skip Lucia session creation (saves 3 DB calls).
		const result = await login(email, password, clientIP, false);

		// If requires password change
		if (result.requiresPasswordChange) {
			return NextResponse.json({
				success: true,
				requiresPasswordChange: true,
				resetToken: result.tempToken,
				message:
					result.message || "Debe cambiar su contraseña antes de continuar.",
			});
		}

		// If requires OTP
		if (result.requiresOTP) {
			return NextResponse.json({
				success: true,
				requiresOTP: true,
				tempToken: result.tempToken,
				message: result.message || "OTP enviado. Verifique para continuar.",
			});
		}

		// Successful login - Mobile API returns JWT token only
		if (!result.user) {
			return NextResponse.json(
				{ success: false, error: "Login failed - user not found" },
				{ status: 500 },
			);
		}

		// Generate JWT token for mobile client
		const token = generateJWTToken({
			userId: result.user.id,
			email: result.user.email,
			role: result.user.role,
			tenantId: result.user.tenantId,
		});

		// Return JSON response with JWT token (no cookies)
		return NextResponse.json({
			success: true,
			user: result.user,
			message: result.message || "Login successful",
			token,
		});
	} catch (error: unknown) {
		const status = error instanceof ApiError ? error.status : 500;
		const message =
			error instanceof Error ? error.message : "Internal server error";
		return NextResponse.json({ success: false, error: message }, { status });
	}
}

