#!/bin/sh
set -e

# Docker startup script for mobile-api app
# Handles database migrations, Prisma client generation, and server startup
# with proper error handling, retry logic, and structured logging

APP_NAME="mobile-api"
APP_PATH="apps/mobile-api"
LOG_PREFIX="[DOCKER-START]"

# Logging function with timestamp
log() {
    echo "${LOG_PREFIX} [$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $*" >&2
}

log_error() {
    echo "${LOG_PREFIX} [$(date -u +"%Y-%m-%dT%H:%M:%SZ")] [ERROR] $*" >&2
}

log_warn() {
    echo "${LOG_PREFIX} [$(date -u +"%Y-%m-%dT%H:%M:%SZ")] [WARN] $*" >&2
}

log_info() {
    echo "${LOG_PREFIX} [$(date -u +"%Y-%m-%dT%H:%M:%SZ")] [INFO] $*" >&2
}

# Check database connectivity with retry logic
check_database() {
    log_info "Checking database connectivity..."
    local max_attempts=5
    local attempt=1
    local delay=2

    while [ $attempt -le $max_attempts ]; do
        # Use Prisma migrate status as a connectivity check
        if npx prisma migrate status --schema=./packages/prisma/schema.prisma > /dev/null 2>&1; then
            log_info "Database connection successful"
            return 0
        fi

        if [ $attempt -lt $max_attempts ]; then
            log_warn "Database connection attempt $attempt/$max_attempts failed. Retrying in ${delay}s..."
            sleep $delay
            delay=$((delay * 2))
        fi
        attempt=$((attempt + 1))
    done

    log_error "Failed to connect to database after $max_attempts attempts"
    return 1
}

# Run database migrations with retry logic
run_migrations() {
    log_info "Running database migrations..."
    local max_attempts=3
    local attempt=1

    while [ $attempt -le $max_attempts ]; do
        if npx prisma migrate deploy --schema=./packages/prisma/schema.prisma; then
            log_info "Database migrations completed successfully"
            return 0
        fi

        if [ $attempt -lt $max_attempts ]; then
            log_warn "Migration attempt $attempt/$max_attempts failed. Retrying..."
            sleep 3
        fi
        attempt=$((attempt + 1))
    done

    log_error "Database migrations failed after $max_attempts attempts"
    return 1
}

# Generate Prisma client
generate_prisma_client() {
    log_info "Generating Prisma client..."
    if npx prisma generate --schema=./packages/prisma/schema.prisma; then
        log_info "Prisma client generated successfully"
        return 0
    else
        log_error "Failed to generate Prisma client"
        return 1
    fi
}

# Start the server with signal handling
start_server() {
    log_info "Starting ${APP_NAME} server..."
    
    # Trap SIGTERM and SIGINT for graceful shutdown
    trap 'log_info "Received shutdown signal, stopping server..."; kill -TERM $PID; wait $PID' TERM INT
    
    # Start the server in background and capture PID
    node "${APP_PATH}/server.js" &
    PID=$!
    
    # Wait for the server process
    wait $PID
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        log_info "Server stopped gracefully"
    else
        log_error "Server exited with code $exit_code"
    fi
    
    return $exit_code
}

# Validate environment variables for security
validate_environment() {
    log_info "Validating environment variables..."
    local is_production="${NODE_ENV:-production}"
    
    if [ "$is_production" = "production" ]; then
        # Check ALLOWED_ORIGINS is set
        if [ -z "$ALLOWED_ORIGINS" ] || [ "$ALLOWED_ORIGINS" = "" ]; then
            log_error "ALLOWED_ORIGINS environment variable is required in production."
            log_error "Set it to a comma-separated list of allowed origins (e.g., 'https://mobile-api.aimrentalspr.com')."
            return 1
        fi
        
        # Check ALLOWED_ORIGINS doesn't contain wildcard
        if echo "$ALLOWED_ORIGINS" | grep -q '\*'; then
            log_error "ALLOWED_ORIGINS cannot contain wildcard '*' in production."
            log_error "Specify explicit origins (e.g., 'https://mobile-api.aimrentalspr.com')."
            return 1
        fi
        
        # Validate all origins are HTTPS (POSIX sh compatible)
        old_ifs=$IFS
        IFS=','
        for origin in $ALLOWED_ORIGINS; do
            origin=$(echo "$origin" | xargs) # Trim whitespace
            if [ -z "$origin" ]; then
                continue
            fi
            
            if ! echo "$origin" | grep -qE '^https://'; then
                log_error "Invalid origin '$origin': All origins must use HTTPS in production."
                return 1
            fi
            
            # Basic URL validation
            if ! echo "$origin" | grep -qE '^https://[a-zA-Z0-9.-]+'; then
                log_error "Invalid origin URL format: '$origin'"
                return 1
            fi
        done
        IFS=$old_ifs
        
        log_info "Environment validation passed. Allowed origins: $ALLOWED_ORIGINS"
    else
        if [ -z "$ALLOWED_ORIGINS" ] || [ "$ALLOWED_ORIGINS" = "*" ]; then
            log_warn "ALLOWED_ORIGINS is set to wildcard or not set. This is acceptable in development but must be restricted in production."
        else
            log_info "Environment validation passed. Allowed origins: $ALLOWED_ORIGINS"
        fi
    fi
    
    return 0
}

# Main execution
main() {
    log_info "Starting ${APP_NAME} app initialization..."
    log_info "Environment: ${NODE_ENV:-production}"
    log_info "Port: ${PORT:-3002}"
    
    # Validate environment variables
    if ! validate_environment; then
        log_error "Environment validation failed. Exiting."
        exit 1
    fi
    
    # Check database connectivity
    if ! check_database; then
        log_error "Database connectivity check failed. Exiting."
        exit 1
    fi
    
    # Run migrations
    if ! run_migrations; then
        log_error "Migration failed. Exiting."
        exit 1
    fi
    
    # Generate Prisma client
    if ! generate_prisma_client; then
        log_error "Prisma client generation failed. Exiting."
        exit 1
    fi
    
    # Start the server
    log_info "Initialization complete. Starting server..."
    start_server
}

# Execute main function
main "$@"

