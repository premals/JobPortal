# Network trace runbook — `nuvemfleet-mobile-api-prod`

Authoritative step-by-step. Follow top-to-bottom. Do not skip the safety
notes.

> **Scope of this runbook.** Claude / the AI assistant does NOT have access
> to the production Azure App Service shell and CANNOT run this trace.
> A human operator with appropriate Azure RBAC (Website Contributor on the
> mobile-api App Service) must execute every command below.

Target App Service: `nuvemfleet-mobile-api-prod`
Target Azure SQL:   `fleet-sql-prod.database.windows.net` (TCP 1433)
Microsoft Case:     2605200040005638
Reference docs:     <https://azureossd.github.io/2023/12/05/Collecting-a-Network-Trace-on-Linux-Web-Apps/index.html>

---

## Step 0 — Pre-flight

1. Confirm with the on-call engineer that a brief debug session on
   `nuvemfleet-mobile-api-prod` is acceptable (no traffic redirect needed —
   `tcpdump` does not interrupt the running container).
2. Have a way to reproduce the mobile login failure ready BEFORE you start
   the capture. Options:
   - A real phone with the NuvemFleet mobile app pointed at production.
   - A `curl` you can run from your workstation against the public
     mobile-api URL with a known test account.
3. Open two browser tabs:
   - **Tab A** — Kudu SSH: `https://nuvemfleet-mobile-api-prod.scm.azurewebsites.net/webssh/host`
   - **Tab B** — Kudu File Manager: `https://nuvemfleet-mobile-api-prod.scm.azurewebsites.net/newui/fileManager`
4. Have a notepad (or `network-trace-log.txt` in this folder) ready for
   timestamps. **All times in UTC.**

---

## Step 1 — Enter the App Service container

In Tab A (Kudu SSH), you should land in `/home/site/wwwroot` of the running
container. Sanity check:

```bash
whoami
hostname
ip -o -4 addr show
date -u +%Y-%m-%dT%H:%M:%SZ
```

Record the hostname (instance ID) — if the App Service is scaled out, you
will need to repeat the trace on each instance.

---

## Step 2 — Install tcpdump

Detect base image:

```bash
cat /etc/os-release | head -3
```

- **Alpine** (our prod runtime — `node:20.18.0-alpine`):
  ```bash
  apk update && apk add --no-cache tcpdump
  ```
- **Debian** (only if a future image change moves us off Alpine):
  ```bash
  apt-get update && apt-get install -y tcpdump
  ```

Verify:

```bash
tcpdump --version
tcpdump -D
```

Expected interface: `eth0` (most blessed images). Use `any` if `eth0` is
not present or if multiple interfaces are listed.

---

## Step 3 — Start the capture

Set a UTC-stamped filename and write to `/home/`, which is the persistent
shared volume (files there survive restarts and are downloadable via Kudu).

```bash
TRACE_PATH=/home/trace-mobileapi-$(date -u +%Y%m%dT%H%M%SZ).pcap
echo "TRACE_PATH=$TRACE_PATH"

# Capture all TCP traffic to/from Azure SQL on port 1433. -s 0 captures
# full packets (we need the TLS handshake bytes). -w writes to disk.
# We do NOT use -X / -A — packet payloads are encrypted anyway.
tcpdump -i any -s 0 -w "$TRACE_PATH" \
  'host fleet-sql-prod.database.windows.net and port 1433'
```

The terminal will block, showing nothing (no `-v`). That is correct.

**Write down the UTC start timestamp** in your notes:

```
START (UTC): YYYY-MM-DDTHH:MM:SSZ
```

---

## Step 4 — Reproduce the mobile login failure

While the capture is running:

1. From the real device (or your workstation), trigger the mobile login
   that has been failing. Repeat a few times so the trace contains multiple
   handshake attempts.
2. If using `curl` from your workstation:

   ```bash
   curl -i -X POST https://mobile-api.aimrentalspr.com/api/v1/auth/login \
     -H 'Content-Type: application/json' \
     -d '{"email":"<test-account-email>","password":"<test-account-password>"}'
   ```

   Do not paste real production users into the ticket. Use a dedicated test
   account.
3. Also hit the DB readiness probe to force a fresh `SELECT 1`:

   ```bash
   curl -i https://mobile-api.aimrentalspr.com/api/health/db
   ```
4. Note every UTC timestamp of every failure (and at least one success
   timestamp for contrast):

   ```
   ATTEMPT 1 (UTC): YYYY-MM-DDTHH:MM:SSZ  -> result: 200 | 503 | timeout
   ATTEMPT 2 (UTC): YYYY-MM-DDTHH:MM:SSZ  -> ...
   ```

Keep the capture running for ~5 minutes minimum, even after a failure, so
that any retry / heartbeat behaviour is in the trace.

---

## Step 5 — Stop the capture

Back in Tab A, press `Ctrl+C` in the `tcpdump` terminal.

**Write down the UTC stop timestamp**:

```
STOP (UTC): YYYY-MM-DDTHH:MM:SSZ
```

Verify the file exists and is non-empty:

```bash
ls -lh "$TRACE_PATH"
tcpdump -r "$TRACE_PATH" -c 5
```

You should see a non-zero file size and the first 5 packets summarized
without errors.

---

## Step 6 — Download the trace

In **Tab B** (Kudu File Manager: `https://nuvemfleet-mobile-api-prod.scm.azurewebsites.net/newui/fileManager`):

1. Navigate to `/home/`.
2. Locate the file matching `trace-mobileapi-*.pcap`.
3. Click the download icon. Save to your local workstation —
   **NOT** into this `not-commit/microsoft-support-case-2605200040005638/`
   folder. We do not want the pcap inside the ZIP.

Confirm the local file size matches what `ls -lh` showed.

---

## Step 7 — Upload to Microsoft

1. Open the Azure Support case 2605200040005638.
2. Attach the downloaded `.pcap` directly to the case (Microsoft accepts up
   to 50 MB per file — split with `editcap -c <n> in.pcap split-` if larger).
3. In the case comment, paste:
   - The Kudu SSH hostname (instance ID) from Step 1.
   - The START / STOP UTC timestamps.
   - The UTC timestamps of each reproduction attempt and their outcome.
   - The capture filter used (`host fleet-sql-prod.database.windows.net and port 1433`).

---

## Step 8 — Clean up the container

```bash
rm -f /home/trace-mobileapi-*.pcap
# Confirm gone:
ls -lh /home/ | grep -i trace || echo "no trace files remain"
```

`tcpdump` itself can be left installed — `apk` packages do not persist
across App Service container restarts (only `/home` does), so it'll be
gone on the next cold start automatically.

---

## Safety notes

- The filter `host fleet-sql-prod... and port 1433` excludes user HTTP
  traffic, JWT tokens, and login bodies. Open the file in Wireshark before
  attaching, sanity-check Protocol Hierarchy shows only TCP/TLS to
  `fleet-sql-prod`.
- TLS payload is encrypted; the trace exposes Server Name Indication (SNI),
  cipher suites, certificate chains, and TCP timing — exactly what Microsoft
  needs and nothing more.
- Do NOT enable SSLKEYLOGFILE / TLS keylogging — that would decrypt query
  contents and leak PII / credentials.
- Do NOT capture from inside `/home/site/wwwroot` (that path is the app
  itself; some Kudu hosts limit writable areas there). `/home/` is the
  correct persistent location.
- If the App Service is running multiple instances, the trace only covers
  the instance you're SSH'd into. Use Azure Portal → App Service → Advanced
  Tools → Process Explorer to confirm which instance you're on, and repeat
  if needed.
- Never paste real production user credentials, tenant IDs, or DB usernames
  into the support ticket comment. Use a dedicated `support-test@` account.
