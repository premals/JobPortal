# Microsoft Support — Case 2605200040005638

NuvemFleet Mobile API — Azure SQL TLS handshake failures

App Service: `nuvemfleet-mobile-api-prod` (Linux container, Node.js / Next.js)
Azure SQL: `fleet-sql-prod.database.windows.net:1433`

## What Microsoft asked for

1. Dockerfile — `Dockerfile` (root of this folder) and `src/apps/mobile-api/Dockerfile`
2. mobile-api `package.json` — `mobile-api-package.json`
3. Root monorepo `package.json` — `root-package.json`
4. Relevant DB connection / pool / heartbeat / health code — under `src/`
5. Network trace from the Linux Web App — see `network-trace-instructions.md` and `network-trace-runbook.md`
6. Local Docker test against `fleet-sql-prod.database.windows.net:1433` — see `local-docker-test-instructions.md`

## How this app talks to Azure SQL — summary for MS

- Driver: Prisma (`@prisma/client` 5.7.x) with the `sqlserver` provider, which uses the Rust `tiberius` driver under the hood.
- All connection parameters (`encrypt=true`, `trustServerCertificate=false`, `connection_limit=15`, `pool_timeout=20`, `connect_timeout=30`, `socket_timeout=60`) are passed via the `DATABASE_URL` App Service Application Setting. We do not override TLS or socket settings in code.
- A per-process heartbeat (`src/packages/prisma/heartbeat.ts`) issues a staggered `SELECT 1` burst every 90 s on every pooled socket to keep TCP flows alive under the App Service outbound load-balancer idle window.
- A transient-retry Prisma extension (`src/packages/prisma/retry-extension.ts` + `with-retry.ts`) re-runs model operations on `P1001` / `P1011` / `P1017` (the codes we see during the TLS handshake / reset cascades).
- Health endpoints split liveness vs readiness:
  - `GET/HEAD /api/health` — no DB; used by Docker HEALTHCHECK + Azure liveness.
  - `GET /api/health/db` — `SELECT 1` with 2 s deadline, single-flighted; used to detect a severed pool.

## Files in this package

See `file-manifest.md`.

## Redaction status

- No real connection strings, JWT secrets, SMTP credentials, OAuth keys, Azure keys, storage keys, or passwords are included.
- `redacted-env-example.txt` shows variable names and placeholder values only.
- Source files reference env variables by name (`process.env.DATABASE_URL`, etc.) — no hardcoded secrets.
- The DB hostname `fleet-sql-prod.database.windows.net` IS included because Microsoft already has it and it is required for the local Docker reproduction.

## Do NOT include in the ZIP

- Real `.env` / `.env.production` files
- Any file containing a real `DATABASE_URL` value
- Network trace `.pcap` files captured against production (upload those directly to the case attachments, not via this package)
