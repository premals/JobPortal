# File manifest — Case 2605200040005638

| Path in ZIP | Purpose | Contains secrets? |
|---|---|---|
| `README.md` | Overview + how this app talks to Azure SQL | No |
| `Dockerfile` | mobile-api Dockerfile (top-level copy for convenience) | No |
| `mobile-api-package.json` | `apps/mobile-api/package.json` | No |
| `root-package.json` | Monorepo root `package.json` | No |
| `redacted-env-example.txt` | All env variable names with placeholder values | No (placeholders only) |
| `local-docker-test-instructions.md` | Build + run the prod image locally against `fleet-sql-prod` | No |
| `network-trace-instructions.md` | Short checklist version of the network-trace procedure | No |
| `network-trace-runbook.md` | Detailed step-by-step runbook for the network trace | No |
| `local-docker-test-results.md` | Results of the local Docker test (executed 2026-05-28) | No |
| `probes-transcript.txt` | Full HTTP request/response transcript of all probes | No |
| `mobile-api-local.log` | Container stdout/stderr from the local Docker test | No |
| `src/apps/mobile-api/Dockerfile` | Same Dockerfile under source tree | No |
| `src/apps/mobile-api/package.json` | mobile-api workspace package | No |
| `src/apps/mobile-api/scripts/docker-start.sh` | Container entrypoint — env validation, server start | No |
| `src/apps/mobile-api/app/api/health/route.ts` | `GET/HEAD /api/health` (liveness, no DB) | No |
| `src/apps/mobile-api/app/api/health/db/route.ts` | `GET /api/health/db` (readiness, single-flighted SELECT 1) | No |
| `src/apps/mobile-api/app/api/v1/auth/login/route.ts` | Mobile login route — minimal, mostly delegates to services | No |
| `src/packages/prisma/index.ts` | Prisma client singleton (HMR-safe), starts heartbeat | No |
| `src/packages/prisma/heartbeat.ts` | Per-process TCP heartbeat (`SELECT 1` every 90s) — pool keep-alive | No |
| `src/packages/prisma/retry-extension.ts` | Prisma `$extends` retry shim | No |
| `src/packages/prisma/with-retry.ts` | Transient retry for P1001/P1011/P1017 | No |
| `src/packages/prisma/package.json` | Prisma workspace package | No |

## Out of scope (not included)

- Real `.env` files — never copied.
- Application Insights / Log Analytics queries — can be shared on request.
- Production `.pcap` files — captured separately per `network-trace-runbook.md`, uploaded directly to the Azure Support case attachments.
- GitHub Actions workflow files — available on request; build-time only, do not affect runtime DB connectivity.
