import { Prisma } from "@prisma/client";
import { withTransientConnectionRetry } from "./with-retry";

/**
 * Prisma client extension that retries every model operation on transient
 * Azure-SQL/Prisma connection failures. Applied via `prisma.$extends(...)`.
 *
 * Scope: covers all generated model operations (`findUnique`, `findMany`,
 * `count`, `create`, `update`, `delete`, ...). It does NOT intercept
 * `$transaction`, `$queryRaw`, or `$executeRaw` — wrap those at the call
 * site with `withTransientConnectionRetry` directly.
 *
 * Built with `Prisma.defineExtension` so the shape is type-checked against
 * Prisma's expected extension signature. Tests in retry-extension.test.ts
 * exercise the inner `query.$allOperations` behaviour directly via the
 * exported `applyTransientRetry` helper.
 */
export function applyTransientRetry<TArgs, TResult>({
	args,
	query,
}: {
	args: TArgs;
	query: (args: TArgs) => Promise<TResult>;
	model?: string;
	operation?: string;
}): Promise<TResult> {
	return withTransientConnectionRetry(() => query(args));
}

export const transientRetryExtension = Prisma.defineExtension({
	name: "transientRetryExtension",
	query: {
		$allOperations({ args, query }) {
			return withTransientConnectionRetry(() => query(args));
		},
	},
});
