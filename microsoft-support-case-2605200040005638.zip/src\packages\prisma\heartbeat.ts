import type { PrismaClient } from "@prisma/client";

/**
 * Per-process TCP heartbeat for the Azure SQL connection pool.
 *
 * Why this exists
 * ----------------
 * Azure App Service Linux containers reach Azure SQL Database over the
 * public endpoint via Azure's outbound load balancer. That load balancer
 * silently drops any TCP flow that has been idle for the configured
 * outbound timeout (default 4 minutes; raisable to 30 in App Service
 * plan networking settings).
 *
 * Prisma's SQL Server provider keeps connections in its pool indefinitely
 * once opened — there is no `idle_timeout` / `max_lifetime` query param
 * for SQL Server (the four URL knobs available are `connection_limit`,
 * `pool_timeout`, `connect_timeout`, `socket_timeout`). The underlying
 * tiberius Rust driver does not enable SO_KEEPALIVE on its sockets, so
 * the OS kernel does not detect the silent severance either.
 *
 * Result: a container that has been idle overnight wakes up with N
 * "open" sockets that the LB has actually torn down. The first wave of
 * morning requests hits these dead sockets and sees
 *   - P1011  Error opening a TLS connection (Connection reset by peer)
 *   - P1017  Server has closed the connection
 *   - P2024  Pool timeout (as 15 simultaneous reopen attempts queue)
 * Adding a second App Service instance "fixes" it only because the new
 * instance starts with a freshly opened pool.
 *
 * The fix
 * --------
 * Fire a small `SELECT 1` burst every 3 minutes (under the 4-minute LB
 * default) so every pooled socket carries traffic well within the idle
 * window. Cost is trivial — a few microseconds of DTU per ping, ~5
 * queries/min per instance. The retry extension already wired into the
 * singleton handles any ping that lands on a connection already going
 * stale, so eviction happens during the heartbeat rather than during a
 * real user request.
 *
 * Safety
 * -------
 *   - Idempotent: re-calling `startPrismaHeartbeat` does nothing if the
 *     interval is already running (matters for dev HMR).
 *   - `setInterval(...).unref()` so the timer never blocks process exit.
 *   - Skipped under `NODE_ENV=test` so vitest doesn't leak handles.
 *   - Individual ping failures are swallowed and logged at debug — they
 *     are EXPECTED on stale connections; the failure is the eviction.
 */

// Ping cadence. The Azure App Service outbound LB idle default is 240s
// (4 min). We fire every 90s for a ~150s safety margin against event-loop
// stalls (heavy GC, big sync JSON serialization in report exports, etc.):
// even a 90s stall doesn't push any socket past the LB threshold.
const HEARTBEAT_INTERVAL_MS = 90 * 1000;

// Initial tick delay after process start, so we don't race app boot.
const HEARTBEAT_INITIAL_DELAY_MS = 30 * 1000;

// Pings per STEADY-STATE tick. Must match `connection_limit` so EVERY
// pooled socket is exercised within the LB idle window — Prisma's pool
// is LIFO, so a value smaller than the pool leaves the cold-end sockets
// unwarmed overnight and they die at the 4-minute LB threshold. A
// previous version of this file dropped this to 5 with the rationale
// that organic traffic warms the top of the LIFO stack; that holds
// during business hours but is exactly wrong overnight (no organic
// traffic = no LIFO rotation = bottom 10 of 15 sockets sit idle for
// hours and die). The morning P1011 cascade returned once that change
// shipped.
//
// IMPORTANT: this value assumes `connection_limit=15` is set in the
// DATABASE_URL query param on every App Service (see
// docs/AZURE_APP_SERVICE_CONFIG.md). If DATABASE_URL omits connection_limit,
// Prisma falls back to `num_physical_cpus * 2 + 1` (= 3 on 1-vCPU plans),
// and 15 pings will queue against that smaller pool, eventually surfacing
// as P2024 from inside the heartbeat. Always verify the App Service
// Application Setting includes `connection_limit=15`.
const HEARTBEAT_PARALLEL_PINGS = 15;

// Pings on the COLD-START tick (the very first tick after process boot).
// The pool is empty at boot — every ping has to open a fresh TCP+TLS
// to Azure SQL. Firing all 15 at once into a cold path produces a
// ~20s storm where every redial can fail with "Connection reset by
// peer" if the Azure SQL gateway/path is unhappy (production failure
// mode we kept hitting). Starting with a single ping lets the pool
// establish one good socket, then subsequent ticks ramp to the full
// 15 with sockets already in steady state.
//
// Trade-off: with 1 ping on the first tick, only 1 of 15 pool slots
// is warmed during the first 90s window. Organic traffic during that
// window may need to redial more than once. This is acceptable —
// the alternative (15 simultaneous redials at boot) is what was
// causing the cascade.
const HEARTBEAT_COLD_START_PINGS = 1;

// Stagger between successive pings inside a single tick. The reason 5 was
// chosen previously was a real concern — bursting 15 simultaneous TLS
// re-handshakes against a CPU-constrained 1-vCPU container could trip
// Azure SQL's pre-login timeout on a bad tick. Spacing the pings 60 ms
// apart prevents the simultaneous pre-login burst. On a healthy morning
// the full tick wraps in ~850 ms (14 × 60 ms stagger + ~10 ms queries);
// on a cold morning where every socket is dead and Prisma has to redial,
// the tick can run ~1–1.5 s as each redial completes. Either way the
// inter-tick gap (90 s) leaves enormous headroom.
const HEARTBEAT_PING_STAGGER_MS = 60;

// Timer handles + ramp-up state are pinned to globalThis so dev HMR
// re-evaluation of this module does NOT spawn parallel intervals.
// Mirrors the singleton pattern at index.ts: a fresh module instance
// reads the same handle and the guard at the start of
// `startPrismaHeartbeat` correctly no-ops.
const globalForHeartbeat = globalThis as unknown as {
	__prismaHeartbeatTimer?: ReturnType<typeof setInterval> | null;
	__prismaHeartbeatInitialTimer?: ReturnType<typeof setTimeout> | null;
	__prismaHeartbeatTickCount?: number;
};

type HeartbeatClient = Pick<PrismaClient, "$queryRaw">;

function fireOnePing(client: HeartbeatClient): Promise<void> {
	return client.$queryRaw`SELECT 1`.then(
		() => undefined,
		(err: unknown) => {
			// Expected behaviour when a stale socket is encountered — the
			// failure IS the eviction. The retry extension on the client
			// surfaces healed paths to user requests; logging at WARN here
			// (not debug) so that any morning that DOES misbehave leaves
			// a visible trail in Azure Log Stream. Healthy days log zero
			// of these; a bad tick logs at most HEARTBEAT_PARALLEL_PINGS.
			const msg = err instanceof Error ? err.message : String(err);
			if (process.env.NODE_ENV !== "test") {
				console.warn("[PrismaHeartbeat] ping evicted stale conn:", msg);
			}
			return undefined;
		},
	);
}

function sleep(ms: number): Promise<void> {
	return new Promise((resolve) => {
		// .unref() so an in-flight tick doesn't pin the process during a
		// graceful shutdown — worst case we lose the tail of one staggered
		// tick, which is the desired behaviour.
		const t = setTimeout(resolve, ms);
		t.unref?.();
	});
}

async function runHeartbeatTick(
	client: HeartbeatClient,
	pingsThisTick: number = HEARTBEAT_PARALLEL_PINGS,
): Promise<void> {
	// Stagger the pings across the tick instead of firing all N at once.
	// Each ping is launched HEARTBEAT_PING_STAGGER_MS after the previous
	// one (not awaited), so the pre-login handshakes never collide on a
	// 1-vCPU container even after a cold morning where every pooled
	// socket has been silently severed by the App Service outbound LB.
	const pings: Promise<void>[] = [];
	for (let i = 0; i < pingsThisTick; i++) {
		pings.push(fireOnePing(client));
		if (i < pingsThisTick - 1) {
			await sleep(HEARTBEAT_PING_STAGGER_MS);
		}
	}
	await Promise.all(pings);
}

/**
 * Start the per-process heartbeat. Safe to call more than once — only the
 * first call creates the interval. Tests should not call this directly;
 * the singleton wires it under a NODE_ENV / VITEST guard.
 */
export function startPrismaHeartbeat(client: HeartbeatClient): void {
	if (globalForHeartbeat.__prismaHeartbeatTimer) return;
	// Skip under any test runner. NODE_ENV=test catches vitest's default;
	// VITEST=true is set by vitest itself and survives test configs that
	// override NODE_ENV (e.g., integration test suites that use a custom
	// env name).
	if (process.env.NODE_ENV === "test" || process.env.VITEST) return;
	if (typeof setInterval !== "function") return; // edge runtime guard

	// Positive boot log — previously we had ZERO observability that the
	// heartbeat was even running. Operations had no way to distinguish
	// "heartbeat firing, all pings succeeding" from "heartbeat never
	// started". This single startup line solves that ambiguity.
	console.log(
		`[PrismaHeartbeat] starting intervalMs=${HEARTBEAT_INTERVAL_MS} initialDelayMs=${HEARTBEAT_INITIAL_DELAY_MS} coldStartPings=${HEARTBEAT_COLD_START_PINGS} steadyStatePings=${HEARTBEAT_PARALLEL_PINGS} staggerMs=${HEARTBEAT_PING_STAGGER_MS}`,
	);

	// Per-process tick counter governs the cold-start ramp. Tick 0 (the
	// initial-delay-driven tick) fires only HEARTBEAT_COLD_START_PINGS.
	// All subsequent ticks fire HEARTBEAT_PARALLEL_PINGS.
	globalForHeartbeat.__prismaHeartbeatTickCount = 0;

	const tick = () => {
		const tickIndex = globalForHeartbeat.__prismaHeartbeatTickCount ?? 0;
		const pingsThisTick =
			tickIndex === 0
				? HEARTBEAT_COLD_START_PINGS
				: HEARTBEAT_PARALLEL_PINGS;
		globalForHeartbeat.__prismaHeartbeatTickCount = tickIndex + 1;

		void runHeartbeatTick(client, pingsThisTick).catch((err) => {
			// Never escape — the heartbeat must not crash the process.
			const msg = err instanceof Error ? err.message : String(err);
			console.warn("[PrismaHeartbeat] tick error:", msg);
		});
	};

	const interval = setInterval(tick, HEARTBEAT_INTERVAL_MS);
	interval.unref?.();
	globalForHeartbeat.__prismaHeartbeatTimer = interval;

	const initial = setTimeout(tick, HEARTBEAT_INITIAL_DELAY_MS);
	initial.unref?.();
	globalForHeartbeat.__prismaHeartbeatInitialTimer = initial;
}

/** Test-only: stop the heartbeat so vitest can exit cleanly. */
export function __stopPrismaHeartbeatForTests(): void {
	if (globalForHeartbeat.__prismaHeartbeatTimer) {
		clearInterval(globalForHeartbeat.__prismaHeartbeatTimer);
		globalForHeartbeat.__prismaHeartbeatTimer = null;
	}
	if (globalForHeartbeat.__prismaHeartbeatInitialTimer) {
		clearTimeout(globalForHeartbeat.__prismaHeartbeatInitialTimer);
		globalForHeartbeat.__prismaHeartbeatInitialTimer = null;
	}
	globalForHeartbeat.__prismaHeartbeatTickCount = undefined;
}

/** Test-only: drive one tick deterministically. */
export async function __runHeartbeatTickForTests(
	client: HeartbeatClient,
	pingsThisTick?: number,
): Promise<void> {
	await runHeartbeatTick(client, pingsThisTick);
}

/** Test-only: number of parallel pings per steady-state tick (for assertion). */
export const __HEARTBEAT_PARALLEL_PINGS_FOR_TESTS = HEARTBEAT_PARALLEL_PINGS;

/** Test-only: number of pings on the cold-start tick (for assertion). */
export const __HEARTBEAT_COLD_START_PINGS_FOR_TESTS = HEARTBEAT_COLD_START_PINGS;

/** Test-only: tick interval (so test code doesn't hard-code the number). */
export const __HEARTBEAT_INTERVAL_MS_FOR_TESTS = HEARTBEAT_INTERVAL_MS;

/** Test-only: initial delay before first tick. */
export const __HEARTBEAT_INITIAL_DELAY_MS_FOR_TESTS = HEARTBEAT_INITIAL_DELAY_MS;
