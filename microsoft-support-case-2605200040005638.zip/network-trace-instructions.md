# Network trace — short checklist

Source: <https://azureossd.github.io/2023/12/05/Collecting-a-Network-Trace-on-Linux-Web-Apps/index.html>

Detailed step-by-step is in `network-trace-runbook.md`. Use this page only as
a quick reference once you're already familiar with the runbook.

## Checklist

- [ ] Open Kudu SSH on `nuvemfleet-mobile-api-prod` (`https://nuvemfleet-mobile-api-prod.scm.azurewebsites.net/webssh/host`).
- [ ] Install `tcpdump` in the container (`apk add tcpdump` on Alpine, `apt install tcpdump` on Debian).
- [ ] Confirm interface with `tcpdump -D` (expect `eth0`).
- [ ] Record UTC start timestamp.
- [ ] Start capture:
      `tcpdump -i any -s 0 -w /home/trace-$(date -u +%Y%m%dT%H%M%SZ).pcap host fleet-sql-prod.database.windows.net and port 1433`
- [ ] Reproduce the mobile login from a real device or `curl` against the public mobile-api URL.
- [ ] Record UTC stop timestamp.
- [ ] Stop capture with `Ctrl+C`.
- [ ] Verify file exists under `/home/` and is non-empty (`ls -lh /home/trace-*.pcap`).
- [ ] Download via Kudu File Manager: `https://nuvemfleet-mobile-api-prod.scm.azurewebsites.net/newui/fileManager` → `/home/` → download.
- [ ] Upload the `.pcap` file directly to the Azure Support case (attachments).
- [ ] Delete the `.pcap` from the container: `rm /home/trace-*.pcap`.

## Safety notes

- `/home/` is the persistent shared volume — files there survive container
  restarts and are visible to all instances. Delete the trace from `/home/`
  once it has been uploaded to the support case.
- The trace is filtered to port 1433 + `fleet-sql-prod` host, so it should
  not contain customer HTTP traffic. Verify with Wireshark before upload.
- Do not enable `-X` / `-A` (which would dump packet payloads in human
  form); we already capture full packets via `-s 0`. The TLS payload is
  encrypted, but record headers (SNI) are visible — MS may need them.
