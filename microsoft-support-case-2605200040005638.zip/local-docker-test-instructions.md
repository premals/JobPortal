# Local Docker test — run the same image against `fleet-sql-prod`

Goal: prove whether the TLS handshake failures reproduce from a developer
workstation using the same Docker image that runs in Azure App Service.

**Hard rules**

- The temporary env file MUST NOT be committed and MUST NOT be added to the
  Microsoft ZIP. It lives only on your workstation.
- Use placeholders below — never paste real secrets into chat, tickets, or PRs.
- Run from the repo root: `c:\Users\hiram\OneDrive\Desktop\AIMRentals` (PowerShell)
  or `/c/Users/hiram/OneDrive/Desktop/AIMRentals` (bash).

---

## 1. Build the mobile-api image locally

The production build uses BuildKit secrets. Locally we do the same so we
reproduce the runtime image bit-for-bit.

```bash
# bash / WSL / git-bash
# Pull the prod DATABASE_URL out of Azure App Service into a TEMP file,
# build the image, then DELETE the file. Do NOT keep it around.
mkdir -p ./.local-secrets
chmod 700 ./.local-secrets
printf '%s' '<paste production DATABASE_URL here, single line, do not commit>' > ./.local-secrets/database_url
printf '%s' '<paste AZURE_BLOB_CONNECTION_STRING here>' > ./.local-secrets/azure_blob_connection_string
printf '%s' '<paste AZURE_BLOB_CONTAINER_NAME here>'   > ./.local-secrets/azure_blob_container_name

DOCKER_BUILDKIT=1 docker build \
  -f apps/mobile-api/Dockerfile \
  --secret id=database_url,src=./.local-secrets/database_url \
  --secret id=azure_blob_connection_string,src=./.local-secrets/azure_blob_connection_string \
  --secret id=azure_blob_container_name,src=./.local-secrets/azure_blob_container_name \
  -t nuvemfleet-mobile-api:local .

# Wipe build-time secret files immediately.
shred -u ./.local-secrets/*  2>/dev/null || rm -f ./.local-secrets/*
rmdir ./.local-secrets 2>/dev/null || true
```

PowerShell equivalent:

```powershell
$env:DOCKER_BUILDKIT = "1"
New-Item -ItemType Directory -Force .\.local-secrets | Out-Null
# Use the Windows credential manager or paste into Set-Content; never echo.
Set-Content -NoNewline .\.local-secrets\database_url '<paste production DATABASE_URL here>'
Set-Content -NoNewline .\.local-secrets\azure_blob_connection_string '<paste here>'
Set-Content -NoNewline .\.local-secrets\azure_blob_container_name '<paste here>'

docker build `
  -f apps/mobile-api/Dockerfile `
  --secret id=database_url,src=.\.local-secrets\database_url `
  --secret id=azure_blob_connection_string,src=.\.local-secrets\azure_blob_connection_string `
  --secret id=azure_blob_container_name,src=.\.local-secrets\azure_blob_container_name `
  -t nuvemfleet-mobile-api:local .

Remove-Item -Force .\.local-secrets\*
Remove-Item -Force .\.local-secrets
```

---

## 2. Create a temporary local env file

```bash
cat > ./.env.local-mobileapi <<'EOF'
DATABASE_URL=<paste production database URL locally, do not commit>
AZURE_BLOB_CONNECTION_STRING=<paste here>
AZURE_BLOB_CONTAINER_NAME=<paste here>
NODE_ENV=production
PORT=3002
LOG_LEVEL=info
LOG_FORMAT=json
ALLOWED_ORIGINS=https://localhost:3002
EOF
chmod 600 ./.env.local-mobileapi
```

Verify the file is gitignored:

```bash
git check-ignore -v ./.env.local-mobileapi
# Should print a line citing your .gitignore — if not, STOP and add it.
```

---

## 3. Run the container against `fleet-sql-prod`

```bash
docker run --rm \
  --name mobile-api-local \
  -p 3002:3002 \
  --env-file ./.env.local-mobileapi \
  nuvemfleet-mobile-api:local
```

Leave this terminal open — it streams container stdout.

PowerShell:

```powershell
docker run --rm `
  --name mobile-api-local `
  -p 3002:3002 `
  --env-file .\.env.local-mobileapi `
  nuvemfleet-mobile-api:local
```

---

## 4. Verify the app started and Azure SQL is reachable

In a second terminal:

```bash
# Liveness — no DB
curl -i http://localhost:3002/api/health

# Readiness — SELECT 1 against fleet-sql-prod
curl -i http://localhost:3002/api/health/db
```

Expected:
- `/api/health` → `200 { status: "ok", service: "mobile-api", ... }`
- `/api/health/db` → `200 { status: "ok", db: "ok", durationMs: <small> }` when
  the handshake succeeds, or `503 { status: "degraded", db: "unreachable",
  reason: "<error>" }` when it fails. **A 503 here is the reproduction we
  want to capture for Microsoft.**

Try the login endpoint (will fail without a real account, but exercises the
auth code path that does DB lookups):

```bash
curl -i -X POST http://localhost:3002/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"<a test account email, do not paste production users here>","password":"<test pw>"}'
```

---

## 5. Capture logs

```bash
# Stream
docker logs -f mobile-api-local

# Snapshot to a file you can attach to the support case
docker logs mobile-api-local > ./mobile-api-local.log 2>&1
```

Look for any of:
- `[PrismaHeartbeat] ping evicted stale conn:` — heartbeat saw a dead socket
- `P1001` / `P1011` / `P1017` — transient connection / TLS handshake failures
- `P2024` — pool timeout (NOT retried by design; surfaces as 503)
- `Error opening a TLS connection` / `Connection reset by peer`

Record the **UTC timestamp** of the first failure line — Microsoft will need
it to correlate against backend telemetry.

---

## 6. Stop and clean up

```bash
docker stop mobile-api-local 2>/dev/null || true
docker rm   mobile-api-local 2>/dev/null || true

# Wipe the local env file. It MUST NOT survive past the test.
shred -u ./.env.local-mobileapi 2>/dev/null || rm -f ./.env.local-mobileapi

# Optional: remove the local image
docker image rm nuvemfleet-mobile-api:local
```

PowerShell:

```powershell
docker stop mobile-api-local 2>$null
docker rm   mobile-api-local 2>$null
Remove-Item -Force .\.env.local-mobileapi
docker image rm nuvemfleet-mobile-api:local
```

---

## 7. What to send Microsoft from this test

- `mobile-api-local.log` (after redacting any tenant data lines if present).
- The exact UTC start/stop timestamps of the run.
- Your workstation's outbound public IP (so MS can correlate against the
  Azure SQL gateway logs): `curl -s https://api.ipify.org`.
- A note saying whether `/api/health/db` returned 200 or 503, and how many
  consecutive probes it took to fail (if it did).
